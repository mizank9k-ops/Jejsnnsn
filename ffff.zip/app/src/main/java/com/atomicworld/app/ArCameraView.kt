package com.atomicworld.app

import android.app.Activity
import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.AttributeSet
import android.view.Surface
import com.google.ar.core.ArCoreApk
import com.google.ar.core.CameraConfigFilter
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.google.ar.core.Session
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ArCameraView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs), GLSurfaceView.Renderer {
    private val activity = context as Activity
    private var session: Session? = null
    private var cameraTexture: SurfaceTexture? = null
    private var textureId = 0
    private var resumed = false
    private var resumeRequested = false
    @Volatile var trackingState = "AR READY"
    @Volatile var trackingConfidence = 0f
    @Volatile var arCoreDepthSupported = false
    @Volatile var arCoreDepthMm = 0f
    @Volatile var arCoreDepthNormalized = 0f
    @Volatile var arCoreTrackedPlanes = 0
    @Volatile var arCorePoseX = 0f
    @Volatile var arCorePoseY = 0f
    @Volatile var arCorePoseZ = 0f
    @Volatile var arCorePoseDistance = 0f
    @Volatile var arCorePoseYaw = 0f
    @Volatile var arCorePosePitch = 0f
    @Volatile var arCorePoseRoll = 0f
    @Volatile var detectedColorLevel = 0f
    @Volatile var cameraColorTracking = 0f
    @Volatile var gpuColorTracking = 0f
    @Volatile var modelColorTracking = 0f
    @Volatile var audioColorTracking = 0f
    @Volatile var sensorColorTracking = 0f
    @Volatile var bodyColorTracking = 0f
    @Volatile var personalBodyColorTracking = 0f
    @Volatile var virtualColorTracking = 0f
    @Volatile var enemyColorTracking = 0f
    @Volatile var systemColorTracking = 0f
    @Volatile var videoFeedback = "VIDEO WAITING"
    @Volatile var videoLoopProtectionActive = true
    @Volatile var videoFrameAgeMs = Long.MAX_VALUE
    @Volatile var cameraThreshold = 0.5f
    @Volatile var cameraSignalBlocked = false
    @Volatile var cameraSpeedThreshold = 0.65f
    @Volatile var cameraMotionThreshold = 0.65f
    @Volatile var cameraWaveThreshold = 0.65f
    @Volatile var cameraSurfaceSpeed = 0f
    @Volatile var cameraSurfaceMovement = 0f
    @Volatile var cameraSurfaceWave = 0f
    @Volatile var cameraBrightnessLevel = 0f
    @Volatile var audioBrightnessLevel = 0f
    @Volatile var audioColourBrightnessLevel = 0f
    @Volatile var cameraColourBrightnessLevel = 0f
    @Volatile var gpuColourBrightnessLevel = 0f
    @Volatile var cameraSurfaceBrightnessLevel = 0f
    @Volatile var visualBrightnessLevel = 0f
    @Volatile var cameraContrastLevel = 0f
    @Volatile var audioContrastLevel = 0f
    @Volatile var audioColourContrastLevel = 0f
    @Volatile var cameraColourContrastLevel = 0f
    @Volatile var gpuColourContrastLevel = 0f
    @Volatile var cameraSurfaceContrastLevel = 0f
    @Volatile var visualContrastLevel = 0f
    @Volatile var filterMode = 0
    @Volatile var colorThreshold = 0.5f
    @Volatile var visualProtectionEnabled = true
    @Volatile var antiVisualProtectionEnabled = true
    @Volatile var vhsTrackingEnabled = false
    @Volatile var vhsTrackingThreshold = 0.5f
    @Volatile var vhsTrackingLevel = 0f
    @Volatile var vhsMovementLevel = 0f
    @Volatile var vhsSpeedLevel = 0f
    @Volatile var vhsWaveLevel = 0f
    @Volatile var transmissionEnabled = false
    @Volatile var keystoneAmount = 0f
    @Volatile var axisProtectionEnabled = true
    @Volatile var axisRotation = 0f
    @Volatile var axisProtectionThreshold = 0.7f
    @Volatile var kaleidoscopeProtectionEnabled = true
    @Volatile var kaleidoscopeSegments = 6f
    @Volatile var kaleidoscopeAxis = 0f
    @Volatile var kaleidoscopeThreshold = 0.7f
    @Volatile var tunnelMode = 0
    @Volatile var tunnelDepth = 0.35f
    @Volatile var tunnelAxis = 0f
    @Volatile var tunnelProtectionEnabled = true
    @Volatile var zoomProtectionEnabled = true
    @Volatile var zoomAmount = 0f
    @Volatile var zoomProtectionThreshold = 0.7f
    @Volatile var edShowMotion = 0.5f
    @Volatile var edShowSpeed = 0.5f
    @Volatile var bodyMotion = 0f
    @Volatile var bodySpeed = 0f
    @Volatile var bodyWave = 0f
    @Volatile var bodyPitchProtection = 0f
    @Volatile var thermalMode = false
    @Volatile var thermalThreshold = 0.5f
    @Volatile var thermalLevel = 0.5f
    @Volatile var irMode = false
    @Volatile var irThreshold = 0.5f
    @Volatile var irLevel = 0.5f
    @Volatile var gpuBodyTextureEnabled = true
    @Volatile var gpuColorThreshold = 0.5f
    @Volatile var gpuProtectionEnabled = true
    @Volatile var cameraCommunicationGateEnabled = true
    @Volatile var cameraCommunicationThreshold = 0.55f
    @Volatile var cameraCommunicationBlocked = false
    @Volatile var virtualColourCommunicationGateEnabled = true
    @Volatile var virtualColourCommunicationThreshold = 0.55f
    @Volatile var virtualColourCommunicationLevel = 0f
    @Volatile var virtualVideoAnimationLevel = 0f
    @Volatile var virtualVideoAnimationThreshold = 0.55f
    @Volatile var audioReactiveFeedback = 0f
    @Volatile var motionRecursionFeedback = 0f
    @Volatile var enemyFeedbackLevel = 0f
    @Volatile var enemyFeedbackProtection = 0f
    @Volatile var videoFeedbackEnabled = true
    @Volatile var videoFeedbackGain = 0.35f
    @Volatile var videoFeedbackDecay = 0.65f
    @Volatile var videoFeedbackDepth = 0.35f
    @Volatile var videoFeedbackThreshold = 0.2f
    @Volatile var videoFeedbackLimiter = 0.8f
    @Volatile var cameraFeedbackThreshold = 0.5f
    @Volatile var cameraFeedbackLevel = 0f
    @Volatile var cameraColourFeedbackLevel = 0f
    @Volatile var cameraColourFeedbackDecay = 1f
    @Volatile var eyeVisionColourTracking = 0f
    @Volatile var focusMode = false
    @Volatile var focusThreshold = 0.5f
    @Volatile var enemyFocusThreshold = 0.7f
    @Volatile var focusBlocked = false
    @Volatile var slsMode = false
    @Volatile var slsThreshold = 0.5f
    @Volatile var slsLevel = 0.5f
    @Volatile var slsSmooth = 0.5f
    @Volatile var slsRed = 1f
    @Volatile var slsGreen = 0.2f
    @Volatile var slsBlue = 1f
    @Volatile var edgeProtectionEnabled = true
    @Volatile var edgeThreshold = 0.5f
    @Volatile var edgeLevel = 0.5f
    @Volatile var edgeSmooth = 0.5f
    @Volatile var edgeRed = 0.5f
    @Volatile var edgeGreen = 1f
    @Volatile var edgeBlue = 0f
    @Volatile var thermalRed = 1f
    @Volatile var thermalGreen = 0.25f
    @Volatile var thermalBlue = 0f
    @Volatile var thermalSmooth = 0.5f
    @Volatile var irRed = 0.2f
    @Volatile var irGreen = 1f
    @Volatile var irBlue = 0.3f
    @Volatile var irSmooth = 0.5f
    @Volatile var argumentRealityColorThreshold = 0.5f
    @Volatile var argumentRealityBrightnessThreshold = 0.5f
    @Volatile var argumentRealityContrastThreshold = 0.5f
    @Volatile var argumentRealityBipolarThresholdDb = 0f
    @Volatile var argumentRealityCommunicationGateEnabled = true
    @Volatile var argumentRealityCommunicationBlocked = false
    @Volatile var argumentRealityCommunicationLevel = 0f
    @Volatile var argumentRealityBrightnessLevel = 0f
    @Volatile var argumentRealityContrastLevel = 0f
    @Volatile var argumentRealityBipolarDb = -120f
    @Volatile var argumentRealityVirtualTracking = 0f
    @Volatile var argumentRealityEnabled = true
    @Volatile var argumentRealityIntensity = 1f
    @Volatile var argumentRealityScale = 1f
    @Volatile var argumentRealityAmbientShieldEnabled = true
    @Volatile var argumentRealityAmbientShieldThreshold = 0.5f
    @Volatile var argumentRealityAnimationShieldEnabled = true
    @Volatile var argumentRealityAnimationShieldThreshold = 0.5f
    @Volatile var argumentRealityBodyShieldEnabled = true
    @Volatile var argumentRealityBodyShieldThreshold = 0.5f
    @Volatile var argumentRealityHumanTrackingGateEnabled = true
    @Volatile var argumentRealityHumanTrackingThreshold = 0.5f
    @Volatile var humanVisualProtectionEnabled = true
    @Volatile var humanVisualProtectionActive = false
    @Volatile var argumentRealityEyesShieldEnabled = true
    @Volatile var argumentRealityEyesShieldThreshold = 0.5f
    @Volatile var argumentRealitySpikeShieldEnabled = true
    @Volatile var argumentRealitySpikeShieldThreshold = 0.35f
    @Volatile var argumentRealityShieldLevel = 0f
    @Volatile var argumentRealityShieldBlocked = false
    @Volatile var argumentRealityAmbientKillerEnabled = false
    @Volatile var argumentRealityFftThreshold = 0.5f
    @Volatile var argumentRealityFftLevel = 0f
    @Volatile var argumentRealityAmbientKillerBlocked = false
    @Volatile var argumentMovementThreshold = 0.65f
    @Volatile var argumentSpeedThreshold = 0.65f
    @Volatile var argumentWaveThreshold = 0.65f
    @Volatile var argumentPitchThreshold = 0.65f
    @Volatile var geometryDensity = 0.5f
    @Volatile var planeGain = 0.5f
    @Volatile var wallGain = 0.5f
    @Volatile var curveGain = 0.5f
    @Volatile var ringGain = 0.5f
    @Volatile var geometryRed = 0.1f
    @Volatile var geometryGreen = 0.8f
    @Volatile var geometryBlue = 1f
    @Volatile var argumentReality3dDepth = 0.35f
    @Volatile var argumentReality3dEnabled = true
    @Volatile var argumentRealityEnemy3dProtectionEnabled = true
    @Volatile var argumentReality3dActive = false
    @Volatile var argumentRealityEnemy3dProtection = false
    @Volatile var quantumSceneEnabled = true
    @Volatile var quantumParticleDensity = 0.55f
    @Volatile var quantumParticleScale = 0.45f
    @Volatile var quantumParticleThreshold = 0.25f
    @Volatile var quantumParticleEnergy = 0f
    @Volatile var argumentRealityBlocked = false
    @Volatile var modelRuntime: ModelRuntime? = null
    private var filteredConfidence = 0.0f
    private var peakConfidence = 0.0f
    private var videoWindowStart = 0L
    private var videoFrames = 0
    private var videoFps = 0

    private val vertexBuffer: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)).position(0)
        }
    private val texBuffer: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f)).position(0)
        }
    private val texMatrix = FloatArray(16)
    private var program = 0

    init {
        setEGLContextClientVersion(2)
        setRenderer(this)
        // ARCore must render at least once to produce the first camera frame.
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun onResumeSession() {
        resumeRequested = true
        onResume()
        if (resumed || textureId == 0) {
            if (textureId == 0) trackingState = "AR WAITING FOR CAMERA SURFACE"
            return
        }
        resumeSessionNow()
    }

    private fun resumeSessionNow() {
        if (resumed) return
        try {
            val availability = ArCoreApk.getInstance().checkAvailability(activity)
            if (!availability.isSupported) {
                trackingState = "ARCORE UNSUPPORTED: ${availability.name}"
                return
            }
            if (session == null) {
                val installStatus = ArCoreApk.getInstance().requestInstall(activity, true)
                if (installStatus == ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                    trackingState = "ARCORE INSTALL REQUIRED"
                    return
                }
                session = Session(activity).also { configure(it) }
            }
            session?.setCameraTextureName(textureId)
            session?.resume()
            resumed = true
            requestRender()
        } catch (error: Exception) {
            trackingState = "AR UNAVAILABLE: ${error.javaClass.simpleName} ${error.message ?: ""}".trim()
        }
    }

    fun onPauseSession() {
        resumeRequested = false
        if (!resumed) return
        session?.pause()
        resumed = false
        onPause()
    }

    fun closeSession() {
        onPauseSession()
        session?.close()
        session = null
        trackingState = "AR CLOSED"
    }

    private fun configure(value: Session) {
        val config = Config(value).apply {
            focusMode = Config.FocusMode.AUTO
            updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
            planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
            arCoreDepthSupported = value.isDepthModeSupported(Config.DepthMode.AUTOMATIC)
            if (arCoreDepthSupported) depthMode = Config.DepthMode.AUTOMATIC
        }
        value.configure(config)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        resumed = false
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        textureId = createExternalTexture()
        cameraTexture = SurfaceTexture(textureId).also { texture ->
            texture.setOnFrameAvailableListener { requestRender() }
        }
        post {
            if (resumeRequested && !resumed) resumeSessionNow()
            requestRender()
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val currentSession = session ?: return
        try {
            cameraTexture?.updateTexImage()
            cameraTexture?.getTransformMatrix(texMatrix)
            val frame: Frame = currentSession.update()
            val pose = frame.camera.pose
            arCorePoseX = pose.tx()
            arCorePoseY = pose.ty()
            arCorePoseZ = pose.tz()
            arCorePoseDistance = kotlin.math.sqrt(arCorePoseX * arCorePoseX + arCorePoseY * arCorePoseY + arCorePoseZ * arCorePoseZ)
            val quaternion = pose.rotationQuaternion
            arCorePoseYaw = kotlin.math.atan2(2f * (quaternion[3] * quaternion[2] + quaternion[0] * quaternion[1]), 1f - 2f * (quaternion[1] * quaternion[1] + quaternion[2] * quaternion[2]))
            arCorePosePitch = kotlin.math.asin((2f * (quaternion[3] * quaternion[1] - quaternion[2] * quaternion[0])).coerceIn(-1f, 1f))
            arCorePoseRoll = kotlin.math.atan2(2f * (quaternion[3] * quaternion[0] + quaternion[1] * quaternion[2]), 1f - 2f * (quaternion[0] * quaternion[0] + quaternion[1] * quaternion[1]))
            arCoreTrackedPlanes = frame.getUpdatedTrackables(Plane::class.java).count { it.trackingState.name == "TRACKING" }
            if (arCoreDepthSupported) {
                runCatching { frame.acquireDepthImage16Bits() }.onSuccess { depthImage ->
                    val plane = depthImage.planes.firstOrNull()
                    if (plane != null) {
                        val centerX = depthImage.width / 2
                        val centerY = depthImage.height / 2
                        val index = centerY * plane.rowStride + centerX * plane.pixelStride
                        if (index + 1 < plane.buffer.limit()) {
                            arCoreDepthMm = (plane.buffer.get(index).toInt() and 0xff or ((plane.buffer.get(index + 1).toInt() and 0xff) shl 8)).toFloat()
                            arCoreDepthNormalized = (1f - arCoreDepthMm / 5000f).coerceIn(0f, 1f)
                        }
                    }
                    depthImage.close()
                }
            }
            val now = android.os.SystemClock.elapsedRealtime()
            runCatching { frame.acquireCameraImage() }.onSuccess { image ->
                modelRuntime?.process(image, now) ?: image.close()
            }
            if (videoWindowStart == 0L) videoWindowStart = now
            videoFrames++
            if (now - videoWindowStart >= 1000L) {
                videoFps = videoFrames
                videoFrames = 0
                videoWindowStart = now
            }
            videoFrameAgeMs = 0L
            videoLoopProtectionActive = true
            videoFeedback = "VIDEO ${videoFps}FPS"
            val rawConfidence = when (frame.camera.trackingState.name) {
                "TRACKING" -> 1.0f
                "PAUSED" -> 0.5f
                else -> 0.0f
            }
            filteredConfidence = if (filterMode == 1) {
                filteredConfidence * 0.8f + rawConfidence * 0.2f
            } else {
                rawConfidence
            }
            peakConfidence = maxOf(peakConfidence * 0.98f, rawConfidence)
            val outputConfidence = if (filterMode == 2) peakConfidence else filteredConfidence
            trackingConfidence = outputConfidence
            trackingState = if (outputConfidence >= cameraThreshold) {
                "${frame.camera.trackingState.name} ${(outputConfidence * 100).toInt()}%"
            } else {
                "BELOW CAMERA THRESHOLD ${(outputConfidence * 100).toInt()}%"
            }
            drawCamera()
        } catch (error: Exception) {
            trackingState = "AR FRAME ERROR: ${error.javaClass.simpleName}"
        }
    }

    private fun drawCamera() {
        GLES20.glUseProgram(program)
        val position = GLES20.glGetAttribLocation(program, "aPosition")
        val texCoord = GLES20.glGetAttribLocation(program, "aTexCoord")
        val matrix = GLES20.glGetUniformLocation(program, "uTexMatrix")
        val rotationLocation = GLES20.glGetUniformLocation(program, "uRotation")
        val zoomLocation = GLES20.glGetUniformLocation(program, "uZoom")
        val colorThresholdLocation = GLES20.glGetUniformLocation(program, "uColorThreshold")
        val protectionLocation = GLES20.glGetUniformLocation(program, "uProtection")
        val vhsLocation = GLES20.glGetUniformLocation(program, "uVhs")
        val vhsThresholdLocation = GLES20.glGetUniformLocation(program, "uVhsThreshold")
        val transmissionLocation = GLES20.glGetUniformLocation(program, "uTransmission")
        val keystoneLocation = GLES20.glGetUniformLocation(program, "uKeystone")
        val motionLocation = GLES20.glGetUniformLocation(program, "uMotion")
        val bodyMotionLocation = GLES20.glGetUniformLocation(program, "uBodyMotion")
        val bodySpeedLocation = GLES20.glGetUniformLocation(program, "uBodySpeed")
        val bodyWaveLocation = GLES20.glGetUniformLocation(program, "uBodyWave")
        val pitchProtectionLocation = GLES20.glGetUniformLocation(program, "uPitchProtection")
        val thermalLocation = GLES20.glGetUniformLocation(program, "uThermal")
        val thermalThresholdLocation = GLES20.glGetUniformLocation(program, "uThermalThreshold")
        val thermalLevelLocation = GLES20.glGetUniformLocation(program, "uThermalLevel")
        val irLocation = GLES20.glGetUniformLocation(program, "uIr")
        val irThresholdLocation = GLES20.glGetUniformLocation(program, "uIrThreshold")
        val irLevelLocation = GLES20.glGetUniformLocation(program, "uIrLevel")
        val gpuLocation = GLES20.glGetUniformLocation(program, "uGpu")
        val gpuColorLocation = GLES20.glGetUniformLocation(program, "uGpuColor")
        val cameraGateLocation = GLES20.glGetUniformLocation(program, "uCameraGate")
        val focusLocation = GLES20.glGetUniformLocation(program, "uFocus")
        val focusThresholdLocation = GLES20.glGetUniformLocation(program, "uFocusThreshold")
        val slsLocation = GLES20.glGetUniformLocation(program, "uSls")
        val slsThresholdLocation = GLES20.glGetUniformLocation(program, "uSlsThreshold")
        val slsLevelLocation = GLES20.glGetUniformLocation(program, "uSlsLevel")
        val slsSmoothLocation = GLES20.glGetUniformLocation(program, "uSlsSmooth")
        val slsRedLocation = GLES20.glGetUniformLocation(program, "uSlsRed")
        val slsGreenLocation = GLES20.glGetUniformLocation(program, "uSlsGreen")
        val slsBlueLocation = GLES20.glGetUniformLocation(program, "uSlsBlue")
        val edgeLocation = GLES20.glGetUniformLocation(program, "uEdge")
        val edgeThresholdLocation = GLES20.glGetUniformLocation(program, "uEdgeThreshold")
        val edgeLevelLocation = GLES20.glGetUniformLocation(program, "uEdgeLevel")
        val edgeSmoothLocation = GLES20.glGetUniformLocation(program, "uEdgeSmooth")
        val edgeRedLocation = GLES20.glGetUniformLocation(program, "uEdgeRed")
        val edgeGreenLocation = GLES20.glGetUniformLocation(program, "uEdgeGreen")
        val edgeBlueLocation = GLES20.glGetUniformLocation(program, "uEdgeBlue")
        val thermalRedLocation = GLES20.glGetUniformLocation(program, "uThermalRed")
        val thermalGreenLocation = GLES20.glGetUniformLocation(program, "uThermalGreen")
        val thermalBlueLocation = GLES20.glGetUniformLocation(program, "uThermalBlue")
        val thermalSmoothLocation = GLES20.glGetUniformLocation(program, "uThermalSmooth")
        val irRedLocation = GLES20.glGetUniformLocation(program, "uIrRed")
        val irGreenLocation = GLES20.glGetUniformLocation(program, "uIrGreen")
        val irBlueLocation = GLES20.glGetUniformLocation(program, "uIrBlue")
        val irSmoothLocation = GLES20.glGetUniformLocation(program, "uIrSmooth")
        val geometryLocation = GLES20.glGetUniformLocation(program, "uGeometry")
        val geometryDensityLocation = GLES20.glGetUniformLocation(program, "uGeometryDensity")
        val planeGainLocation = GLES20.glGetUniformLocation(program, "uPlaneGain")
        val wallGainLocation = GLES20.glGetUniformLocation(program, "uWallGain")
        val curveGainLocation = GLES20.glGetUniformLocation(program, "uCurveGain")
        val ringGainLocation = GLES20.glGetUniformLocation(program, "uRingGain")
        val geometryRedLocation = GLES20.glGetUniformLocation(program, "uGeometryRed")
        val geometryGreenLocation = GLES20.glGetUniformLocation(program, "uGeometryGreen")
        val geometryBlueLocation = GLES20.glGetUniformLocation(program, "uGeometryBlue")
            val geometryDepthLocation = GLES20.glGetUniformLocation(program, "uGeometryDepth")
            val enemy3dProtectionLocation = GLES20.glGetUniformLocation(program, "uEnemy3dProtection")
            val quantumEnabledLocation = GLES20.glGetUniformLocation(program, "uQuantumEnabled")
            val quantumDensityLocation = GLES20.glGetUniformLocation(program, "uQuantumDensity")
            val quantumScaleLocation = GLES20.glGetUniformLocation(program, "uQuantumScale")
            val quantumThresholdLocation = GLES20.glGetUniformLocation(program, "uQuantumThreshold")
            val quantumEnergyLocation = GLES20.glGetUniformLocation(program, "uQuantumEnergy")
        val timeLocation = GLES20.glGetUniformLocation(program, "uTime")
        val kaleidoscopeLocation = GLES20.glGetUniformLocation(program, "uKaleidoscope")
        val kaleidoscopeSegmentsLocation = GLES20.glGetUniformLocation(program, "uKaleidoscopeSegments")
        val kaleidoscopeAxisLocation = GLES20.glGetUniformLocation(program, "uKaleidoscopeAxis")
        val kaleidoscopeThresholdLocation = GLES20.glGetUniformLocation(program, "uKaleidoscopeThreshold")
        val tunnelModeLocation = GLES20.glGetUniformLocation(program, "uTunnelMode")
        val tunnelDepthLocation = GLES20.glGetUniformLocation(program, "uTunnelDepth")
        val tunnelAxisLocation = GLES20.glGetUniformLocation(program, "uTunnelAxis")
        val tunnelProtectionLocation = GLES20.glGetUniformLocation(program, "uTunnelProtection")
        val feedbackEnabledLocation = GLES20.glGetUniformLocation(program, "uFeedbackEnabled")
        val feedbackGainLocation = GLES20.glGetUniformLocation(program, "uFeedbackGain")
        val feedbackDecayLocation = GLES20.glGetUniformLocation(program, "uFeedbackDecay")
        val feedbackDepthLocation = GLES20.glGetUniformLocation(program, "uFeedbackDepth")
        val feedbackThresholdLocation = GLES20.glGetUniformLocation(program, "uFeedbackThreshold")
        val feedbackLimiterLocation = GLES20.glGetUniformLocation(program, "uFeedbackLimiter")
        GLES20.glEnableVertexAttribArray(position)
        GLES20.glEnableVertexAttribArray(texCoord)
        GLES20.glVertexAttribPointer(position, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glVertexAttribPointer(texCoord, 2, GLES20.GL_FLOAT, false, 0, texBuffer)
        GLES20.glUniformMatrix4fv(matrix, 1, false, texMatrix, 0)
        GLES20.glUniform1f(rotationLocation, if (axisProtectionEnabled && trackingConfidence < axisProtectionThreshold) 0f else axisRotation)
        GLES20.glUniform1f(zoomLocation, if (zoomProtectionEnabled && trackingConfidence < zoomProtectionThreshold) 0f else zoomAmount)
        GLES20.glUniform1f(colorThresholdLocation, colorThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(protectionLocation, if (visualProtectionEnabled || antiVisualProtectionEnabled) 1f else 0f)
        GLES20.glUniform1f(vhsLocation, if (vhsTrackingEnabled) 1f else 0f)
        GLES20.glUniform1f(vhsThresholdLocation, vhsTrackingThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(transmissionLocation, if (transmissionEnabled) 1f else 0f)
        GLES20.glUniform1f(keystoneLocation, keystoneAmount.coerceIn(-1f, 1f))
        val feedbackMotion = (edShowMotion * edShowSpeed * 0.45f + audioReactiveFeedback * 0.25f + motionRecursionFeedback * 0.30f).coerceIn(0f, 1f)
        GLES20.glUniform1f(motionLocation, feedbackMotion)
        GLES20.glUniform1f(bodyMotionLocation, bodyMotion.coerceIn(0f, 1f))
        GLES20.glUniform1f(bodySpeedLocation, bodySpeed.coerceIn(0f, 1f))
        GLES20.glUniform1f(bodyWaveLocation, bodyWave.coerceIn(0f, 1f))
        GLES20.glUniform1f(pitchProtectionLocation, bodyPitchProtection.coerceIn(0f, 1f))
        GLES20.glUniform1f(thermalLocation, if (thermalMode) 1f else 0f)
        GLES20.glUniform1f(thermalThresholdLocation, thermalThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(thermalLevelLocation, thermalLevel.coerceIn(0f, 1f))
        GLES20.glUniform1f(irLocation, if (irMode) 1f else 0f)
        GLES20.glUniform1f(irThresholdLocation, irThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(irLevelLocation, irLevel.coerceIn(0f, 1f))
        GLES20.glUniform1f(gpuLocation, if (gpuBodyTextureEnabled && gpuProtectionEnabled) 1f else 0f)
        GLES20.glUniform1f(gpuColorLocation, gpuColorThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(cameraGateLocation, if (cameraCommunicationGateEnabled && cameraCommunicationBlocked) 1f else 0f)
        GLES20.glUniform1f(focusLocation, if (focusMode && focusBlocked) 1f else 0f)
        GLES20.glUniform1f(focusThresholdLocation, focusThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(slsLocation, if (slsMode) 1f else 0f)
        GLES20.glUniform1f(slsThresholdLocation, slsThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(slsLevelLocation, slsLevel.coerceIn(0f, 1f))
        GLES20.glUniform1f(slsSmoothLocation, slsSmooth.coerceIn(0f, 1f))
        GLES20.glUniform1f(slsRedLocation, slsRed.coerceIn(0f, 1f))
        GLES20.glUniform1f(slsGreenLocation, slsGreen.coerceIn(0f, 1f))
        GLES20.glUniform1f(slsBlueLocation, slsBlue.coerceIn(0f, 1f))
        GLES20.glUniform1f(edgeLocation, if (edgeProtectionEnabled) 1f else 0f)
        GLES20.glUniform1f(edgeThresholdLocation, edgeThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(edgeLevelLocation, edgeLevel.coerceIn(0f, 1f))
        GLES20.glUniform1f(edgeSmoothLocation, edgeSmooth.coerceIn(0f, 1f))
        GLES20.glUniform1f(edgeRedLocation, edgeRed.coerceIn(0f, 1f))
        GLES20.glUniform1f(edgeGreenLocation, edgeGreen.coerceIn(0f, 1f))
        GLES20.glUniform1f(edgeBlueLocation, edgeBlue.coerceIn(0f, 1f))
        GLES20.glUniform1f(thermalRedLocation, thermalRed.coerceIn(0f, 1f))
        GLES20.glUniform1f(thermalGreenLocation, thermalGreen.coerceIn(0f, 1f))
        GLES20.glUniform1f(thermalBlueLocation, thermalBlue.coerceIn(0f, 1f))
        GLES20.glUniform1f(thermalSmoothLocation, thermalSmooth.coerceIn(0f, 1f))
        GLES20.glUniform1f(irRedLocation, irRed.coerceIn(0f, 1f))
        GLES20.glUniform1f(irGreenLocation, irGreen.coerceIn(0f, 1f))
        GLES20.glUniform1f(irBlueLocation, irBlue.coerceIn(0f, 1f))
        GLES20.glUniform1f(irSmoothLocation, irSmooth.coerceIn(0f, 1f))
        val realityIntensity = argumentRealityIntensity.coerceIn(0f, 1f)
        val realityScale = argumentRealityScale.coerceIn(0.1f, 10f)
        GLES20.glUniform1f(geometryLocation, if (argumentRealityEnabled) realityIntensity else 0f)
        GLES20.glUniform1f(geometryDensityLocation, (geometryDensity * realityScale).coerceIn(0f, 1f))
        GLES20.glUniform1f(planeGainLocation, (planeGain * realityIntensity).coerceIn(0f, 1f))
        GLES20.glUniform1f(wallGainLocation, (wallGain * realityIntensity).coerceIn(0f, 1f))
        GLES20.glUniform1f(curveGainLocation, (curveGain * realityIntensity).coerceIn(0f, 1f))
        GLES20.glUniform1f(ringGainLocation, (ringGain * realityIntensity).coerceIn(0f, 1f))
        GLES20.glUniform1f(geometryRedLocation, geometryRed.coerceIn(0f, 1f))
        GLES20.glUniform1f(geometryGreenLocation, geometryGreen.coerceIn(0f, 1f))
        GLES20.glUniform1f(geometryBlueLocation, geometryBlue.coerceIn(0f, 1f))
            val measuredDepth = if (arCoreDepthSupported) arCoreDepthNormalized else trackingConfidence
            GLES20.glUniform1f(geometryDepthLocation, if (argumentReality3dActive) (argumentReality3dDepth * (0.35f + measuredDepth * 0.65f)).coerceIn(0f, 1f) else 0f)
            GLES20.glUniform1f(enemy3dProtectionLocation, if (argumentRealityEnemy3dProtection) 1f else 0f)
            GLES20.glUniform1f(quantumEnabledLocation, if (quantumSceneEnabled) 1f else 0f)
            GLES20.glUniform1f(quantumDensityLocation, quantumParticleDensity.coerceIn(0f, 1f))
            GLES20.glUniform1f(quantumScaleLocation, quantumParticleScale.coerceIn(0f, 1f))
            GLES20.glUniform1f(quantumThresholdLocation, quantumParticleThreshold.coerceIn(0f, 1f))
            GLES20.glUniform1f(quantumEnergyLocation, quantumParticleEnergy.coerceIn(0f, 1f))
        GLES20.glUniform1f(timeLocation, (android.os.SystemClock.uptimeMillis() % 100000L) / 1000f)
        GLES20.glUniform1f(kaleidoscopeLocation, if (kaleidoscopeProtectionEnabled) 1f else 0f)
        GLES20.glUniform1f(kaleidoscopeSegmentsLocation, kaleidoscopeSegments.coerceIn(2f, 32f))
        GLES20.glUniform1f(kaleidoscopeAxisLocation, kaleidoscopeAxis)
        GLES20.glUniform1f(kaleidoscopeThresholdLocation, kaleidoscopeThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(tunnelModeLocation, tunnelMode.coerceIn(0, 6).toFloat())
        GLES20.glUniform1f(tunnelDepthLocation, tunnelDepth.coerceIn(0f, 1f))
        GLES20.glUniform1f(tunnelAxisLocation, tunnelAxis)
        GLES20.glUniform1f(tunnelProtectionLocation, if (tunnelProtectionEnabled) 1f else 0f)
        GLES20.glUniform1f(feedbackEnabledLocation, if (videoFeedbackEnabled) 1f else 0f)
        GLES20.glUniform1f(feedbackGainLocation, videoFeedbackGain.coerceIn(0f, 1f))
        GLES20.glUniform1f(feedbackDecayLocation, videoFeedbackDecay.coerceIn(0f, 1f))
        GLES20.glUniform1f(feedbackDepthLocation, videoFeedbackDepth.coerceIn(0f, 1f))
        GLES20.glUniform1f(feedbackThresholdLocation, videoFeedbackThreshold.coerceIn(0f, 1f))
        GLES20.glUniform1f(feedbackLimiterLocation, videoFeedbackLimiter.coerceIn(0f, 1f))
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(position)
        GLES20.glDisableVertexAttribArray(texCoord)
    }

    private fun createExternalTexture(): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textures[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return textures[0]
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        fun compile(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            return shader
        }

        var effectFragment = fragment
        effectFragment = effectFragment.replace(
            "precision mediump float;",
            "precision mediump float; uniform float uGeometryDepth; uniform float uEnemy3dProtection; uniform float uQuantumEnabled; uniform float uQuantumDensity; uniform float uQuantumScale; uniform float uQuantumThreshold; uniform float uQuantumEnergy; uniform float uFeedbackEnabled; uniform float uFeedbackGain; uniform float uFeedbackDecay; uniform float uFeedbackDepth; uniform float uFeedbackThreshold; uniform float uFeedbackLimiter; uniform float uKaleidoscope; uniform float uKaleidoscopeSegments; uniform float uKaleidoscopeAxis; uniform float uKaleidoscopeThreshold; uniform float uTunnelMode; uniform float uTunnelDepth; uniform float uTunnelAxis; uniform float uTunnelProtection;"
        )
        effectFragment = effectFragment.replace(
            "vec2 uv=vTexCoord; vec2 effectPoint=uv-vec2(0.5); float effectRadius=length(effectPoint); float effectAngle=atan(effectPoint.y,effectPoint.x)+uKaleidoscopeAxis+uTunnelAxis; float tunnelGate=step(0.5,uTunnelMode)*uTunnelProtection; if(tunnelGate>0.0){ if(uTunnelMode<1.5){effectPoint*=1.0+uTunnelDepth*(1.0-effectRadius);} else if(uTunnelMode<2.5){effectPoint*=1.0+uTunnelDepth*(0.5+0.5*sin(effectAngle*3.0));} else {effectAngle+=uTunnelDepth*sin(effectRadius*18.0-uTime*0.8); effectPoint=vec2(cos(effectAngle),sin(effectAngle))*effectRadius*(1.0+uTunnelDepth*(1.0-effectRadius));} } float kaleidoGate=uKaleidoscope*(1.0-0.5*uKaleidoscopeThreshold); if(kaleidoGate>0.0){float sector=6.2831853/max(uKaleidoscopeSegments,2.0); float localAngle=mod(effectAngle,sector); localAngle=abs(localAngle-sector*0.5); vec2 kaleidoPoint=vec2(cos(localAngle),sin(localAngle))*effectRadius; effectPoint=mix(effectPoint,kaleidoPoint,kaleidoGate);} uv=effectPoint+vec2(0.5);",
            ""
        )
        effectFragment = effectFragment.replace(
            "vec2 uv=vTexCoord;",
            "vec2 uv=vTexCoord; float depthWave=sin((uv.y+uTime*0.12)*18.0)*cos((uv.x-uTime*0.08)*14.0); uv+=vec2(depthWave*0.025*uGeometryDepth, depthWave*0.018*uGeometryDepth);"
        )
        effectFragment = effectFragment.replace(
            "vec3 c=texture2D(sTexture,uv).rgb;",
            "vec3 c=texture2D(sTexture,uv).rgb; float feedbackGate=step(uFeedbackThreshold,uFeedbackGain)*uFeedbackEnabled; if(feedbackGate>0.0){vec2 center=vec2(0.5); vec2 delta=(uv-center)*(0.08+uFeedbackDepth*0.16); vec3 recursive=texture2D(sTexture,center+(uv-center)*(1.0-delta.x)).rgb; recursive+=texture2D(sTexture,center+(uv-center)*(1.0-delta.y)).rgb*0.5; c=mix(c,recursive*0.6667,feedbackGate*uFeedbackGain*uFeedbackDecay*uFeedbackLimiter); }"
        )
        effectFragment = effectFragment.replace(
            "else {effectAngle+=uTunnelDepth*sin(effectRadius*18.0-uTime*0.8); effectPoint=vec2(cos(effectAngle),sin(effectAngle))*effectRadius*(1.0+uTunnelDepth*(1.0-effectRadius));}",
            "else if(uTunnelMode<3.5){effectAngle+=uTunnelDepth*sin(effectRadius*18.0-uTime*0.8); effectPoint=vec2(cos(effectAngle),sin(effectAngle))*effectRadius*(1.0+uTunnelDepth*(1.0-effectRadius));} else if(uTunnelMode<4.5){effectAngle+=uTunnelDepth*sin(effectRadius*24.0-uTime*1.1)+uTunnelDepth*0.4; effectPoint=vec2(cos(effectAngle),sin(effectAngle))*effectRadius*(1.0+uTunnelDepth*(0.7-effectRadius));} else if(uTunnelMode<5.5){effectAngle+=uTunnelDepth*cos(effectRadius*30.0-uTime*1.4); effectPoint=vec2(cos(effectAngle),sin(effectAngle))*effectRadius*(1.0+uTunnelDepth*(0.45+0.55*sin(effectAngle*4.0)));} else {effectAngle+=uTunnelDepth*sin(effectRadius*42.0-uTime*1.8); effectPoint=vec2(cos(effectAngle),sin(effectAngle))*effectRadius*(1.0+uTunnelDepth*(0.25+0.75*cos(effectAngle*7.0)));}"
        )
        effectFragment = effectFragment.replace(
            "c=mix(c,vec3(uGeometryRed,uGeometryGreen,uGeometryBlue),geometryMask*0.48);",
            "vec3 geometryColor=mix(vec3(uGeometryRed,uGeometryGreen,uGeometryBlue),vec3(1.0,0.08,0.02),uEnemy3dProtection); c=mix(c,geometryColor,geometryMask*(0.48+0.22*uGeometryDepth));"
        )
        effectFragment = effectFragment.replace(
            "c+=vec3(scan);",
            "if(uQuantumEnabled>0.5 && uQuantumEnergy>=uQuantumThreshold){float qx=fract(uv.x*(18.0+uQuantumDensity*80.0)+sin(uTime*0.7)*uQuantumScale); float qy=fract(uv.y*(14.0+uQuantumDensity*64.0)+cos(uTime*0.5)*uQuantumScale); float qdot=step(0.94,qx)*step(0.94,qy); float qhalo=step(0.985,sin((qx+qy+uTime)*40.0)*0.5+0.5); c+=vec3(0.05,0.55,1.0)*(qdot+qhalo*0.35)*uQuantumEnergy; } c+=vec3(scan);"
        )
        val value = GLES20.glCreateProgram()
        GLES20.glAttachShader(value, compile(GLES20.GL_VERTEX_SHADER, vertex))
        GLES20.glAttachShader(value, compile(GLES20.GL_FRAGMENT_SHADER, effectFragment))
        GLES20.glLinkProgram(value)
        return value
    }

    companion object {
        private const val VERTEX_SHADER = "attribute vec4 aPosition; attribute vec2 aTexCoord; varying vec2 vTexCoord; uniform mat4 uTexMatrix; uniform float uRotation; uniform float uZoom; void main(){float c=cos(uRotation*0.35);float s=sin(uRotation*0.35);vec2 p=aPosition.xy; p=vec2(p.x*c-p.y*s,p.x*s+p.y*c);p*=1.0-uZoom;gl_Position=vec4(p,0.0,1.0);vTexCoord=(uTexMatrix*vec4(aTexCoord,0.0,1.0)).xy;}"
               private const val FRAGMENT_SHADER = "#extension GL_OES_EGL_image_external : require\nprecision mediump float; uniform samplerExternalOES sTexture; uniform float uColorThreshold; uniform float uProtection; uniform float uVhs; uniform float uVhsThreshold; uniform float uTransmission; uniform float uKeystone; uniform float uMotion; uniform float uBodyMotion; uniform float uBodySpeed; uniform float uBodyWave; uniform float uPitchProtection; uniform float uThermal; uniform float uThermalThreshold; uniform float uThermalLevel; uniform float uThermalRed; uniform float uThermalGreen; uniform float uThermalBlue; uniform float uThermalSmooth; uniform float uIr; uniform float uIrThreshold; uniform float uIrLevel; uniform float uIrRed; uniform float uIrGreen; uniform float uIrBlue; uniform float uIrSmooth; uniform float uGpu; uniform float uGpuColor; uniform float uCameraGate; uniform float uFocus; uniform float uFocusThreshold; uniform float uSls; uniform float uSlsThreshold; uniform float uSlsLevel; uniform float uSlsSmooth; uniform float uSlsRed; uniform float uSlsGreen; uniform float uSlsBlue; uniform float uEdge; uniform float uEdgeThreshold; uniform float uEdgeLevel; uniform float uEdgeSmooth; uniform float uEdgeRed; uniform float uEdgeGreen; uniform float uEdgeBlue; uniform float uGeometry; uniform float uGeometryDensity; uniform float uPlaneGain; uniform float uWallGain; uniform float uCurveGain; uniform float uRingGain; uniform float uGeometryRed; uniform float uGeometryGreen; uniform float uGeometryBlue; uniform float uTime; varying vec2 vTexCoord; void main(){ vec2 uv=vTexCoord; uv.y += uKeystone * (uv.x-0.5) * 0.12; vec3 c=texture2D(sTexture,uv).rgb; float peak=max(c.r,max(c.g,c.b)); float vhsGate=step(uVhsThreshold,peak); float scan=sin((uv.y*720.0+uTime*18.0))*0.025*uVhs*vhsGate; float protect=step(uColorThreshold,peak)*uProtection; c=mix(c,vec3(min(c.r,0.82),min(c.g,0.88),min(c.b,0.92)),protect*0.35); float bodyPulse=(uBodyMotion*0.08+uBodySpeed*0.05+uBodyWave*0.05)*sin(uv.y*90.0+uTime*5.0); c += vec3(bodyPulse,bodyPulse*0.7,bodyPulse*0.35); c += vec3(0.08,0.0,0.0)*uPitchProtection*abs(sin(uv.x*18.0+uTime*4.0)); if(uThermal>0.5){float heat=step(uThermalThreshold,peak)*uThermalLevel;c=mix(c,vec3(uThermalRed,uThermalGreen,uThermalBlue),heat*(0.35+uThermalSmooth*0.45));} if(uIr>0.5){float ir=step(uIrThreshold,1.0-peak)*uIrLevel;c=mix(c,vec3(uIrRed,uIrGreen,uIrBlue),ir*(0.3+uIrSmooth*0.4));} if(uSls>0.5){float sls=step(uSlsThreshold,peak)*uSlsLevel;c=mix(c,vec3(uSlsRed,uSlsGreen,uSlsBlue),sls*(0.3+uSlsSmooth*0.4));} if(uGpu>0.5){float grid=step(0.97,abs(sin(uv.x*80.0))*abs(sin(uv.y*60.0)));c=mix(c,vec3(c.r+uGpuColor*0.08,c.g+uGpuColor*0.16,c.b+uGpuColor*0.20),0.45);c+=vec3(grid)*0.025;} if(uGeometry>0.5){float planes=step(0.985,abs(sin(uv.x*(24.0+uGeometryDensity*120.0))))*uPlaneGain;float walls=step(0.985,abs(sin(uv.y*(18.0+uGeometryDensity*90.0))))*uWallGain;float curves=step(0.992,abs(sin((uv.x+uv.y+uTime*0.02)*(12.0+uGeometryDensity*60.0))))*uCurveGain;float rings=step(0.994,abs(sin(length(uv-vec2(0.5))*(22.0+uGeometryDensity*120.0)-uTime*0.8))*uRingGain);float geometryMask=clamp(planes+walls+curves+rings,0.0,1.0);c=mix(c,vec3(uGeometryRed,uGeometryGreen,uGeometryBlue),geometryMask*0.48);} if(uEdge>0.5){float edge=step(uEdgeThreshold,abs(sin(uv.x*180.0+uTime*2.0))*abs(sin(uv.y*140.0)))*uEdgeLevel;c=mix(c,vec3(uEdgeRed,uEdgeGreen,uEdgeBlue),edge*(0.3+uEdgeSmooth*0.45));} if(uFocus>0.5){float focusMask=step(uFocusThreshold,peak);c=mix(c,vec3(0.02),1.0-focusMask*0.8);} c+=vec3(scan);if(uTransmission>0.5){float glitch=sin(uv.y*140.0+uTime*32.0)*0.018*uMotion;c.r+=glitch;c.b-=glitch;}if(uCameraGate>0.5){c=mix(c,vec3(0.02,0.02,0.02),0.82);c.r+=0.05*abs(sin(uTime*5.0));}gl_FragColor=vec4(clamp(c,0.0,1.0),1.0);}"
    }
}