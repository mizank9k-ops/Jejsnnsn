package com.atomicworld.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

class SensorTelemetry(context: Context) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensors = mapOf(
        "ACCEL" to Sensor.TYPE_ACCELEROMETER,
        "GYRO" to Sensor.TYPE_GYROSCOPE,
        "ROTATION" to Sensor.TYPE_ROTATION_VECTOR,
        "GRAVITY" to Sensor.TYPE_GRAVITY,
        "MAGNETIC" to Sensor.TYPE_MAGNETIC_FIELD,
        "LIGHT" to Sensor.TYPE_LIGHT,
        "PROXIMITY" to Sensor.TYPE_PROXIMITY
    )
    private val enabled = sensors.keys.associateWith { true }.toMutableMap()
    private val values = sensors.keys.associateWith { floatArrayOf(0f, 0f, 0f) }.toMutableMap()
    @Volatile var sensitivity = 1f
        private set
    @Volatile var threshold = 0.2f
        private set
    @Volatile var active = false
        private set
    @Volatile var lastUpdateMs = 0L
        private set
    @Volatile private var emfEvents = 0
    @Volatile private var emfLevel = 0f

    fun setEnabled(name: String, value: Boolean) {
        if (name in enabled) enabled[name] = value
        refresh()
    }

    fun setSensitivity(value: Float) { sensitivity = value.coerceIn(0f, 3f) }
    fun setThreshold(value: Float) { threshold = value.coerceIn(0f, 1f) }

    fun start() {
        refresh()
    }

    fun stop() {
        manager.unregisterListener(this)
        active = false
    }

    private fun refresh() {
        manager.unregisterListener(this)
        var registered = false
        enabled.forEach { (name, on) ->
            if (on) {
                manager.getDefaultSensor(sensors.getValue(name))?.let {
                    registered = manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) || registered
                }
            }
        }
        active = registered
    }

    fun summary(): String {
        val enabledNames = enabled.filterValues { it }.keys.joinToString("/")
        val age = if (lastUpdateMs == 0L) "WAITING" else "LIVE"
        return "SENSORS $age ${enabledNames.ifEmpty { "NONE" }}"
    }

    fun rawSummary(): String {
        val accel = magnitude(values["ACCEL"] ?: floatArrayOf()) * sensitivity
        val gyro = magnitude(values["GYRO"] ?: floatArrayOf()) * sensitivity
        val light = values["LIGHT"]?.firstOrNull() ?: 0f
        val proximity = values["PROXIMITY"]?.firstOrNull() ?: 0f
        val state = if (active && lastUpdateMs > 0L) "LIVE" else "WAITING"
        return "$state | ACCEL ${"%.2f".format(accel)} | GYRO ${"%.2f".format(gyro)} | EMF ${"%.1f".format(emfLevel)} (#$emfEvents) | LIGHT ${"%.1f".format(light)} | PROX ${"%.1f".format(proximity)} | THRESH ${(threshold * 100f).toInt()}%"
    }

    fun motionLevel(): Float = (magnitude(values["ACCEL"] ?: floatArrayOf()) * sensitivity / 10f).coerceIn(0f, 1f)

    private fun magnitude(value: FloatArray): Float {
        if (value.isEmpty()) return 0f
        return sqrt(value.sumOf { it.toDouble() * it.toDouble() }).toFloat()
    }

    override fun onSensorChanged(event: SensorEvent) {
        val name = sensors.entries.firstOrNull { it.value == event.sensor.type }?.key ?: return
        values[name] = event.values.copyOf()
        if (name == "MAGNETIC") {
            emfLevel = (magnitude(event.values) * sensitivity / 100f).coerceIn(0f, 1f)
            if (emfLevel >= threshold) emfEvents++
        }
        lastUpdateMs = android.os.SystemClock.elapsedRealtime()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
