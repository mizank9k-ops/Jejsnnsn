package com.atomicworld.app

import android.content.Context
import java.security.MessageDigest

object ModelRegistry {
    data class ModelStatus(
        val assetPath: String,
        val available: Boolean,
        val bytes: Long,
        val sha256: String
    )

    private val modelPaths = listOf(
        "models/pose_landmarker_full.task",
        "models/face_landmarker.task",
        "models/hand_landmarker.task"
    )

    fun inspect(context: Context): List<ModelStatus> = modelPaths.map { path ->
        runCatching {
            val digest = MessageDigest.getInstance("SHA-256")
            var bytes = 0L
            context.assets.open(path).use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var read = input.read(buffer)
                while (read >= 0) {
                    if (read > 0) {
                        digest.update(buffer, 0, read)
                        bytes += read
                    }
                    read = input.read(buffer)
                }
            }
            ModelStatus(path, bytes > 1024L * 1024L, bytes, digest.digest().toHex())
        }.getOrElse {
            ModelStatus(path, false, 0L, "")
        }
    }

    fun summary(context: Context): String {
        val statuses = inspect(context)
        val ready = statuses.count { it.available }
        return "MODELS $ready/${statuses.size} READY"
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
