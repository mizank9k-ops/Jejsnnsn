package com.atomicworld.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.sin

class RawFeatureBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {
    data class Channel(val label: String, var value: Float = 0f, var threshold: Float = 0.3f)

    @Volatile var channels: List<Channel> = emptyList()
    private var running = false
    private var thread: Thread? = null
    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this, "raw-feature-board").also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join(300)
        thread = null
    }

    override fun run() {
        while (running) {
            val canvas = holder.lockCanvas()
            if (canvas != null) {
                try {
                    drawBoard(canvas)
                } finally {
                    holder.unlockCanvasAndPost(canvas)
                }
            }
            phase += 0.12f
            Thread.sleep(33)
        }
    }

    private fun drawBoard(canvas: Canvas) {
        val width = canvas.width.toFloat()
        val height = canvas.height.toFloat()
        canvas.drawColor(Color.rgb(11, 15, 26))
        paint.style = Paint.Style.FILL
        paint.color = Color.CYAN
        paint.textSize = 22f
        canvas.drawText("RAW FEATURE BOARD  |  SURFACE / MOVE / WAVE / SPEED", 12f, 28f, paint)

        val current = channels
        if (current.isEmpty()) return
        val columns = 3
        val rows = (current.size + columns - 1) / columns
        val cellWidth = width / columns
        val cellHeight = (height - 38f) / rows
        current.forEachIndexed { index, channel ->
            val column = index % columns
            val row = index / columns
            drawChannel(
                canvas,
                column * cellWidth,
                38f + row * cellHeight,
                cellWidth,
                cellHeight,
                channel
            )
        }
    }

    private fun drawChannel(canvas: Canvas, left: Float, top: Float, width: Float, height: Float, channel: Channel) {
        val value = channel.value.coerceIn(0f, 1f)
        val threshold = channel.threshold.coerceIn(0f, 1f)
        val centerY = top + height * 0.54f
        val amplitude = height * 0.28f * value
        val color = detectionColor(value)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = Color.rgb(45, 60, 78)
        canvas.drawRect(left + 6f, top + 5f, left + width - 6f, top + height - 6f, paint)

        val path = Path()
        path.moveTo(left + 8f, centerY)
        for (step in 0..24) {
            val x = left + 8f + (width - 16f) * step / 24f
            val y = centerY + sin(phase + step * 0.45f) * amplitude
            path.lineTo(x, y)
        }
        paint.color = color
        paint.strokeWidth = 3f
        canvas.drawPath(path, paint)

        val thresholdY = centerY - amplitude.coerceAtLeast(height * 0.22f) * threshold
        paint.color = Color.MAGENTA
        paint.strokeWidth = 1f
        canvas.drawLine(left + 8f, thresholdY, left + width - 8f, thresholdY, paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.textSize = 14f
        canvas.drawText(channel.label, left + 10f, top + 22f, paint)
        canvas.drawText("${(value * 100f).toInt()}% / ${(threshold * 100f).toInt()}%", left + 10f, top + height - 12f, paint)
    }

    private fun detectionColor(value: Float): Int {
        val t = value.coerceIn(0f, 1f)
        return when {
            t < 0.33f -> {
                val k = t / 0.33f
                Color.rgb((20 + 30 * k).toInt(), (40 + 80 * k).toInt(), (80 + 100 * k).toInt())
            }
            t < 0.66f -> {
                val k = (t - 0.33f) / 0.33f
                Color.rgb((50 + 180 * k).toInt(), (120 + 100 * k).toInt(), (180 - 100 * k).toInt())
            }
            else -> {
                val k = (t - 0.66f) / 0.34f
                Color.rgb((230 + 25 * k).toInt(), (220 - 180 * k).toInt(), (80 - 60 * k).toInt())
            }
        }
    }
}
