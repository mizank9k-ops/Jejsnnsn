package com.atomicworld.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

class EyeBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {
    @Volatile var leftLevel = 0f
    @Volatile var rightLevel = 0f
    @Volatile var threshold = 0.2f
    @Volatile var modelName = "EYE MODEL"
    private var running = false
    private var thread: Thread? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init { holder.addCallback(this) }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this, "eye-board").also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join(300)
        thread = null
    }

    override fun run() {
        while (running) {
            val canvas = holder.lockCanvas()
            if (canvas != null) {
                try { drawBoard(canvas) } finally { holder.unlockCanvasAndPost(canvas) }
            }
            Thread.sleep(33)
        }
    }

    private fun drawBoard(canvas: Canvas) {
        val width = canvas.width.toFloat()
        val height = canvas.height.toFloat()
        canvas.drawColor(Color.rgb(10, 18, 28))
        paint.style = Paint.Style.FILL
        paint.color = Color.CYAN
        paint.textSize = 24f
        canvas.drawText("EYE BOARD  $modelName", 12f, 28f, paint)
        drawEye(canvas, width * 0.31f, height * 0.55f, leftLevel, "L")
        drawEye(canvas, width * 0.69f, height * 0.55f, rightLevel, "R")
    }

    private fun drawEye(canvas: Canvas, x: Float, y: Float, level: Float, label: String) {
        val value = level.coerceIn(0f, 1f)
        paint.color = if (value >= threshold) Color.rgb(255, 193, 7) else Color.rgb(0, 188, 212)
        paint.style = Paint.Style.FILL
        canvas.drawCircle(x, y, 18f + value * 18f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.WHITE
        canvas.drawCircle(x, y, 24f, paint)
        paint.style = Paint.Style.FILL
        paint.textSize = 20f
        canvas.drawText("EYE-$label ${(value * 100).toInt()}%", x - 38f, y + 48f, paint)
    }
}
