package com.atomicworld.app

object NativeBridge {
    init {
        System.loadLibrary("atomicworld")
    }

    external fun nativeInit()
    external fun nativeRelease()
    external fun nativeProcess(left: FloatArray, right: FloatArray, frames: Int)
    external fun getVulkanAvailable(): Boolean

    // AtomSpare Speed
    external fun setAtomSpareSpeed(v: Float)
    external fun setAtomSpareSpeedEnabled(v: Boolean)
    external fun setAtomSpareSpeedThreshold(v: Float)
    external fun setAtomSpareSpeedBoost(v: Float)
    external fun getAtomSpareSpeed(): Float
    external fun getAtomSpareSpeedThreshold(): Float
    external fun getAtomSpareSpeedBoost(): Float
    external fun setAtomSpaceCurvature(v: Float)
    external fun setAtomSpaceCurvatureThreshold(v: Float)
    external fun getAtomSpaceCurvature(): Float
    external fun getAtomSpaceCurvatureThreshold(): Float

    // AtomSpare Move
    external fun setAtomSpareMove(v: Float)
    external fun setAtomSpareMoveEnabled(v: Boolean)
    external fun getAtomSpareMove(): Float

    // AtomSpare Wave
    external fun setAtomSpareWave(v: Float)
    external fun setAtomSpareWaveEnabled(v: Boolean)
    external fun getAtomSpareWave(): Float

    // WaveSpare Speed / Wave
    external fun setWaveSpareSpeed(v: Float)
    external fun setWaveSpareSpeedEnabled(v: Boolean)
    external fun setWaveSpareWave(v: Float)
    external fun setWaveSpareWaveEnabled(v: Boolean)
    external fun setWaveSpareMovement(v: Float)
    external fun setWaveSpareThreshold(v: Float)
    external fun setWaveSpareBipolarDb(v: Float)
    external fun setVirtualSpeedCapEnabled(v: Boolean)
    external fun setVirtualSpeedCapMultiplier(v: Float)
    external fun getVirtualSpeedCapEnabled(): Boolean
    external fun getVirtualSpeedCapMultiplier(): Float
    external fun setMicIntensityEnabled(v: Boolean)
    external fun setMicIntensityBias(v: Float)
    external fun setMicIntensityThreshold(v: Float)
    external fun getMicIntensityEnabled(): Boolean
    external fun getMicIntensityBias(): Float
    external fun getMicIntensityThreshold(): Float
    external fun getMicIntensity(): Float
    external fun getMicIntensityRaw(): Float
    external fun getMicIntensityConfidence(): Float
    external fun getWaveSpareSpeed(): Float
    external fun getWaveSpareWave(): Float
    external fun getWaveSpareMovement(): Float
    external fun getWaveSpareThreshold(): Float
    external fun getWaveSpareBipolarDb(): Float
    external fun getWaveSpareLevel(): Float
    external fun getWaveSpareActive(): Boolean
    external fun setWaveSpaceCurvature(v: Float)
    external fun setWaveSpaceCurvatureThreshold(v: Float)
    external fun getWaveSpaceCurvature(): Float
    external fun getWaveSpaceCurvatureThreshold(): Float

    // Wave Speed and Smooth
    external fun setWaveSpeed(v: Float)
    external fun setWaveSmooth(v: Float)
    external fun getWaveSpeed(): Float
    external fun getWaveSmooth(): Float

    // Ambient live analysis and locked thresholds
    external fun setAmbientAnalysisEnabled(v: Boolean)
    external fun setAtomSpareAmbientThreshold(v: Float)
    external fun setWaveSpareAmbientThreshold(v: Float)
    external fun setAmbientThresholdLocked(v: Boolean)
    external fun getAmbientAnalysisEnabled(): Boolean
    external fun setAmbientMotionThreshold(v: Float)
    external fun setAmbientSpeedThreshold(v: Float)
    external fun setAmbientWaveThreshold(v: Float)
    external fun setAmbientMotionGateEnabled(v: Boolean)
    external fun setAmbientSpeedGateEnabled(v: Boolean)
    external fun setAmbientWaveGateEnabled(v: Boolean)
    external fun getAmbientMotionThreshold(): Float
    external fun getAmbientSpeedThreshold(): Float
    external fun getAmbientWaveThreshold(): Float
    external fun getAtomSpareAmbientThreshold(): Float
    external fun getWaveSpareAmbientThreshold(): Float
    external fun getAmbientThresholdLocked(): Boolean
    external fun setAtomAmbientThresholdLocked(v: Boolean)
    external fun setWaveAmbientThresholdLocked(v: Boolean)
    external fun getAtomAmbientThresholdLocked(): Boolean
    external fun getWaveAmbientThresholdLocked(): Boolean
    external fun getAtomAmbientActive(): Boolean
    external fun getWaveAmbientActive(): Boolean
    external fun getAmbientLevel(): Float
    external fun setAmbientThresholdLevel(v: Float)
    external fun getAmbientThresholdLevel(): Float
    external fun setAmbientBipolarThreshold(v: Float)
    external fun getAmbientBipolarThreshold(): Float
    external fun getAmbientRms(): Float
    external fun getAmbientFftLevel(): Float
    external fun getAmbientDb(): Float
    external fun getBodyOutput(): Float
    external fun setAmplifierEnabled(v: Boolean)
    external fun setAmplifierLevel(v: Float)
    external fun setAmplifierGain(v: Float)
    external fun setAmplifierThreshold(v: Float)
    external fun getAmplifierEnabled(): Boolean
    external fun getAmplifierLevel(): Float
    external fun getAmplifierGain(): Float
    external fun getAmplifierThreshold(): Float
    external fun getDominantHz(): Float
    external fun getSpectralCentroidHz(): Float
    external fun getDominantHzCounter(): Int
    external fun getSpectralCentroidCounter(): Int
    external fun getSpikeOutput(): Float
    external fun getSpikeCount(): Int
    external fun getSilenceActive(): Boolean
    external fun getBrainWaveOutput(): Float
    external fun setSpikeThreshold(v: Float)
    external fun getSpikeThreshold(): Float
    external fun setSilenceThreshold(v: Float)
    external fun getSilenceThreshold(): Float
    external fun setMicrophoneEnabled(v: Boolean)
    external fun setMicrophoneGain(v: Float)
    external fun getMicrophoneEnabled(): Boolean
    external fun getMicrophoneGain(): Float
    external fun getRawMicRms(): Float
    external fun getRawMicPeak(): Float
    external fun setAmbientSpaceCurvature(v: Float)
    external fun setAmbientSpaceCurvatureThreshold(v: Float)
    external fun getAmbientSpaceCurvature(): Float
    external fun getAmbientSpaceCurvatureThreshold(): Float
    external fun getBipolarDb(): Float
    external fun getPitchHz(): Float
    external fun getThresholdedPitchHz(): Float
    external fun getThresholdedPitchDb(): Float
    external fun setPitchOutputThreshold(v: Float)
    external fun setPitchOutputLevel(v: Float)
    external fun getPitchOutputThreshold(): Float
    external fun getPitchOutputLevel(): Float
    external fun setDominantThreshold(v: Float)
    external fun setDominantLevel(v: Float)
    external fun getDominantThreshold(): Float
    external fun getDominantLevel(): Float
    external fun setCentroidThreshold(v: Float)
    external fun setCentroidLevel(v: Float)
    external fun getCentroidThreshold(): Float
    external fun getCentroidLevel(): Float
    external fun setSpectrumBipolarThreshold(v: Float)
    external fun getSpectrumBipolarThreshold(): Float
    external fun getSilenceLevel(): Float
    external fun setArgumentThreshold(v: Float)
    external fun getArgumentThreshold(): Float
    external fun getArgumentActive(): Boolean
    external fun setDbThreshold(v: Float)
    external fun getDbThreshold(): Float
    external fun setWarpThreshold(v: Float)
    external fun setStutterThreshold(v: Float)
    external fun setWarpBipolarThreshold(v: Float)
    external fun setStutterBipolarThreshold(v: Float)
    external fun getWarpThreshold(): Float
    external fun getStutterThreshold(): Float
    external fun getWarpBipolarThreshold(): Float
    external fun getStutterBipolarThreshold(): Float
    external fun getWarpHz(): Float
    external fun getStutterHz(): Float
    external fun getWarpDb(): Float
    external fun getStutterDb(): Float
    external fun getWarpRaw(): Float
    external fun getStutterRaw(): Float
    external fun getWarpBipolar(): Float
    external fun getStutterBipolar(): Float
    external fun getWarpCounter(): Int
    external fun getStutterCounter(): Int
    external fun getWarpDirection(): Int
    external fun getStutterDirection(): Int
    external fun getWarpDirectionUpCounter(): Int
    external fun getWarpDirectionDownCounter(): Int
    external fun getStutterDirectionUpCounter(): Int
    external fun getStutterDirectionDownCounter(): Int
    external fun getPitchThresholdEvents(): Int
    external fun setInnerVoiceMaskEnabled(v: Boolean)
    external fun setInnerVoiceMaskGain(v: Float)
    external fun setInnerVoiceMaskThreshold(v: Float)
    external fun setLoudSpeechMaskEnabled(v: Boolean)
    external fun setLoudSpeechMaskGain(v: Float)
    external fun setLoudSpeechMaskThreshold(v: Float)
    external fun getInnerVoiceMaskActive(): Boolean
    external fun getLoudSpeechMaskActive(): Boolean
    external fun setAmbientKillEnabled(v: Boolean)
    external fun setAmbientShiftEnabled(v: Boolean)
    external fun setPeakLimiterDb(v: Float)
    external fun setPeakLimiterRatio(v: Float)
    external fun getPeakHoldDb(): Float
    external fun getPeakLimiterReductionDb(): Float
    external fun getAmbientKillActive(): Boolean
    external fun getAmbientShiftActive(): Boolean
    external fun setAntiAmbianceEnabled(v: Boolean)
    external fun setAtmosphereMode(v: Int)
    external fun setIntentionGateThreshold(v: Float)
    external fun setImaginationSpaceIntensity(v: Float)
    external fun setIntentionLowHz(v: Float)
    external fun setIntentionHighHz(v: Float)
    external fun setGateAttackMs(v: Float)
    external fun setGateReleaseMs(v: Float)
    external fun getAntiAmbianceEnabled(): Boolean
    external fun getAtmosphereMode(): Int
    external fun getIntentionGateThreshold(): Float
    external fun getImaginationSpaceIntensity(): Float
    external fun getIntentionLowHz(): Float
    external fun getIntentionHighHz(): Float
    external fun getGateAttackMs(): Float
    external fun getGateReleaseMs(): Float
    external fun getIntentionLevel(): Float
    external fun getGateAmount(): Float
    external fun getIntentionGateOpen(): Boolean
    external fun getEyeLeftLevel(): Float
    external fun getEyeRightLevel(): Float
    external fun getEyeVisionThreshold(): Float
    external fun setEyePingPongEnabled(v: Boolean)
    external fun setEyePingPongLevel(v: Float)
    external fun setEyeBipolarDb(v: Float)
    external fun setEyeAmbientThreshold(v: Float)
    external fun getEyePingPongLevel(): Float
    external fun getEyeBipolarDb(): Float
    external fun getEyeAmbientThreshold(): Float
    external fun getEyeLeftPitch(): Float
    external fun getEyeRightPitch(): Float
    external fun setAdvancedValue(control: Int, value: Float)
    external fun setAdvancedEnabled(control: Int, enabled: Boolean)

    // Resonance / Robotic Modes
    external fun setResonanceModeEnabled(v: Boolean)
    external fun setResonanceStrength(v: Float)
    external fun getResonanceModeEnabled(): Boolean
    external fun getResonanceStrength(): Float

    external fun setRoboticModeEnabled(v: Boolean)
    external fun setRoboticBias(v: Float)
    external fun getRoboticModeEnabled(): Boolean
    external fun getRoboticBias(): Float

    // Energies
    external fun getSpeedEnergy(): Float
    external fun getMoveEnergy(): Float
    external fun getWaveEnergy(): Float
    external fun getAtomMoveEnergy(): Float
    external fun getAtomWaveEnergy(): Float
    external fun getWaveSpareSpeedOutput(): Float
    external fun getWaveSpareMoveOutput(): Float
    external fun getWaveSpareWaveOutput(): Float
    external fun getThresholdedMovementOutput(): Float
    external fun getThresholdedMovementLevel(): Float
    external fun getThresholdedMovementThreshold(): Float
    external fun getThresholdedSpeedOutput(): Float
    external fun getThresholdedSpeedLevel(): Float
    external fun getThresholdedSpeedThreshold(): Float
    external fun getThresholdedWaveOutput(): Float
    external fun getThresholdedWaveLevel(): Float
    external fun getThresholdedWaveThreshold(): Float
    external fun getCommunicationGateEnabled(): Boolean
    external fun getCommunicationGateBlocked(): Boolean
    external fun getCommunicationGateState(): Int
    external fun getPitchSpeedOutput(): Float
    external fun getPitchMovementOutput(): Float
    external fun getPitchWaveOutput(): Float
    external fun getAtomSpareSpeedLeft(): Float
    external fun getAtomSpareSpeedRight(): Float
    external fun getAtomSpareMoveLeft(): Float
    external fun getAtomSpareMoveRight(): Float
    external fun getAtomSpareWaveLeft(): Float
    external fun getAtomSpareWaveRight(): Float
    external fun getWarpLeft(): Float
    external fun getWarpRight(): Float
    external fun getWarpCenter(): Float
    external fun getStutterLeft(): Float
    external fun getStutterRight(): Float
    external fun getStutterCenter(): Float
    external fun getMotionPitchLeftProtection(): Float
    external fun getMotionPitchRightProtection(): Float
    external fun getMotionPitchSpeedProtection(): Float
    external fun getMotionPitchMovementProtection(): Float
    external fun getMotionPitchWaveProtection(): Float
    external fun getEyeLeftProtection(): Float
    external fun getEyeRightProtection(): Float
    external fun setMotionPitchProtectionEnabled(v: Boolean)
    external fun setMotionPitchThreshold(v: Float)
    external fun setMotionPitchSpeedThreshold(v: Float)
    external fun setMotionPitchMovementThreshold(v: Float)
    external fun setMotionPitchWaveThreshold(v: Float)
    external fun setEnemyCurveThreshold(v: Float)
    external fun setEnemyPlaneThreshold(v: Float)
    external fun setEnemyWallThreshold(v: Float)
    external fun setEnemyRingThreshold(v: Float)
    external fun getEnemyCurveThreshold(): Float
    external fun getEnemyPlaneThreshold(): Float
    external fun getEnemyWallThreshold(): Float
    external fun getEnemyRingThreshold(): Float

    // Body zones
    external fun getHeadZone(): Float
    external fun getChestZone(): Float
    external fun getAbdomenZone(): Float
    external fun getLeftArmZone(): Float
    external fun getRightArmZone(): Float
    external fun getLeftLegZone(): Float
    external fun getRightLegZone(): Float
    external fun setBodyAmbientThreshold(index: Int, value: Float)
    external fun getBodyAmbientThreshold(index: Int): Float
    external fun getBodyAmbientLevel(index: Int): Float
    external fun getBodyAmbientBipolarDb(index: Int): Float
    external fun getBodyAmbientCounter(index: Int): Int
    external fun setBodyEnemyProtectionEnabled(value: Boolean)
    external fun setBodyEnemyMovementThreshold(value: Float)
    external fun getBodyEnemyProtectionActive(): Boolean
    external fun setBodyInsideThreshold(value: Float)
    external fun setBodyOutsideThreshold(value: Float)
    external fun setBodyInsideProtectionEnabled(value: Boolean)
    external fun setBodyOutsideProtectionEnabled(value: Boolean)
    external fun getBodyInsideProtectionActive(): Boolean
    external fun getBodyOutsideProtectionActive(): Boolean

    // Echo with Protection and Smoothing
    external fun setEchoEnabled(v: Boolean)
    external fun setEchoDelayMs(v: Float)
    external fun setEchoFeedback(v: Float)
    external fun setEchoMix(v: Float)
    external fun setEchoProtectionEnabled(v: Boolean)
    external fun setEchoSmoothingFactor(v: Float)
    external fun getEchoProtectionActive(): Boolean

    // Global Effects
    external fun setGlobalEffectsEnabled(v: Boolean)
    external fun setGlobalEffectsMix(v: Float)
    external fun getGlobalEffectsEnabled(): Boolean

    // Audio Generation (Atomic Sounds)
    external fun setAudioGenerationEnabled(v: Boolean)
    external fun setAudioGenSpeed(v: Float)
    external fun setAudioGenDensity(v: Float)
    external fun generateAtomicSound(frequency: Float, duration: Int): ByteArray

    // Protection and Blocking
    external fun setProtectionBlockEnabled(v: Boolean)
    external fun setThresholdValue(v: Float)
    external fun setBlockingMode(mode: Int)  // 0=off, 1=soft, 2=hard
    external fun getProtectionActive(): Boolean
    external fun getThresholdViolations(): Int

    // Communication Threshold
    external fun setCommunicationThreshold(v: Float)
    external fun setThresholdCommunicationBlockEnabled(v: Boolean)
    external fun getThresholdCommunicationStatus(): Int
    external fun setEnemyProtectionEnabled(v: Boolean)
    external fun setEnemyAmbientThreshold(v: Float)
    external fun setEnemyAmbientThresholdLocked(v: Boolean)
    external fun getEnemyAmbientThresholdLocked(): Boolean
    external fun setEnemyMovementThreshold(v: Float)
    external fun setEnemySpeedThreshold(v: Float)
    external fun setEnemyWaveThreshold(v: Float)
    external fun getEnemyMovementThreshold(): Float
    external fun getEnemySpeedThreshold(): Float
    external fun getEnemyWaveThreshold(): Float
    external fun setEnemyPitchThreshold(v: Float)
    external fun setEnemyCommunicationThreshold(v: Float)
    external fun setEnemySpeakerThreshold(v: Float)
    external fun setEnemyHardBlock(v: Boolean)
    external fun getEnemyProtectionActive(): Boolean
    external fun getEnemyProtectionStatus(): Int
    external fun getEnemyAmbientSignalHold(): Boolean
}