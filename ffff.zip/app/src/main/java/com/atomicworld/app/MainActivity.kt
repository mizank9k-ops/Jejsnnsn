package com.atomicworld.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioAttributes
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.SeekBar
import android.widget.AdapterView
import android.widget.Button
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val SENSOR_PERMISSION_REQUEST = 1003
    }

    private lateinit var bodyView: BodyDiagramView
    private lateinit var speedWave: WaveSurfaceView
    private lateinit var moveWave: WaveSurfaceView
    private lateinit var waveWave: WaveSurfaceView
    private lateinit var eyeBoard: EyeBoardView
    private lateinit var motionBoard: MotionBoardView
    private lateinit var arCameraView: ArCameraView
    private lateinit var arStatus: TextView
    private lateinit var modelStatus: TextView
    private lateinit var sensorTelemetry: SensorTelemetry
    private lateinit var modelRuntime: ModelRuntime
    private lateinit var rawFeatureBoard: RawFeatureBoardView

    private var waveSpeedEnabled = true
    private val handler = Handler(Looper.getMainLooper())
    private var micThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private var micRunning = false
    private var processedMonitorEnabled = false
    private var audioTrack: AudioTrack? = null
    private var movementSpeedControl = 0.5f
    private var framesThisSecond = 0
    private var fpsWindowStart = 0L
    private var liveFps = 0
    private val rawFeatureRows = mutableListOf<RawFeatureRow>()
    private val spatialDirectionRows = mutableListOf<SpatialDirectionRow>()
    private val directionValues = mutableMapOf<String, Float>()
    private val directionCounters = mutableMapOf<String, Int>()
    private var lastRawTelemetryUpdateMs = 0L

    private data class RawFeatureRow(
        val name: String,
        val provider: () -> Float,
        val output: TextView,
        val level: SeekBar,
        val threshold: SeekBar,
        val bipolarThreshold: SeekBar,
        val counter: () -> Int = { 0 }
    )

    private data class SpatialDirectionRow(
        val name: String,
        val provider: () -> Float,
        val output: TextView,
        val threshold: SeekBar
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NativeBridge.nativeInit()
        sensorTelemetry = SensorTelemetry(this)
        modelRuntime = ModelRuntime(this)

        arCameraView = findViewById(R.id.arCameraView)
        arCameraView.modelRuntime = modelRuntime
        bindCameraAdvancedControls()
        bindCameraVisualEnhancements()
        arStatus = findViewById(R.id.txtArStatus)
        modelStatus = findViewById(R.id.txtModelStatus)
        modelStatus.text = "${ModelRegistry.summary(this)} | ${modelRuntime.status}"
        bindSensorControls()
        val cameraThresholdSeek = findViewById<SeekBar>(R.id.seekCameraThreshold)
        val cameraThresholdText = findViewById<TextView>(R.id.txtCameraThreshold)
        val argumentThresholdSeek = findViewById<SeekBar>(R.id.seekArgumentThreshold)
        val argumentThresholdText = findViewById<TextView>(R.id.txtArgumentThreshold)
        val argumentThreshold = NativeBridge.getArgumentThreshold()
        argumentThresholdSeek.progress = (argumentThreshold * 100f).toInt()
        argumentThresholdText.text = "${(argumentThreshold * 100f).toInt()}%"
        argumentThresholdSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setArgumentThreshold(value)
            argumentThresholdText.text = "${(value * 100f).toInt()}%"
        })
        val colorThresholdSeek = findViewById<SeekBar>(R.id.seekColorThreshold)
        val colorThresholdText = findViewById<TextView>(R.id.txtColorThreshold)
        colorThresholdSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            arCameraView.colorThreshold = value
            colorThresholdText.text = "${(value * 100f).toInt()}%"
        })
        findViewById<Switch>(R.id.switchColorProtection).setOnCheckedChangeListener { _, enabled ->
            arCameraView.visualProtectionEnabled = enabled
        }
        findViewById<Switch>(R.id.switchAntiVisualProtection).setOnCheckedChangeListener { _, enabled ->
            arCameraView.antiVisualProtectionEnabled = enabled
        }
        findViewById<Switch>(R.id.switchVhsTracking).setOnCheckedChangeListener { _, enabled ->
            arCameraView.vhsTrackingEnabled = enabled
        }
        bindCurvature(R.id.seekVhsThreshold, R.id.txtVhsThreshold, 0.5f) {
            arCameraView.vhsTrackingThreshold = it
        }
        findViewById<Switch>(R.id.switchCameraTransmission).setOnCheckedChangeListener { _, enabled ->
            arCameraView.transmissionEnabled = enabled
        }
        val keystoneSeek = findViewById<SeekBar>(R.id.seekKeystone)
        val keystoneText = findViewById<TextView>(R.id.txtKeystone)
        keystoneSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress / 100f - 1f
                arCameraView.keystoneAmount = value
                keystoneText.text = "${(value * 100f).toInt()}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        val edShowMotionSeek = findViewById<SeekBar>(R.id.seekEdShowMotion)
        val edShowMotionText = findViewById<TextView>(R.id.txtEdShowMotion)
        edShowMotionSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            arCameraView.edShowMotion = value
            edShowMotionText.text = "${(value * 100f).toInt()}%"
        })
        val edShowSpeedSeek = findViewById<SeekBar>(R.id.seekEdShowSpeed)
        val edShowSpeedText = findViewById<TextView>(R.id.txtEdShowSpeed)
        edShowSpeedSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            arCameraView.edShowSpeed = value
            edShowSpeedText.text = "${(value * 100f).toInt()}%"
        })
        cameraThresholdSeek.progress = 50
        arCameraView.cameraThreshold = 0.5f
        cameraThresholdSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            arCameraView.cameraThreshold = value
            cameraThresholdText.text = "${(value * 100).toInt()}%"
        })
        findViewById<Spinner>(R.id.spinnerCameraFilter).onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                arCameraView.filterMode = position
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        bodyView = findViewById(R.id.bodyDiagram)
        bodyView.eyeModelName = BuildConfig.EYE_MODEL
        speedWave = findViewById(R.id.speedWaveView)
        moveWave = findViewById(R.id.moveWaveView)
        waveWave = findViewById(R.id.waveWaveView)
        eyeBoard = findViewById(R.id.eyeBoardView)
        motionBoard = findViewById(R.id.motionBoardView)
        eyeBoard.modelName = "${BuildConfig.EYE_MODEL}/${BuildConfig.VISUAL_MODEL}"
        motionBoard.modelName = "${BuildConfig.SIGNAL_MODEL}/${BuildConfig.INTENSITY_MODEL}"
        bindMotionBoardControls()
        bindVirtualAtomSpareControls()
        bindRawFeatureTelemetry()
        bindSpatialDirectionControls()

        speedWave.label = "SPEED"
        moveWave.label = "MOVE"
        waveWave.label = "WAVE"

        // ===== AtomSpare Speed =====
        val switchSpeed = findViewById<Switch>(R.id.switchSpeed)
        val seekSpeed = findViewById<SeekBar>(R.id.seekSpeed)
        val txtSpeed = findViewById<TextView>(R.id.txtSpeedValue)

        switchSpeed.isChecked = true
        NativeBridge.setAtomSpareSpeedEnabled(true)
        seekSpeed.progress = 50
        NativeBridge.setAtomSpareSpeed(0.5f)
        txtSpeed.text = "50%"

        switchSpeed.setOnCheckedChangeListener { _, checked ->
            NativeBridge.setAtomSpareSpeedEnabled(checked)
        }
        seekSpeed.setOnSeekBarChangeListener(simpleSeek { v ->
            NativeBridge.setAtomSpareSpeed(v)
            txtSpeed.text = "${(v * 100).toInt()}%"
        })

        // ===== AtomSpare Speed Threshold =====
        try {
            val seekSpeedThreshold = findViewById<SeekBar>(R.id.seekSpeedThreshold)
            val txtSpeedThreshold = findViewById<TextView>(R.id.txtSpeedThresholdValue)

            seekSpeedThreshold?.progress = 30
            NativeBridge.setAtomSpareSpeedThreshold(0.3f)
            txtSpeedThreshold?.text = "30%"

            seekSpeedThreshold?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setAtomSpareSpeedThreshold(v)
                txtSpeedThreshold?.text = "${(v * 100).toInt()}%"
            })
        } catch (_: Exception) {}

        // ===== AtomSpare Speed Boost (More Control) =====
        try {
            val seekSpeedBoost = findViewById<SeekBar>(R.id.seekSpeedBoost)
            val txtSpeedBoost = findViewById<TextView>(R.id.txtSpeedBoostValue)

            seekSpeedBoost?.progress = 50
            NativeBridge.setAtomSpareSpeedBoost(1.0f)
            txtSpeedBoost?.text = "1.0x"

            seekSpeedBoost?.setOnSeekBarChangeListener(simpleSeek { v ->
                val boostVal = 1.0f + (v * 1.0f)
                NativeBridge.setAtomSpareSpeedBoost(boostVal)
                txtSpeedBoost?.text = "${"%.1f".format(boostVal)}x"
            })
        } catch (_: Exception) {}

        // ===== AtomSpare Move =====
        val switchMove = findViewById<Switch>(R.id.switchMove)
        val seekMove = findViewById<SeekBar>(R.id.seekMove)
        val txtMove = findViewById<TextView>(R.id.txtMoveValue)

        switchMove.isChecked = true
        NativeBridge.setAtomSpareMoveEnabled(true)
        seekMove.progress = 50
        NativeBridge.setAtomSpareMove(0.5f)
        txtMove.text = "50%"

        switchMove.setOnCheckedChangeListener { _, checked ->
            NativeBridge.setAtomSpareMoveEnabled(checked)
        }
        seekMove.setOnSeekBarChangeListener(simpleSeek { v ->
            NativeBridge.setAtomSpareMove(v)
            txtMove.text = "${(v * 100).toInt()}%"
        })

        // ===== AtomSpare Wave =====
        val switchWave = findViewById<Switch>(R.id.switchWave)
        val seekWave = findViewById<SeekBar>(R.id.seekWave)
        val txtWave = findViewById<TextView>(R.id.txtWaveValue)

        switchWave.isChecked = true
        NativeBridge.setAtomSpareWaveEnabled(true)
        seekWave.progress = 50
        NativeBridge.setAtomSpareWave(0.5f)
        txtWave.text = "50%"

        switchWave.setOnCheckedChangeListener { _, checked ->
            NativeBridge.setAtomSpareWaveEnabled(checked)
        }
        seekWave.setOnSeekBarChangeListener(simpleSeek { v ->
            NativeBridge.setAtomSpareWave(v)
            txtWave.text = "${(v * 100).toInt()}%"
        })

        // ===== WaveSpare Speed / Wave =====
        val switchWaveSpareSpeed = findViewById<Switch>(R.id.switchWaveSpareSpeed)
        val seekWaveSpareSpeed = findViewById<SeekBar>(R.id.seekWaveSpareSpeed)
        val txtWaveSpareSpeed = findViewById<TextView>(R.id.txtWaveSpareSpeed)
        val switchWaveSpareWave = findViewById<Switch>(R.id.switchWaveSpareWave)
        val seekWaveSpareWave = findViewById<SeekBar>(R.id.seekWaveSpareWave)
        val txtWaveSpareWave = findViewById<TextView>(R.id.txtWaveSpareWave)
        val seekWaveSpareMovement = findViewById<SeekBar>(R.id.seekWaveSpareMovement)
        val txtWaveSpareMovement = findViewById<TextView>(R.id.txtWaveSpareMovement)
        val seekWaveSpareThreshold = findViewById<SeekBar>(R.id.seekWaveSpareThreshold)
        val txtWaveSpareThreshold = findViewById<TextView>(R.id.txtWaveSpareThreshold)
        val seekWaveSpareBipolar = findViewById<SeekBar>(R.id.seekWaveSpareBipolarDb)
        val txtWaveSpareBipolar = findViewById<TextView>(R.id.txtWaveSpareBipolarDb)

        switchWaveSpareSpeed.isChecked = true
        switchWaveSpareWave.isChecked = true
        seekWaveSpareSpeed.progress = 50
        seekWaveSpareWave.progress = 50
        seekWaveSpareThreshold.progress = 30
        seekWaveSpareBipolar.progress = 100
        NativeBridge.setWaveSpareSpeedEnabled(true)
        NativeBridge.setWaveSpareWaveEnabled(true)
        NativeBridge.setWaveSpareSpeed(0.5f)
        NativeBridge.setWaveSpareWave(0.5f)
        NativeBridge.setWaveSpareMovement(0.5f)
        NativeBridge.setWaveSpareThreshold(0.3f)
        NativeBridge.setWaveSpareBipolarDb(0.0f)
        txtWaveSpareSpeed.text = "50%"
        txtWaveSpareWave.text = "50%"
        txtWaveSpareMovement.text = "50%"
        txtWaveSpareThreshold.text = "30%"
        txtWaveSpareBipolar.text = "0dB"
        switchWaveSpareSpeed.setOnCheckedChangeListener { _, enabled -> NativeBridge.setWaveSpareSpeedEnabled(enabled) }
        switchWaveSpareWave.setOnCheckedChangeListener { _, enabled -> NativeBridge.setWaveSpareWaveEnabled(enabled) }
        seekWaveSpareSpeed.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareSpeed(value)
            txtWaveSpareSpeed.text = "${(value * 100).toInt()}%"
        })
        seekWaveSpareWave.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareWave(value)
            txtWaveSpareWave.text = "${(value * 100).toInt()}%"
        })
        seekWaveSpareMovement.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareMovement(value)
            txtWaveSpareMovement.text = "${(value * 100).toInt()}%"
        })
        seekWaveSpareThreshold.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareThreshold(value)
            txtWaveSpareThreshold.text = "${(value * 100).toInt()}%"
        })
        seekWaveSpareBipolar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val db = progress * 10f - 1000f
                NativeBridge.setWaveSpareBipolarDb(db)
                txtWaveSpareBipolar.text = "${db.toInt()}dB"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        // ===== Wave Speed and Smooth =====
        try {
            val switchWaveSpeed = findViewById<Switch>(R.id.switchWaveSpeed)
            val seekWaveSpeed = findViewById<SeekBar>(R.id.seekWaveSpeed)
            val txtWaveSpeed = findViewById<TextView>(R.id.txtWaveSpeedValue)
            
            switchWaveSpeed?.isChecked = true
            seekWaveSpeed?.progress = 50
            NativeBridge.setWaveSpeed(0.5f)
            txtWaveSpeed?.text = "50%"
            
            switchWaveSpeed?.setOnCheckedChangeListener { _, checked ->
                waveSpeedEnabled = checked
                if (!checked) {
                    NativeBridge.setWaveSpeed(0f)
                }
            }
            seekWaveSpeed?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setWaveSpeed(v)
                if (waveSpeedEnabled) {
                    speedWave.animationSpeed = v
                }
                txtWaveSpeed?.text = "${(v * 100).toInt()}%"
            })

            val seekWaveSmooth = findViewById<SeekBar>(R.id.seekWaveSmooth)
            val txtWaveSmooth = findViewById<TextView>(R.id.txtWaveSmoothValue)
            
            seekWaveSmooth?.progress = 60
            NativeBridge.setWaveSmooth(0.6f)
            txtWaveSmooth?.text = "60%"
            
            seekWaveSmooth?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setWaveSmooth(v)
                speedWave.smoothness = v
                txtWaveSmooth?.text = "${(v * 100).toInt()}%"
            })
        } catch (e: Exception) {
            // Wave speed UI elements may not be in layout yet
        }

        // ===== Echo with Protection and Smoothing =====
        try {
            val switchEcho = findViewById<Switch>(R.id.switchEcho)
            val switchEchoProtection = findViewById<Switch>(R.id.switchEchoProtection)
            val seekEchoSmoothing = findViewById<SeekBar>(R.id.seekEchoSmoothing)
            val txtEchoSmoothing = findViewById<TextView>(R.id.txtEchoSmoothingValue)
            
            switchEcho?.isChecked = true
            NativeBridge.setEchoEnabled(true)
            
            switchEcho?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setEchoEnabled(checked)
            }
            
            switchEchoProtection?.isChecked = true
            NativeBridge.setEchoProtectionEnabled(true)
            
            switchEchoProtection?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setEchoProtectionEnabled(checked)
            }
            
            seekEchoSmoothing?.progress = 50
            NativeBridge.setEchoSmoothingFactor(0.5f)
            txtEchoSmoothing?.text = "50%"
            
            seekEchoSmoothing?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setEchoSmoothingFactor(v)
                txtEchoSmoothing?.text = "${(v * 100).toInt()}%"
            })
        } catch (e: Exception) {
            // Echo UI elements may not be in layout yet
        }

        // ===== Resonance / Robotic =====
        try {
            val switchResonance = findViewById<Switch>(R.id.switchResonance)
            val seekResonance = findViewById<SeekBar>(R.id.seekResonance)
            val txtResonance = findViewById<TextView>(R.id.txtResonanceValue)
            val switchRobotic = findViewById<Switch>(R.id.switchRobotic)
            val seekRobotic = findViewById<SeekBar>(R.id.seekRobotic)
            val txtRobotic = findViewById<TextView>(R.id.txtRoboticValue)

            switchResonance?.isChecked = false
            NativeBridge.setResonanceModeEnabled(false)
            seekResonance?.progress = 45
            NativeBridge.setResonanceStrength(0.45f)
            txtResonance?.text = "45%"

            switchResonance?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setResonanceModeEnabled(checked)
            }
            seekResonance?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setResonanceStrength(v)
                txtResonance?.text = "${(v * 100).toInt()}%"
            })

            switchRobotic?.isChecked = false
            NativeBridge.setRoboticModeEnabled(false)
            seekRobotic?.progress = 50
            NativeBridge.setRoboticBias(0.5f)
            txtRobotic?.text = "50%"

            switchRobotic?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setRoboticModeEnabled(checked)
            }
            seekRobotic?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setRoboticBias(v)
                txtRobotic?.text = "${(v * 100).toInt()}%"
            })
        } catch (_: Exception) {
            // Resonance/robotic UI elements may not be in layout yet
        }

        // ===== Global Effects =====
        try {
            val switchGlobalEffects = findViewById<Switch>(R.id.switchGlobalEffects)
            val seekGlobalEffectsMix = findViewById<SeekBar>(R.id.seekGlobalEffectsMix)
            val txtGlobalEffectsMix = findViewById<TextView>(R.id.txtGlobalEffectsMixValue)
            
            switchGlobalEffects?.isChecked = false
            NativeBridge.setGlobalEffectsEnabled(false)
            
            switchGlobalEffects?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setGlobalEffectsEnabled(checked)
            }
            
            seekGlobalEffectsMix?.progress = 50
            NativeBridge.setGlobalEffectsMix(0.5f)
            txtGlobalEffectsMix?.text = "50%"
            
            seekGlobalEffectsMix?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setGlobalEffectsMix(v)
                txtGlobalEffectsMix?.text = "${(v * 100).toInt()}%"
            })
            findViewById<Switch>(R.id.switchProcessedMonitor)?.setOnCheckedChangeListener { _, enabled ->
                processedMonitorEnabled = enabled
                if (enabled && micRunning) startProcessedMonitor() else if (!enabled) stopProcessedMonitor()
            }
        } catch (e: Exception) {
            // Global effects UI elements may not be in layout yet
        }

        // ===== Audio Generation =====
        try {
            val switchAudioGen = findViewById<Switch>(R.id.switchAudioGen)
            val seekAudioGenSpeed = findViewById<SeekBar>(R.id.seekAudioGenSpeed)
            val txtAudioGenSpeed = findViewById<TextView>(R.id.txtAudioGenSpeedValue)
            val seekAudioGenDensity = findViewById<SeekBar>(R.id.seekAudioGenDensity)
            val txtAudioGenDensity = findViewById<TextView>(R.id.txtAudioGenDensityValue)
            
            switchAudioGen?.isChecked = false
            NativeBridge.setAudioGenerationEnabled(false)
            
            switchAudioGen?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setAudioGenerationEnabled(checked)
            }
            
            seekAudioGenSpeed?.progress = 50
            NativeBridge.setAudioGenSpeed(0.5f)
            txtAudioGenSpeed?.text = "50%"
            
            seekAudioGenSpeed?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setAudioGenSpeed(v)
                txtAudioGenSpeed?.text = "${(v * 100).toInt()}%"
            })
            
            seekAudioGenDensity?.progress = 40
            NativeBridge.setAudioGenDensity(0.4f)
            txtAudioGenDensity?.text = "40%"
            
            seekAudioGenDensity?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setAudioGenDensity(v)
                txtAudioGenDensity?.text = "${(v * 100).toInt()}%"
            })
        } catch (e: Exception) {
            // Audio generation UI elements may not be in layout yet
        }

        // ===== Protection and Blocking =====
        try {
            val switchProtection = findViewById<Switch>(R.id.switchProtection)
            val seekThreshold = findViewById<SeekBar>(R.id.seekThreshold)
            val txtThreshold = findViewById<TextView>(R.id.txtThresholdValue)
            val switchBlockingHard = findViewById<Switch>(R.id.switchBlockingHard)
            
            switchProtection?.isChecked = false
            NativeBridge.setProtectionBlockEnabled(false)
            
            switchProtection?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setProtectionBlockEnabled(checked)
            }
            
            seekThreshold?.progress = 60
            NativeBridge.setThresholdValue(0.6f)
            txtThreshold?.text = "60%"
            
            seekThreshold?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setThresholdValue(v)
                txtThreshold?.text = "${(v * 100).toInt()}%"
            })
            
            switchBlockingHard?.isChecked = false
            NativeBridge.setBlockingMode(if (switchBlockingHard?.isChecked == true) 2 else 1)
            
            switchBlockingHard?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setBlockingMode(if (checked) 2 else 1)
            }
        } catch (e: Exception) {
            // Protection UI elements may not be in layout yet
        }

        // ===== Communication Threshold =====
        try {
            val switchCommThreshold = findViewById<Switch>(R.id.switchCommThreshold)
            val seekCommThreshold = findViewById<SeekBar>(R.id.seekCommThreshold)
            val txtCommThreshold = findViewById<TextView>(R.id.txtCommThresholdValue)
            
            switchCommThreshold?.isChecked = true
            NativeBridge.setThresholdCommunicationBlockEnabled(true)
            
            switchCommThreshold?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setThresholdCommunicationBlockEnabled(checked)
            }
            
            seekCommThreshold?.progress = 55
            NativeBridge.setCommunicationThreshold(0.55f)
            txtCommThreshold?.text = "55%"
            
            seekCommThreshold?.setOnSeekBarChangeListener(simpleSeek { v ->
                NativeBridge.setCommunicationThreshold(v)
                txtCommThreshold?.text = "${(v * 100).toInt()}%"
            })
        } catch (e: Exception) {
            // Communication threshold UI elements may not be in layout yet
        }

        // ===== Ambient Live Analysis =====
        try {
            val switchAmbient = findViewById<Switch>(R.id.switchAmbientAnalysis)
            val seekAtomAmbient = findViewById<SeekBar>(R.id.seekAtomAmbientThreshold)
            val seekWaveAmbient = findViewById<SeekBar>(R.id.seekWaveAmbientThreshold)
            val switchAmbientLock = findViewById<Switch>(R.id.switchAmbientLock)
            val switchAtomAmbientLock = findViewById<Switch>(R.id.switchAtomAmbientLock)
            val switchWaveAmbientLock = findViewById<Switch>(R.id.switchWaveAmbientLock)
            val txtAmbientLockState = findViewById<TextView>(R.id.txtAmbientLockState)
            val txtAtomAmbient = findViewById<TextView>(R.id.txtAtomAmbientValue)
            val txtWaveAmbient = findViewById<TextView>(R.id.txtWaveAmbientValue)
            val seekAmbientLevel = findViewById<SeekBar>(R.id.seekAmbientThresholdLevel)
            val txtAmbientLevelThreshold = findViewById<TextView>(R.id.txtAmbientThresholdLevel)
            val seekAmbientBipolar = findViewById<SeekBar>(R.id.seekAmbientBipolarThreshold)
            val txtAmbientBipolar = findViewById<TextView>(R.id.txtAmbientBipolarThreshold)

            val prefs = getSharedPreferences("live_controls", MODE_PRIVATE)
            val ambientEnabled = prefs.getBoolean("ambient_enabled", true)
            val ambientLocked = prefs.getBoolean("ambient_locked", false)
            val atomLocked = prefs.getBoolean("atom_ambient_locked", ambientLocked)
            val waveLocked = prefs.getBoolean("wave_ambient_locked", ambientLocked)
            val atomThreshold = prefs.getFloat("atom_ambient_threshold", 0.30f)
            val waveThreshold = prefs.getFloat("wave_ambient_threshold", 0.30f)
            val ambientLevelThreshold = prefs.getFloat("ambient_threshold_level", 0.30f)
            val ambientBipolarThreshold = prefs.getFloat("ambient_bipolar_threshold", -120.0f)
            switchAmbient?.isChecked = ambientEnabled
            NativeBridge.setAmbientAnalysisEnabled(ambientEnabled)
            seekAtomAmbient?.progress = (atomThreshold * 100f).toInt()
            seekWaveAmbient?.progress = (waveThreshold * 100f).toInt()
            NativeBridge.setAmbientThresholdLocked(false)
            NativeBridge.setAtomSpareAmbientThreshold(atomThreshold)
            NativeBridge.setWaveSpareAmbientThreshold(waveThreshold)
            NativeBridge.setAmbientThresholdLevel(ambientLevelThreshold)
            NativeBridge.setAmbientBipolarThreshold(ambientBipolarThreshold)
            seekAmbientLevel?.progress = (ambientLevelThreshold * 100f).toInt()
            txtAmbientLevelThreshold?.text = "${(ambientLevelThreshold * 100f).toInt()}%"
            seekAmbientBipolar?.progress = (ambientBipolarThreshold + 120f).toInt()
            txtAmbientBipolar?.text = "${ambientBipolarThreshold.toInt()}dB"
            NativeBridge.setAtomAmbientThresholdLocked(atomLocked)
            NativeBridge.setWaveAmbientThresholdLocked(waveLocked)
            txtAtomAmbient?.text = "${(NativeBridge.getAtomSpareAmbientThreshold() * 100).toInt()}%"
            txtWaveAmbient?.text = "${(NativeBridge.getWaveSpareAmbientThreshold() * 100).toInt()}%"
            switchAmbientLock?.isChecked = ambientLocked
            switchAtomAmbientLock?.isChecked = atomLocked
            switchWaveAmbientLock?.isChecked = waveLocked
            seekAtomAmbient?.isEnabled = !atomLocked
            seekWaveAmbient?.isEnabled = !waveLocked
            txtAmbientLockState?.text = "ATOM ${if (atomLocked) "LOCKED" else "UNLOCKED"} | WAVE ${if (waveLocked) "LOCKED" else "UNLOCKED"}"

            switchAmbient?.setOnCheckedChangeListener { _, checked ->
                NativeBridge.setAmbientAnalysisEnabled(checked)
                prefs.edit().putBoolean("ambient_enabled", checked).apply()
            }
            seekAtomAmbient?.setOnSeekBarChangeListener(simpleSeek { value ->
                if (NativeBridge.getAtomAmbientThresholdLocked()) {
                    seekAtomAmbient.progress = (NativeBridge.getAtomSpareAmbientThreshold() * 100f).toInt()
                    return@simpleSeek
                }
                NativeBridge.setAtomSpareAmbientThreshold(value)
                prefs.edit().putFloat("atom_ambient_threshold", NativeBridge.getAtomSpareAmbientThreshold()).apply()
                txtAtomAmbient?.text = "${(NativeBridge.getAtomSpareAmbientThreshold() * 100).toInt()}%"
            })
            seekWaveAmbient?.setOnSeekBarChangeListener(simpleSeek { value ->
                if (NativeBridge.getWaveAmbientThresholdLocked()) {
                    seekWaveAmbient.progress = (NativeBridge.getWaveSpareAmbientThreshold() * 100f).toInt()
                    return@simpleSeek
                }
                NativeBridge.setWaveSpareAmbientThreshold(value)
                prefs.edit().putFloat("wave_ambient_threshold", NativeBridge.getWaveSpareAmbientThreshold()).apply()
                txtWaveAmbient?.text = "${(NativeBridge.getWaveSpareAmbientThreshold() * 100).toInt()}%"
            })
            seekAmbientLevel?.setOnSeekBarChangeListener(simpleSeek { value ->
                NativeBridge.setAmbientThresholdLevel(value)
                prefs.edit().putFloat("ambient_threshold_level", value).apply()
                txtAmbientLevelThreshold?.text = "${(value * 100f).toInt()}%"
            })
            seekAmbientBipolar?.setOnSeekBarChangeListener(simpleSeek { value ->
                val db = value * 120f - 120f
                NativeBridge.setAmbientBipolarThreshold(db)
                prefs.edit().putFloat("ambient_bipolar_threshold", db).apply()
                txtAmbientBipolar?.text = "${db.toInt()}dB"
            })
            switchAmbientLock?.setOnCheckedChangeListener { _, locked ->
                NativeBridge.setAmbientThresholdLocked(locked)
                prefs.edit().putBoolean("ambient_locked", locked).apply()
                seekAtomAmbient?.isEnabled = !locked
                seekWaveAmbient?.isEnabled = !locked
                txtAmbientLockState?.text = "ATOM ${if (locked) "LOCKED" else "UNLOCKED"} | WAVE ${if (locked) "LOCKED" else "UNLOCKED"}"
            }
            switchAtomAmbientLock?.setOnCheckedChangeListener { _, locked ->
                NativeBridge.setAtomAmbientThresholdLocked(locked)
                prefs.edit().putBoolean("atom_ambient_locked", locked).apply()
                seekAtomAmbient?.isEnabled = !locked
                txtAmbientLockState?.text = "ATOM ${if (locked) "LOCKED" else "UNLOCKED"} | WAVE ${if (NativeBridge.getWaveAmbientThresholdLocked()) "LOCKED" else "UNLOCKED"}"
            }
            switchWaveAmbientLock?.setOnCheckedChangeListener { _, locked ->
                NativeBridge.setWaveAmbientThresholdLocked(locked)
                prefs.edit().putBoolean("wave_ambient_locked", locked).apply()
                seekWaveAmbient?.isEnabled = !locked
                txtAmbientLockState?.text = "ATOM ${if (NativeBridge.getAtomAmbientThresholdLocked()) "LOCKED" else "UNLOCKED"} | WAVE ${if (locked) "LOCKED" else "UNLOCKED"}"
            }
        } catch (_: Exception) {
            // Ambient controls may not be present in alternate layouts.
        }

        val microphoneSwitch = findViewById<Switch>(R.id.switchMicrophoneLive)
        val microphoneGainSeek = findViewById<SeekBar>(R.id.seekMicrophoneGain)
        val microphoneGainText = findViewById<TextView>(R.id.txtMicrophoneGain)
        NativeBridge.setMicrophoneEnabled(true)
        NativeBridge.setMicrophoneGain(1.0f)
        microphoneSwitch.setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setMicrophoneEnabled(enabled)
            if (enabled && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startMicCapture()
            }
        }
        microphoneGainSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val gain = progress / 67f
                NativeBridge.setMicrophoneGain(gain)
                microphoneGainText.text = "${"%.1f".format(gain)}x"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        bindAdvancedControls()
        bindEyeControls()
        bindSpaceCurvatureControls()
        bindBodyAmbientControls()
        bindEnemyControls()
        bindMotionPitchControls()
        bindAmbientChannelGates()

        val dbThresholdSeek = findViewById<SeekBar>(R.id.seekDbThreshold)
        val dbThresholdText = findViewById<TextView>(R.id.txtDbThreshold)
        val storedDbThreshold = NativeBridge.getDbThreshold()
        dbThresholdSeek.progress = (((storedDbThreshold + 120f) / 120f) * 100f).toInt().coerceIn(0, 100)
        dbThresholdText.text = "${storedDbThreshold.toInt()}dB"
        dbThresholdSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            val db = -120f + value * 120f
            NativeBridge.setDbThreshold(db)
            dbThresholdText.text = "${db.toInt()}dB"
        })

        findViewById<Switch>(R.id.switchAmbientKill).setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setAmbientKillEnabled(enabled)
        }
        findViewById<Switch>(R.id.switchAmbientShift).setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setAmbientShiftEnabled(enabled)
        }
        findViewById<Switch>(R.id.switchVirtualAmbientKill).setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setAmbientKillEnabled(enabled)
        }
        findViewById<Switch>(R.id.switchVirtualAmbientShift).setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setAmbientShiftEnabled(enabled)
        }
        findViewById<Switch>(R.id.switchVirtualAmbientThresholdLock).setOnCheckedChangeListener { _, locked ->
            NativeBridge.setAmbientThresholdLocked(locked)
        }
        val peakLimiterSeek = findViewById<SeekBar>(R.id.seekPeakLimiterDb)
        val peakLimiterText = findViewById<TextView>(R.id.txtPeakLimiterDb)
        peakLimiterSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            val db = -120f + value * 120f
            NativeBridge.setPeakLimiterDb(db)
            peakLimiterText.text = "${db.toInt()}dB"
        })
        bindVoiceMaskControls()

        requestSensorPermissions()

        startLiveUpdate()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SENSOR_PERMISSION_REQUEST) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                arCameraView.onResumeSession()
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startMicCapture()
            } else {
                micRunning = false
            }
        }
    }

    private fun requestSensorPermissions() {
        val missing = buildList {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                add(Manifest.permission.CAMERA)
            }
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                add(Manifest.permission.RECORD_AUDIO)
            }
        }
        if (missing.isEmpty()) {
            arCameraView.onResumeSession()
            startMicCapture()
        } else {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), SENSOR_PERMISSION_REQUEST)
        }
    }

    private fun startMicCapture() {
        if (micRunning) return

        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        if (minBuffer <= 0) {
            return
        }

        val bufferSize = maxOf(minBuffer * 2, 2048)
        val shortBuffer = ShortArray(bufferSize / 2)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                audioRecord?.release()
                audioRecord = null
                return
            }

            micRunning = true
            audioRecord?.startRecording()
            if (processedMonitorEnabled) startProcessedMonitor()

            micThread = Thread {
                while (micRunning) {
                    val read = audioRecord?.read(shortBuffer, 0, shortBuffer.size) ?: 0
                    if (read > 0) {
                        val left = FloatArray(read)
                        val right = FloatArray(read)
                        for (i in 0 until read) {
                            val sample = shortBuffer[i] / 32768f
                            left[i] = sample
                            right[i] = sample
                        }
                        NativeBridge.nativeProcess(left, right, read)
                        if (processedMonitorEnabled) writeProcessedMonitor(left, right)
                    }
                }
            }.apply { start() }
        } catch (_: Exception) {
            micRunning = false
            audioRecord?.release()
            audioRecord = null
        }
    }

    private fun stopMicCapture() {
        micRunning = false
        try {
            audioRecord?.stop()
        } catch (_: IllegalStateException) {
        }
        audioRecord?.release()
        audioRecord = null
        micThread?.join(200)
        micThread = null
        stopProcessedMonitor()
    }

    private fun startProcessedMonitor() {
        if (audioTrack != null) return
        val bufferSize = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (bufferSize <= 0) return
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
            .also { it.play() }
    }

    private fun writeProcessedMonitor(left: FloatArray, right: FloatArray) {
        val track = audioTrack ?: return
        val pcm = ShortArray(left.size * 2)
        for (i in left.indices) {
            pcm[i * 2] = (left[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            pcm[i * 2 + 1] = (right[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        track.write(pcm, 0, pcm.size)
    }

    private fun stopProcessedMonitor() {
        audioTrack?.let {
            runCatching { it.stop() }
            it.release()
        }
        audioTrack = null
    }

    private fun simpleSeek(onChange: (Float) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onChange(progress / 100f)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }

    private fun bindAdvancedControls() {
        bindAdvancedSlider(R.id.seekWindLevel, R.id.txtWindLevel, 0, 0.50f)
        bindAdvancedSlider(R.id.seekWindThreshold, R.id.txtWindThreshold, 1, 0.25f)
        bindAdvancedSlider(R.id.seekMovementSpeed, R.id.txtMovementSpeed, 2, 0.50f)
        bindAdvancedSlider(R.id.seekMovementThreshold, R.id.txtMovementThreshold, 3, 0.20f)
        bindAdvancedSlider(R.id.seekMovementSmooth, R.id.txtMovementSmooth, 4, 0.60f)
        bindAdvancedSlider(R.id.seekAtomIntensity, R.id.txtAtomIntensity, 5, 0.70f)
        bindAdvancedSlider(R.id.seekWaveIntensity, R.id.txtWaveIntensity, 6, 0.70f)
        bindAdvancedSlider(R.id.seekVisualThreshold, R.id.txtVisualThreshold, 7, 0.25f)
        bindAdvancedSlider(R.id.seekEchoThreshold, R.id.txtEchoThreshold, 8, 0.40f)
        bindAdvancedSlider(R.id.seekPitchSpeed, R.id.txtPitchSpeed, 9, 0.50f)
        bindAdvancedSlider(R.id.seekPitchLevel, R.id.txtPitchLevel, 10, 0.50f)
        bindAdvancedSlider(R.id.seekPitchThreshold, R.id.txtPitchThreshold, 11, 0.25f)
        bindAdvancedSlider(R.id.seekPitchSmooth, R.id.txtPitchSmooth, 12, 0.60f)

        bindAdvancedGate(R.id.switchWind, 0, true)
        bindAdvancedGate(R.id.switchAtomIntensity, 5, true)
        bindAdvancedGate(R.id.switchWaveIntensity, 6, true)
        bindAdvancedGate(R.id.switchVisualGate, 7, true)
        bindAdvancedGate(R.id.switchEchoGate, 8, true)
    }

    private fun bindAdvancedSlider(seekId: Int, textId: Int, control: Int, initial: Float) {
        val seek = findViewById<SeekBar>(seekId) ?: return
        val text = findViewById<TextView>(textId) ?: return
        seek.progress = (initial * 100f).toInt()
        NativeBridge.setAdvancedValue(control, initial)
        if (control == 2) movementSpeedControl = initial
        text.text = "${(initial * 100f).toInt()}%"
        seek.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setAdvancedValue(control, value)
            if (control == 2) movementSpeedControl = value
            text.text = "${(value * 100f).toInt()}%"
        })
    }

    private fun bindAdvancedGate(switchId: Int, control: Int, initial: Boolean) {
        val toggle = findViewById<Switch>(switchId) ?: return
        toggle.isChecked = initial
        NativeBridge.setAdvancedEnabled(control, initial)
        toggle.setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setAdvancedEnabled(control, enabled)
        }
    }

    private fun bindEyeControls() {
        bindAdvancedSlider(R.id.seekEyeMoveSpeed, R.id.txtEyeMoveSpeed, 13, 0.60f)
        bindAdvancedSlider(R.id.seekEyeWaveLevel, R.id.txtEyeWaveLevel, 14, 0.55f)
        bindAdvancedSlider(R.id.seekEyeThreshold, R.id.txtEyeThreshold, 15, 0.20f)
        bindAdvancedSlider(R.id.seekEyePitchThreshold, R.id.txtEyePitchThreshold, 16, 0.25f)
        bindAdvancedSlider(R.id.seekEyeProtectionThreshold, R.id.txtEyeProtectionThreshold, 17, 0.85f)
        bindAdvancedSlider(R.id.seekEyeVisionThreshold, R.id.txtEyeVisionThreshold, 18, 0.30f)
        bindAdvancedGate(R.id.switchEyeMoveGate, 13, true)
        bindAdvancedGate(R.id.switchEyeWaveGate, 14, true)
        bindAdvancedGate(R.id.switchEyeVisionGate, 18, true)
        bindAdvancedGate(R.id.switchEyeProtection, 17, true)
        findViewById<Switch>(R.id.switchEyePingPong).setOnCheckedChangeListener { _, enabled -> NativeBridge.setEyePingPongEnabled(enabled) }
        val pingPongSeek = findViewById<SeekBar>(R.id.seekEyePingPong)
        val pingPongText = findViewById<TextView>(R.id.txtEyePingPong)
        pingPongSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setEyePingPongLevel(value)
            pingPongText.text = "${(value * 100f).toInt()}%"
        })
        val eyeBipolarSeek = findViewById<SeekBar>(R.id.seekEyeBipolarDb)
        val eyeBipolarText = findViewById<TextView>(R.id.txtEyeBipolarDb)
        eyeBipolarSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val db = progress * 10f - 1000f
                NativeBridge.setEyeBipolarDb(db)
                eyeBipolarText.text = "${db.toInt()}dB"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        val eyeAmbientSeek = findViewById<SeekBar>(R.id.seekEyeAmbientThreshold)
        val eyeAmbientText = findViewById<TextView>(R.id.txtEyeAmbientThreshold)
        eyeAmbientSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setEyeAmbientThreshold(value)
            eyeAmbientText.text = "${(value * 100f).toInt()}%"
        })
    }

    private fun bindSpaceCurvatureControls() {
        bindCurvature(R.id.seekAtomSpaceCurvature, R.id.txtAtomSpaceCurvature, 0.5f) { NativeBridge.setAtomSpaceCurvature(it) }
        bindCurvature(R.id.seekAtomSpaceCurvatureThreshold, R.id.txtAtomSpaceCurvatureThreshold, 0.3f) { NativeBridge.setAtomSpaceCurvatureThreshold(it) }
        bindCurvature(R.id.seekWaveSpaceCurvature, R.id.txtWaveSpaceCurvature, 0.5f) { NativeBridge.setWaveSpaceCurvature(it) }
        bindCurvature(R.id.seekWaveSpaceCurvatureThreshold, R.id.txtWaveSpaceCurvatureThreshold, 0.3f) { NativeBridge.setWaveSpaceCurvatureThreshold(it) }
        bindCurvature(R.id.seekAmbientSpaceCurvature, R.id.txtAmbientSpaceCurvature, 0.5f) { NativeBridge.setAmbientSpaceCurvature(it) }
        bindCurvature(R.id.seekAmbientSpaceCurvatureThreshold, R.id.txtAmbientSpaceCurvatureThreshold, 0.3f) { NativeBridge.setAmbientSpaceCurvatureThreshold(it) }
    }

    private fun bindBodyAmbientControls() {
        val names = listOf("HEAD", "CHEST", "ABDOMEN", "L-ARM", "R-ARM", "L-LEG", "R-LEG", "BRAIN", "NECK", "HEART", "BODY", "CNS", "FACE", "PELVIS", "TEETH", "BRAIN GLAND")
        val container = findViewById<LinearLayout>(R.id.bodyAmbientControls)
        names.forEachIndexed { index, name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            val label = TextView(this).apply { text = "$name threshold"; setTextColor(android.graphics.Color.WHITE); layoutParams = LinearLayout.LayoutParams(96, -2) }
            val seek = SeekBar(this).apply { max = 100; progress = 30; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            val value = TextView(this).apply { text = "30%"; setTextColor(android.graphics.Color.WHITE); gravity = android.view.Gravity.END; layoutParams = LinearLayout.LayoutParams(64, -2) }
            seek.setOnSeekBarChangeListener(simpleSeek { amount -> NativeBridge.setBodyAmbientThreshold(index, amount); value.text = "${(amount * 100f).toInt()}%" })
            row.addView(label); row.addView(seek); row.addView(value); container.addView(row)
        }
        val enemySwitch = findViewById<Switch>(R.id.switchBodyEnemyProtection)
        enemySwitch.setOnCheckedChangeListener { _, enabled -> NativeBridge.setBodyEnemyProtectionEnabled(enabled) }
        val enemySeek = findViewById<SeekBar>(R.id.seekBodyEnemyThreshold)
        val enemyText = findViewById<TextView>(R.id.txtBodyEnemyThreshold)
        enemySeek.setOnSeekBarChangeListener(simpleSeek { amount -> NativeBridge.setBodyEnemyMovementThreshold(amount); enemyText.text = "${(amount * 100f).toInt()}%" })
        findViewById<Switch>(R.id.switchBodyInsideProtection).apply {
            isChecked = true
            NativeBridge.setBodyInsideProtectionEnabled(true)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setBodyInsideProtectionEnabled(enabled) }
        }
        findViewById<Switch>(R.id.switchBodyOutsideProtection).apply {
            isChecked = true
            NativeBridge.setBodyOutsideProtectionEnabled(true)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setBodyOutsideProtectionEnabled(enabled) }
        }
        bindCurvature(R.id.seekBodyInsideThreshold, R.id.txtBodyInsideThreshold, 0.5f) { NativeBridge.setBodyInsideThreshold(it) }
        bindCurvature(R.id.seekBodyOutsideThreshold, R.id.txtBodyOutsideThreshold, 0.5f) { NativeBridge.setBodyOutsideThreshold(it) }
    }

    private fun bindEnemyControls() {
        findViewById<Switch>(R.id.switchEnemyProtection).apply {
            isChecked = true
            NativeBridge.setEnemyProtectionEnabled(true)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setEnemyProtectionEnabled(enabled) }
        }

        findViewById<Switch>(R.id.switchEnemyHardBlock).apply {
            isChecked = false
            NativeBridge.setEnemyHardBlock(false)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setEnemyHardBlock(enabled) }
        }
        bindCurvature(R.id.seekEnemyAmbientThreshold, R.id.txtEnemyAmbientThreshold, 0.30f) { NativeBridge.setEnemyAmbientThreshold(it) }
        findViewById<Switch>(R.id.switchEnemyAmbientThresholdLock).setOnCheckedChangeListener { _, locked ->
            NativeBridge.setEnemyAmbientThresholdLocked(locked)
            findViewById<SeekBar>(R.id.seekEnemyAmbientThreshold).isEnabled = !locked
        }
        bindCurvature(R.id.seekEnemyMovementThreshold, R.id.txtEnemyMovementThreshold, 0.70f) { NativeBridge.setEnemyMovementThreshold(it) }
        bindCurvature(R.id.seekEnemySpeedThreshold, R.id.txtEnemySpeedThreshold, 0.70f) { NativeBridge.setEnemySpeedThreshold(it) }
        bindCurvature(R.id.seekEnemyWaveThreshold, R.id.txtEnemyWaveThreshold, 0.70f) { NativeBridge.setEnemyWaveThreshold(it) }
        bindCurvature(R.id.seekEnemyCommunicationThreshold, R.id.txtEnemyCommunicationThreshold, 0.55f) { NativeBridge.setEnemyCommunicationThreshold(it) }
        bindCurvature(R.id.seekEnemySpeakerThreshold, R.id.txtEnemySpeakerThreshold, 0.70f) { NativeBridge.setEnemySpeakerThreshold(it) }
        bindCurvature(R.id.seekSpikeThreshold, R.id.txtSpikeThreshold, 0.35f) { NativeBridge.setSpikeThreshold(it) }
        bindCurvature(R.id.seekSilenceThreshold, R.id.txtSilenceThreshold, 0.02f) { NativeBridge.setSilenceThreshold(it) }
        bindHzThreshold(R.id.seekDominantThreshold, R.id.txtDominantThreshold, NativeBridge.getDominantThreshold()) { NativeBridge.setDominantThreshold(it) }
        bindHzThreshold(R.id.seekCentroidThreshold, R.id.txtCentroidThreshold, NativeBridge.getCentroidThreshold()) { NativeBridge.setCentroidThreshold(it) }
        val spectrumBipolarSeek = findViewById<SeekBar>(R.id.seekSpectrumBipolarThreshold)
        val spectrumBipolarText = findViewById<TextView>(R.id.txtSpectrumBipolarThreshold)
        val spectrumBipolar = NativeBridge.getSpectrumBipolarThreshold()
        spectrumBipolarSeek.progress = (spectrumBipolar + 120f).toInt()
        spectrumBipolarText.text = "${spectrumBipolar.toInt()}dB"
        spectrumBipolarSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            val db = value * 120f - 120f
            NativeBridge.setSpectrumBipolarThreshold(db)
            spectrumBipolarText.text = "${db.toInt()}dB"
        })

        val pitchSeek = findViewById<SeekBar>(R.id.seekEnemyPitchThreshold)
        val pitchText = findViewById<TextView>(R.id.txtEnemyPitchThreshold)
        pitchSeek.progress = 45
        NativeBridge.setEnemyPitchThreshold(1800f)
        pitchText.text = "1800Hz"
        pitchSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val hz = progress * 4000f / 100f
                NativeBridge.setEnemyPitchThreshold(hz)
                pitchText.text = "${hz.toInt()}Hz"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun bindHzThreshold(id: Int, textId: Int, initial: Float, onChanged: (Float) -> Unit) {
        val seek = findViewById<SeekBar>(id)
        val text = findViewById<TextView>(textId)
        seek.progress = initial.toInt()
        text.text = "${initial.toInt()}Hz"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onChanged(progress.toFloat())
                text.text = "${progress}Hz"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun bindMotionPitchControls() {
        findViewById<Switch>(R.id.switchMotionPitchProtection).apply {
            isChecked = true
            NativeBridge.setMotionPitchProtectionEnabled(true)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setMotionPitchProtectionEnabled(enabled) }
        }
        bindCurvature(R.id.seekMotionPitchThreshold, R.id.txtMotionPitchThreshold, 0.25f) { NativeBridge.setMotionPitchThreshold(it) }
        bindCurvature(R.id.seekMotionPitchSpeedThreshold, R.id.txtMotionPitchSpeedThreshold, 0.65f) { NativeBridge.setMotionPitchSpeedThreshold(it) }
        bindCurvature(R.id.seekMotionPitchMovementThreshold, R.id.txtMotionPitchMovementThreshold, 0.65f) { NativeBridge.setMotionPitchMovementThreshold(it) }
        bindCurvature(R.id.seekMotionPitchWaveThreshold, R.id.txtMotionPitchWaveThreshold, 0.65f) { NativeBridge.setMotionPitchWaveThreshold(it) }
        bindCurvature(R.id.seekEnemyCurveThreshold, R.id.txtEnemyCurveThreshold, 0.70f) { NativeBridge.setEnemyCurveThreshold(it) }
        bindCurvature(R.id.seekEnemyPlaneThreshold, R.id.txtEnemyPlaneThreshold, 0.70f) { NativeBridge.setEnemyPlaneThreshold(it) }
        bindCurvature(R.id.seekEnemyWallThreshold, R.id.txtEnemyWallThreshold, 0.70f) { NativeBridge.setEnemyWallThreshold(it) }
        bindCurvature(R.id.seekEnemyRingThreshold, R.id.txtEnemyRingThreshold, 0.70f) { NativeBridge.setEnemyRingThreshold(it) }
    }

    private fun bindAmbientChannelGates() {
        findViewById<Switch>(R.id.switchAmbientMovementGate).apply {
            isChecked = true
            NativeBridge.setAmbientMotionGateEnabled(true)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setAmbientMotionGateEnabled(enabled) }
        }
        findViewById<Switch>(R.id.switchAmbientSpeedGate).apply {
            isChecked = true
            NativeBridge.setAmbientSpeedGateEnabled(true)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setAmbientSpeedGateEnabled(enabled) }
        }
        findViewById<Switch>(R.id.switchAmbientWaveGate).apply {
            isChecked = true
            NativeBridge.setAmbientWaveGateEnabled(true)
            setOnCheckedChangeListener { _, enabled -> NativeBridge.setAmbientWaveGateEnabled(enabled) }
        }
    }

    private fun bindMotionBoardControls() {
        bindCurvature(R.id.seekMotionBoardSpeed, R.id.txtMotionBoardSpeed, 0.5f) {
            NativeBridge.setAtomSpareSpeed(it)
        }
        bindCurvature(R.id.seekMotionBoardMove, R.id.txtMotionBoardMove, 0.5f) {
            NativeBridge.setAtomSpareMove(it)
        }
        bindCurvature(R.id.seekMotionBoardWave, R.id.txtMotionBoardWave, 0.5f) {
            NativeBridge.setAtomSpareWave(it)
        }
    }

    private fun bindVoiceMaskControls() {
        findViewById<Switch>(R.id.switchInnerVoiceMask).setOnCheckedChangeListener { _, enabled -> NativeBridge.setInnerVoiceMaskEnabled(enabled) }
        findViewById<Switch>(R.id.switchLoudSpeechMask).setOnCheckedChangeListener { _, enabled -> NativeBridge.setLoudSpeechMaskEnabled(enabled) }
        bindCurvature(R.id.seekInnerVoiceMaskGain, R.id.txtInnerVoiceMaskGain, 0.35f) { NativeBridge.setInnerVoiceMaskGain(it) }
        bindCurvature(R.id.seekInnerVoiceMaskThreshold, R.id.txtInnerVoiceMaskThreshold, 0.25f) { NativeBridge.setInnerVoiceMaskThreshold(it) }
        bindCurvature(R.id.seekLoudSpeechMaskGain, R.id.txtLoudSpeechMaskGain, 0.35f) { NativeBridge.setLoudSpeechMaskGain(it) }
        val threshold = findViewById<SeekBar>(R.id.seekLoudSpeechMaskThreshold)
        val text = findViewById<TextView>(R.id.txtLoudSpeechMaskThreshold)
        threshold.setOnSeekBarChangeListener(simpleSeek { value ->
            val db = -120f + value * 120f
            NativeBridge.setLoudSpeechMaskThreshold(db)
            text.text = "${db.toInt()}dB"
        })
    }

    private fun bindVirtualAtomSpareControls() {
        val atomSpeed = findViewById<SeekBar>(R.id.seekVirtualAtomSpeed)
        val atomSpeedText = findViewById<TextView>(R.id.txtVirtualAtomSpeed)
        val warp = findViewById<SeekBar>(R.id.seekVirtualWarp)
        val warpText = findViewById<TextView>(R.id.txtVirtualWarp)
        val resonance = findViewById<SeekBar>(R.id.seekVirtualResonance)
        val resonanceText = findViewById<TextView>(R.id.txtVirtualResonance)
        val inertia = findViewById<SeekBar>(R.id.seekVirtualInertia)
        val inertiaText = findViewById<TextView>(R.id.txtVirtualInertia)
        val syncRate = findViewById<SeekBar>(R.id.seekVirtualSyncRate)
        val syncRateText = findViewById<TextView>(R.id.txtVirtualSyncRate)
        val stutterRate = findViewById<SeekBar>(R.id.seekVirtualStutterRate)
        val stutterRateText = findViewById<TextView>(R.id.txtVirtualStutterRate)
        val stutterDepth = findViewById<SeekBar>(R.id.seekVirtualStutterDepth)
        val stutterDepthText = findViewById<TextView>(R.id.txtVirtualStutterDepth)
        val overdrive = findViewById<SeekBar>(R.id.seekVirtualOverdrive)
        val overdriveText = findViewById<TextView>(R.id.txtVirtualOverdrive)
        val warpThreshold = findViewById<SeekBar>(R.id.seekWarpThreshold)
        val warpThresholdText = findViewById<TextView>(R.id.txtWarpThreshold)
        val stutterThreshold = findViewById<SeekBar>(R.id.seekStutterThreshold)
        val stutterThresholdText = findViewById<TextView>(R.id.txtStutterThreshold)
        val waveSpeed = findViewById<SeekBar>(R.id.seekWaveSpareVirtualSpeed)
        val waveSpeedText = findViewById<TextView>(R.id.txtWaveSpareVirtualSpeed)

        val setSliderText: (SeekBar, TextView, Float) -> Unit = { seekBar, text, value ->
            text.text = "${(value * 100f).toInt()}%"
            seekBar.progress = (value * 100f).toInt()
        }

        val atomInit = 0.5f
        atomSpeed.progress = (atomInit * 100f).toInt()
        atomSpeedText.text = "50%"
        NativeBridge.setAtomSpareSpeed(atomInit)
        atomSpeed.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setAtomSpareSpeed(value)
            atomSpeedText.text = "${(value * 100).toInt()}%"
        })

        warp.progress = 30
        warpText.text = "30%"
        NativeBridge.setAtomSpareSpeedBoost(1.0f + (warp.progress / 100f) * 3.0f)
        warp.setOnSeekBarChangeListener(simpleSeek { value ->
            val boost = 1.0f + value * 3.0f
            NativeBridge.setAtomSpareSpeedBoost(boost)
            warpText.text = "${(value * 100).toInt()}%"
        })

        resonance.progress = 40
        resonanceText.text = "40%"
        NativeBridge.setResonanceStrength(0.4f)
        resonance.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setResonanceStrength(value)
            resonanceText.text = "${(value * 100).toInt()}%"
        })

        inertia.progress = 35
        inertiaText.text = "35%"
        NativeBridge.setWaveSpareMovement(0.35f)
        inertia.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareMovement(value)
            inertiaText.text = "${(value * 100).toInt()}%"
        })

        syncRate.progress = 60
        syncRateText.text = "60%"
        NativeBridge.setWaveSpareThreshold(0.6f)
        syncRate.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareThreshold(value)
            syncRateText.text = "${(value * 100).toInt()}%"
        })

        stutterRate.progress = 50
        stutterRateText.text = "50%"
        stutterDepth.progress = 60
        stutterDepthText.text = "60%"
        stutterRate.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareSpeed(value)
            stutterRateText.text = "${(value * 100).toInt()}%"
        })
        stutterDepth.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareWave(value)
            stutterDepthText.text = "${(value * 100).toInt()}%"
        })

        overdrive.progress = 25
        overdriveText.text = "25%"
        overdrive.setOnSeekBarChangeListener(simpleSeek { value ->
            val capMultiplier = 1.0f + value * 9.0f
            NativeBridge.setVirtualSpeedCapMultiplier(capMultiplier)
            overdriveText.text = "${"%.1f".format(capMultiplier)}x"
        })

        waveSpeed.progress = 50
        waveSpeedText.text = "50%"
        NativeBridge.setWaveSpareSpeed(0.5f)
        waveSpeed.setOnSeekBarChangeListener(simpleSeek { value ->
            NativeBridge.setWaveSpareSpeed(value)
            waveSpeedText.text = "${(value * 100).toInt()}%"
        })

        NativeBridge.setVirtualSpeedCapEnabled(false)
        NativeBridge.setVirtualSpeedCapMultiplier(1.0f)
        NativeBridge.setMicIntensityEnabled(true)
        NativeBridge.setMicIntensityBias(1.0f)
        NativeBridge.setMicIntensityThreshold(0.25f)
        findViewById<Switch>(R.id.switchVirtualPhaseSync).setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setResonanceModeEnabled(enabled)
        }
        findViewById<Switch>(R.id.switchVirtualStutterGate).setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setMicIntensityEnabled(enabled)
        }
        findViewById<Switch>(R.id.switchVirtualOverdrive).setOnCheckedChangeListener { _, enabled ->
            NativeBridge.setVirtualSpeedCapEnabled(enabled)
        }

        listOf(
            R.id.btnAtomPresetFreeze to 0.0f,
            R.id.btnAtomPresetDrift to 0.25f,
            R.id.btnAtomPresetUnit to 1.0f,
            R.id.btnAtomPresetSurge to 8.0f,
            R.id.btnAtomPresetHyper to 50.0f,
            R.id.btnAtomPresetMax to 100.0f
        ).forEach { (id, value) ->
            findViewById<Button>(id).setOnClickListener {
                val scaled = (value / 100f).coerceIn(0f, 1f)
                NativeBridge.setAtomSpareSpeed(scaled)
                NativeBridge.setWaveSpareSpeed(scaled)
                NativeBridge.setWaveSpareWave(scaled)
                atomSpeed.progress = (scaled * 100f).toInt()
                atomSpeedText.text = "${(scaled * 100f).toInt()}%"
                waveSpeed.progress = (scaled * 100f).toInt()
                waveSpeedText.text = "${(scaled * 100f).toInt()}%"
            }
        }

        findViewById<Button>(R.id.btnAtomResetAll).setOnClickListener {
            NativeBridge.setAtomSpareSpeed(0.5f)
            NativeBridge.setAtomSpareSpeedBoost(1.0f)
            NativeBridge.setResonanceStrength(0.45f)
            NativeBridge.setWaveSpareSpeed(0.5f)
            NativeBridge.setWaveSpareMovement(0.5f)
            NativeBridge.setWaveSpareThreshold(0.3f)
            atomSpeed.progress = 50
            atomSpeedText.text = "50%"
            warp.progress = 30
            warpText.text = "30%"
            resonance.progress = 45
            resonanceText.text = "45%"
            inertia.progress = 35
            inertiaText.text = "35%"
            syncRate.progress = 30
            syncRateText.text = "30%"
            stutterRate.progress = 50
            stutterRateText.text = "50%"
            stutterDepth.progress = 60
            stutterDepthText.text = "60%"
            overdrive.progress = 25
            overdriveText.text = "25%"
            waveSpeed.progress = 50
            waveSpeedText.text = "50%"
        }
    }

    private fun bindSensorControls() {
        val sensorSwitches = mapOf(
            R.id.switchSensorAccel to "ACCEL",
            R.id.switchSensorGyro to "GYRO",
            R.id.switchSensorRotation to "ROTATION",
            R.id.switchSensorGravity to "GRAVITY",
            R.id.switchSensorMagnetic to "MAGNETIC",
            R.id.switchSensorLight to "LIGHT",
            R.id.switchSensorProximity to "PROXIMITY"
        )
        sensorSwitches.forEach { (id, name) ->
            findViewById<Switch>(id).setOnCheckedChangeListener { _, enabled -> sensorTelemetry.setEnabled(name, enabled) }
        }
        val sensitivitySeek = findViewById<SeekBar>(R.id.seekSensorSensitivity)
        val sensitivityText = findViewById<TextView>(R.id.txtSensorSensitivity)
        sensitivitySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress / 67f
                sensorTelemetry.setSensitivity(value)
                sensitivityText.text = "${"%.1f".format(value)}x"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        val thresholdSeek = findViewById<SeekBar>(R.id.seekSensorThreshold)
        val thresholdText = findViewById<TextView>(R.id.txtSensorThreshold)
        thresholdSeek.setOnSeekBarChangeListener(simpleSeek { value ->
            sensorTelemetry.setThreshold(value)
            thresholdText.text = "${(value * 100f).toInt()}%"
        })
        sensorTelemetry.start()
    }

    private fun bindCameraAdvancedControls() {
        findViewById<Switch>(R.id.switchThermalMode).setOnCheckedChangeListener { _, enabled -> arCameraView.thermalMode = enabled }
        findViewById<Switch>(R.id.switchIrMode).setOnCheckedChangeListener { _, enabled -> arCameraView.irMode = enabled }
        findViewById<Switch>(R.id.switchGpuBodyTexture).setOnCheckedChangeListener { _, enabled -> arCameraView.gpuBodyTextureEnabled = enabled }
        findViewById<Switch>(R.id.switchGpuProtection).setOnCheckedChangeListener { _, enabled -> arCameraView.gpuProtectionEnabled = enabled }
        findViewById<Switch>(R.id.switchCameraCommunicationGate).setOnCheckedChangeListener { _, enabled -> arCameraView.cameraCommunicationGateEnabled = enabled }
        findViewById<Switch>(R.id.switchVirtualColourCommunicationGate).setOnCheckedChangeListener { _, enabled -> arCameraView.virtualColourCommunicationGateEnabled = enabled }
        bindCurvature(
            R.id.seekVirtualColourCommunicationThreshold,
            R.id.txtVirtualColourCommunicationThreshold,
            0.55f
        ) { arCameraView.virtualColourCommunicationThreshold = it }
        bindCurvature(
            R.id.seekCameraFeedbackThreshold,
            R.id.txtCameraFeedbackThreshold,
            0.5f
        ) { arCameraView.cameraFeedbackThreshold = it }
        findViewById<Switch>(R.id.switchVideoFeedback).setOnCheckedChangeListener { _, enabled -> arCameraView.videoFeedbackEnabled = enabled }
        bindCurvature(R.id.seekVideoFeedbackGain, R.id.txtVideoFeedbackGain, 0.35f) { arCameraView.videoFeedbackGain = it }
        bindCurvature(R.id.seekVideoFeedbackDecay, R.id.txtVideoFeedbackDecay, 0.65f) { arCameraView.videoFeedbackDecay = it }
        bindCurvature(R.id.seekVideoFeedbackDepth, R.id.txtVideoFeedbackDepth, 0.35f) { arCameraView.videoFeedbackDepth = it }
        bindCurvature(R.id.seekVideoFeedbackThreshold, R.id.txtVideoFeedbackThreshold, 0.2f) { arCameraView.videoFeedbackThreshold = it }
        bindCurvature(R.id.seekVideoFeedbackLimiter, R.id.txtVideoFeedbackLimiter, 0.8f) { arCameraView.videoFeedbackLimiter = it }
        bindCurvature(R.id.seekThermalThreshold, R.id.txtThermalThreshold, 0.5f) { arCameraView.thermalThreshold = it }
        bindCurvature(R.id.seekThermalLevel, R.id.txtThermalLevel, 0.5f) { arCameraView.thermalLevel = it }
        bindCurvature(R.id.seekIrThreshold, R.id.txtIrThreshold, 0.5f) { arCameraView.irThreshold = it }
        bindCurvature(R.id.seekIrLevel, R.id.txtIrLevel, 0.5f) { arCameraView.irLevel = it }
        bindCurvature(R.id.seekGpuColorThreshold, R.id.txtGpuColorThreshold, 0.5f) { arCameraView.gpuColorThreshold = it }
        bindCurvature(R.id.seekCameraCommunicationThreshold, R.id.txtCameraCommunicationThreshold, 0.55f) { arCameraView.cameraCommunicationThreshold = it }
        bindCurvature(R.id.seekArgumentRealityBrightnessThreshold, R.id.txtArgumentRealityBrightnessThreshold, 0.5f) { arCameraView.argumentRealityBrightnessThreshold = it }
        bindCurvature(R.id.seekArgumentRealityContrastThreshold, R.id.txtArgumentRealityContrastThreshold, 0.5f) { arCameraView.argumentRealityContrastThreshold = it }
        bindDbRange(R.id.seekArgumentRealityBipolarThreshold, R.id.txtArgumentRealityBipolarThreshold, 0f) { arCameraView.argumentRealityBipolarThresholdDb = it }
        bindCurvature(R.id.seekArgumentRealityIntensity, R.id.txtArgumentRealityIntensity, 1f) { arCameraView.argumentRealityIntensity = it }
        bindMappedRange(R.id.seekArgumentRealityScale, R.id.txtArgumentRealityScale, 1f, 0.1f, 10f) { arCameraView.argumentRealityScale = it }
        bindCurvature(R.id.seekArgumentRealityGeometryDensity, R.id.txtArgumentRealityGeometryDensity, 0.5f) { arCameraView.geometryDensity = it }
        bindCurvature(R.id.seekArgumentRealityPlaneGain, R.id.txtArgumentRealityPlaneGain, 0.5f) { arCameraView.planeGain = it }
        bindCurvature(R.id.seekArgumentRealityWallGain, R.id.txtArgumentRealityWallGain, 0.5f) { arCameraView.wallGain = it }
        bindCurvature(R.id.seekArgumentRealityCurveGain, R.id.txtArgumentRealityCurveGain, 0.5f) { arCameraView.curveGain = it }
        bindCurvature(R.id.seekArgumentRealityRingGain, R.id.txtArgumentRealityRingGain, 0.5f) { arCameraView.ringGain = it }
        findViewById<Switch>(R.id.switchQuantumScene).setOnCheckedChangeListener { _, enabled -> arCameraView.quantumSceneEnabled = enabled }
        bindCurvature(R.id.seekQuantumParticleDensity, R.id.txtQuantumParticleDensity, 0.55f) { arCameraView.quantumParticleDensity = it }
        bindCurvature(R.id.seekQuantumParticleScale, R.id.txtQuantumParticleScale, 0.45f) { arCameraView.quantumParticleScale = it }
        bindCurvature(R.id.seekQuantumParticleThreshold, R.id.txtQuantumParticleThreshold, 0.25f) { arCameraView.quantumParticleThreshold = it }
        findViewById<Switch>(R.id.switchArgumentReality3d).setOnCheckedChangeListener { _, enabled -> arCameraView.argumentReality3dEnabled = enabled }
        bindCurvature(R.id.seekArgumentReality3dDepth, R.id.txtArgumentReality3dDepth, 0.35f) { arCameraView.argumentReality3dDepth = it }
        findViewById<Switch>(R.id.switchArgumentRealityEnemy3dProtection).setOnCheckedChangeListener { _, enabled -> arCameraView.argumentRealityEnemy3dProtectionEnabled = enabled }
        bindShieldSwitch(R.id.switchArgumentRealityAmbientShield) { arCameraView.argumentRealityAmbientShieldEnabled = it }
        bindCurvature(R.id.seekArgumentRealityAmbientShieldThreshold, R.id.txtArgumentRealityAmbientShieldThreshold, 0.5f) { arCameraView.argumentRealityAmbientShieldThreshold = it }
        bindShieldSwitch(R.id.switchArgumentRealityAnimationShield) { arCameraView.argumentRealityAnimationShieldEnabled = it }
        bindCurvature(R.id.seekArgumentRealityAnimationShieldThreshold, R.id.txtArgumentRealityAnimationShieldThreshold, 0.5f) { arCameraView.argumentRealityAnimationShieldThreshold = it }
        bindShieldSwitch(R.id.switchArgumentRealityBodyShield) { arCameraView.argumentRealityBodyShieldEnabled = it }
        bindCurvature(R.id.seekArgumentRealityBodyShieldThreshold, R.id.txtArgumentRealityBodyShieldThreshold, 0.5f) { arCameraView.argumentRealityBodyShieldThreshold = it }
        bindShieldSwitch(R.id.switchArgumentRealityHumanTrackingGate) { arCameraView.argumentRealityHumanTrackingGateEnabled = it }
        bindCurvature(R.id.seekArgumentRealityHumanTrackingThreshold, R.id.txtArgumentRealityHumanTrackingThreshold, 0.5f) { arCameraView.argumentRealityHumanTrackingThreshold = it }
        bindShieldSwitch(R.id.switchArgumentRealityEyesShield) { arCameraView.argumentRealityEyesShieldEnabled = it }
        bindCurvature(R.id.seekArgumentRealityEyesShieldThreshold, R.id.txtArgumentRealityEyesShieldThreshold, 0.5f) { arCameraView.argumentRealityEyesShieldThreshold = it }
        bindShieldSwitch(R.id.switchArgumentRealitySpikeShield) { arCameraView.argumentRealitySpikeShieldEnabled = it }
        bindCurvature(R.id.seekArgumentRealitySpikeShieldThreshold, R.id.txtArgumentRealitySpikeShieldThreshold, 0.35f) { arCameraView.argumentRealitySpikeShieldThreshold = it }
        findViewById<Switch>(R.id.switchArgumentRealityAmbientKiller).setOnCheckedChangeListener { _, enabled -> arCameraView.argumentRealityAmbientKillerEnabled = enabled }
        bindCurvature(R.id.seekArgumentRealityFftThreshold, R.id.txtArgumentRealityFftThreshold, 0.5f) { arCameraView.argumentRealityFftThreshold = it }
        findViewById<Switch>(R.id.switchArgumentRealityCommunicationGate).setOnCheckedChangeListener { _, enabled -> arCameraView.argumentRealityCommunicationGateEnabled = enabled }
    }

    private fun bindCameraVisualEnhancements() {
        findViewById<Switch>(R.id.switchCameraFocus).setOnCheckedChangeListener { _, enabled -> arCameraView.focusMode = enabled }
        findViewById<Switch>(R.id.switchAxisProtection).setOnCheckedChangeListener { _, enabled -> arCameraView.axisProtectionEnabled = enabled }
        findViewById<Switch>(R.id.switchZoomProtection).setOnCheckedChangeListener { _, enabled -> arCameraView.zoomProtectionEnabled = enabled }
        findViewById<Switch>(R.id.switchSlsMode).setOnCheckedChangeListener { _, enabled -> arCameraView.slsMode = enabled }
        findViewById<Switch>(R.id.switchEdgeProtection).setOnCheckedChangeListener { _, enabled -> arCameraView.edgeProtectionEnabled = enabled }
        bindCurvature(R.id.seekCameraFocusThreshold, R.id.txtCameraFocusThreshold, 0.5f) { arCameraView.focusThreshold = it }
        bindCurvature(R.id.seekEnemyFocusThreshold, R.id.txtEnemyFocusThreshold, 0.7f) { arCameraView.enemyFocusThreshold = it }
        bindCurvature(R.id.seekAxisRotation, R.id.txtAxisRotation, 0.5f) { arCameraView.axisRotation = it * 2f - 1f }
        bindCurvature(R.id.seekAxisThreshold, R.id.txtAxisThreshold, 0.7f) { arCameraView.axisProtectionThreshold = it }
        findViewById<Switch>(R.id.switchKaleidoscopeProtection).setOnCheckedChangeListener { _, enabled -> arCameraView.kaleidoscopeProtectionEnabled = enabled }
        bindCurvature(R.id.seekKaleidoscopeSegments, R.id.txtKaleidoscopeSegments, 0.17f) { arCameraView.kaleidoscopeSegments = 2f + it * 30f }
        bindCurvature(R.id.seekKaleidoscopeAxis, R.id.txtKaleidoscopeAxis, 0.5f) { arCameraView.kaleidoscopeAxis = it * 6.2831853f - 3.1415926f }
        bindCurvature(R.id.seekKaleidoscopeThreshold, R.id.txtKaleidoscopeThreshold, 0.7f) { arCameraView.kaleidoscopeThreshold = it }
        findViewById<Switch>(R.id.switchTunnelProtection).setOnCheckedChangeListener { _, enabled -> arCameraView.tunnelProtectionEnabled = enabled }
        findViewById<Spinner>(R.id.spinnerTunnelMode).onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { arCameraView.tunnelMode = position }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        bindCurvature(R.id.seekTunnelDepth, R.id.txtTunnelDepth, 0.35f) { arCameraView.tunnelDepth = it }
        bindCurvature(R.id.seekTunnelAxis, R.id.txtTunnelAxis, 0.5f) { arCameraView.tunnelAxis = it * 6.2831853f - 3.1415926f }
        bindCurvature(R.id.seekCameraZoom, R.id.txtCameraZoom, 0.5f) { arCameraView.zoomAmount = it - 0.5f }
        bindCurvature(R.id.seekZoomThreshold, R.id.txtZoomThreshold, 0.7f) { arCameraView.zoomProtectionThreshold = it }
        bindCurvature(R.id.seekSlsThreshold, R.id.txtSlsThreshold, 0.5f) { arCameraView.slsThreshold = it }
        bindCurvature(R.id.seekSlsLevel, R.id.txtSlsLevel, 0.5f) { arCameraView.slsLevel = it }
        bindCurvature(R.id.seekSlsSmooth, R.id.txtSlsSmooth, 0.5f) { arCameraView.slsSmooth = it }
        bindCurvature(R.id.seekEdgeThreshold, R.id.txtEdgeThreshold, 0.5f) { arCameraView.edgeThreshold = it }
        bindCurvature(R.id.seekEdgeLevel, R.id.txtEdgeLevel, 0.5f) { arCameraView.edgeLevel = it }
        bindCurvature(R.id.seekEdgeSmooth, R.id.txtEdgeSmooth, 0.5f) { arCameraView.edgeSmooth = it }
        bindCurvature(R.id.seekThermalSmooth, R.id.txtThermalSmooth, 0.5f) { arCameraView.thermalSmooth = it }
        bindCurvature(R.id.seekIrSmooth, R.id.txtIrSmooth, 0.5f) { arCameraView.irSmooth = it }
        bindCurvature(R.id.seekArgumentRealityColorThreshold, R.id.txtArgumentRealityColorThreshold, 0.5f) { arCameraView.argumentRealityColorThreshold = it }
        bindPalette(R.id.seekSlsPalette, R.id.txtSlsPalette) { red, green, blue -> arCameraView.slsRed = red; arCameraView.slsGreen = green; arCameraView.slsBlue = blue }
        bindPalette(R.id.seekEdgePalette, R.id.txtEdgePalette) { red, green, blue -> arCameraView.edgeRed = red; arCameraView.edgeGreen = green; arCameraView.edgeBlue = blue }
        bindPalette(R.id.seekThermalPalette, R.id.txtThermalPalette) { red, green, blue -> arCameraView.thermalRed = red; arCameraView.thermalGreen = green; arCameraView.thermalBlue = blue }
        bindPalette(R.id.seekIrPalette, R.id.txtIrPalette) { red, green, blue -> arCameraView.irRed = red; arCameraView.irGreen = green; arCameraView.irBlue = blue }
    }

    private fun bindPalette(seekId: Int, textId: Int, setter: (Float, Float, Float) -> Unit) {
        val seek = findViewById<SeekBar>(seekId)
        val text = findViewById<TextView>(textId)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val palette = progress / 25
                val colors = arrayOf(floatArrayOf(1f, 0.1f, 0.1f), floatArrayOf(0.6f, 1f, 0.1f), floatArrayOf(1f, 1f, 1f), floatArrayOf(0.2f, 1f, 0.2f))
                val color = colors[palette.coerceIn(0, 3)]
                setter(color[0], color[1], color[2])
                text.text = arrayOf("RED", "LIME", "WHITE", "GREEN")[palette.coerceIn(0, 3)]
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun bindDbRange(seekId: Int, textId: Int, initial: Float, setter: (Float) -> Unit) {
        val seek = findViewById<SeekBar>(seekId)
        val text = findViewById<TextView>(textId)
        seek.progress = (initial + 10000f).toInt().coerceIn(0, 20000)
        setter(initial)
        text.text = "${initial.toInt()}dB"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val db = progress.toFloat() - 10000f
                setter(db)
                text.text = "${db.toInt()}dB"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun bindCurvature(seekId: Int, textId: Int, initial: Float, setter: (Float) -> Unit) {
        val seek = findViewById<SeekBar>(seekId) ?: return
        val text = findViewById<TextView>(textId) ?: return
        seek.progress = (initial * 100f).toInt()
        setter(initial)
        text.text = "${(initial * 100f).toInt()}%"
        seek.setOnSeekBarChangeListener(simpleSeek { value ->
            setter(value)
            text.text = "${(value * 100f).toInt()}%"
        })
    }

    private fun bindMappedRange(seekId: Int, textId: Int, initial: Float, minimum: Float, maximum: Float, setter: (Float) -> Unit) {
        val seek = findViewById<SeekBar>(seekId) ?: return
        val text = findViewById<TextView>(textId) ?: return
        fun value(progress: Int) = minimum + (maximum - minimum) * progress / 100f
        seek.progress = (((initial - minimum) / (maximum - minimum)) * 100f).toInt().coerceIn(0, 100)
        setter(initial)
        text.text = "${"%.1f".format(initial)}x"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val mapped = value(progress)
                setter(mapped)
                text.text = "${"%.1f".format(mapped)}x"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun bindShieldSwitch(id: Int, setter: (Boolean) -> Unit) {
        findViewById<Switch>(id).apply {
            isChecked = true
            setter(true)
            setOnCheckedChangeListener { _, enabled -> setter(enabled) }
        }
    }

    private fun startLiveUpdate() {
        handler.post(object : Runnable {
            override fun run() {
                updateNativeVisuals()
                val micState = if (micRunning && NativeBridge.getMicrophoneEnabled()) "MIC LIVE" else "MIC OFF"
                findViewById<TextView>(R.id.txtArgumentStatus)?.text = "ARGUMENT: ${if (NativeBridge.getArgumentActive()) "ACTIVE" else "QUIET"} | threshold ${(NativeBridge.getArgumentThreshold() * 100f).toInt()}%"
                arStatus.text = "AR CAMERA: ${arCameraView.trackingState} | ${arCameraView.videoFeedback} | $micState"
                findViewById<TextView>(R.id.txtCameraGpuStatus)?.text =
                    "GPU ${if (arCameraView.gpuBodyTextureEnabled) "BODY TEXTURE" else "RAW"} | THERMAL ${if (arCameraView.thermalMode) "ON" else "OFF"} | IR ${if (arCameraView.irMode) "ON" else "OFF"} | CAMERA COMM ${if (arCameraView.cameraCommunicationBlocked) "BLOCKED" else "OPEN"}"
                findViewById<TextView>(R.id.txtVisualFeedback)?.text = "VISUAL: ${if (arCameraView.visualProtectionEnabled || arCameraView.antiVisualProtectionEnabled) "PROTECTED" else "RAW"} ${if (arCameraView.vhsTrackingEnabled) "VHS" else "CLEAN"} | VIDEO: ${arCameraView.videoFeedback} | TRANSMISSION ${if (arCameraView.transmissionEnabled) "ON" else "OFF"}"
                findViewById<TextView>(R.id.txtCameraEffectsStatus)?.text =
                    "KALEIDOSCOPE ${if (arCameraView.kaleidoscopeProtectionEnabled) "PROTECTED" else "OFF"} | SEGMENTS ${arCameraView.kaleidoscopeSegments.toInt()} | TUNNEL ${arrayOf("OFF", "2D", "3D", "4D", "5D", "6D", "7D").getOrElse(arCameraView.tunnelMode) { "OFF" }} ${if (arCameraView.tunnelProtectionEnabled) "PROTECTED" else "RAW"} | AXIS ${"%.2f".format(arCameraView.tunnelAxis)}"
                val warpCounter = NativeBridge.getWarpCounter()
                val stutterCounter = NativeBridge.getStutterCounter()
                val warpHz = NativeBridge.getWarpHz().toInt()
                val stutterHz = NativeBridge.getStutterHz().toInt()
                val warpDb = NativeBridge.getWarpDb().toInt()
                val stutterDb = NativeBridge.getStutterDb().toInt()
                val warpRaw = NativeBridge.getWarpRaw()
                val stutterRaw = NativeBridge.getStutterRaw()
                val warpDirectionCode = NativeBridge.getWarpDirection()
                val stutterDirectionCode = NativeBridge.getStutterDirection()
                val warpDirection = when (warpDirectionCode) { 1 -> "UP"; -1 -> "DOWN"; else -> "IDLE" }
                val stutterDirection = when (stutterDirectionCode) { 1 -> "UP"; -1 -> "DOWN"; else -> "IDLE" }
                val warpUpCount = NativeBridge.getWarpDirectionUpCounter()
                val warpDownCount = NativeBridge.getWarpDirectionDownCounter()
                val stutterUpCount = NativeBridge.getStutterDirectionUpCounter()
                val stutterDownCount = NativeBridge.getStutterDirectionDownCounter()
                findViewById<TextView>(R.id.txtMicrophoneRaw)?.text = "${if (micRunning && NativeBridge.getMicrophoneEnabled()) "MIC LIVE" else "MIC OFF"} | RAW RMS ${(NativeBridge.getRawMicRms().coerceIn(0f, 1f) * 100f).toInt()}% | PEAK ${(NativeBridge.getRawMicPeak().coerceIn(0f, 1f) * 100f).toInt()}% | WARP $warpCounter/$warpHz Hz/$warpDb dB | STUTTER $stutterCounter/$stutterHz Hz/$stutterDb dB | RAW ${"%.2f".format(warpRaw)}/${"%.2f".format(stutterRaw)} | BIPOLAR ${"%.1f".format(NativeBridge.getWarpBipolar())}/${"%.1f".format(NativeBridge.getStutterBipolar())}"
                findViewById<TextView>(R.id.txtWarpDirection)?.text = "WARP DIRECTION: $warpDirection | UP $warpUpCount | DOWN $warpDownCount | LEVEL ${"%.2f".format(warpRaw)} | THRESH ${"%.2f".format(NativeBridge.getWarpThreshold())}"
                findViewById<TextView>(R.id.txtStutterDirection)?.text = "STUTTER DIRECTION: $stutterDirection | UP $stutterUpCount | DOWN $stutterDownCount | LEVEL ${"%.2f".format(stutterRaw)} | THRESH ${"%.2f".format(NativeBridge.getStutterThreshold())}"
                findViewById<TextView>(R.id.txtSensorStatus)?.text = sensorTelemetry.rawSummary()
                modelStatus.text = "${modelRuntime.status} | ${modelRuntime.lastInference}"
                handler.postDelayed(this, 40)
            }
        })
    }

    private fun updateNativeVisuals() {
        arCameraView.cameraCommunicationBlocked =
            NativeBridge.getThresholdCommunicationStatus() >= 2 || NativeBridge.getEnemyProtectionStatus() >= 2 ||
                NativeBridge.getAmbientLevel() >= arCameraView.cameraCommunicationThreshold
        // Keep the camera video loop alive during temporary tracking loss.
        arCameraView.cameraSignalBlocked = false
        arCameraView.quantumParticleEnergy = (
            arCameraView.trackingConfidence * 0.25f +
                NativeBridge.getAmbientFftLevel() * 0.20f +
                sensorTelemetry.motionLevel() * 0.15f +
                modelRuntime.humanVisualGate.let { if (it) 0.20f else 0f } +
                NativeBridge.getWaveEnergy() * 0.20f
            ).coerceIn(0f, 1f)
        arCameraView.focusBlocked = NativeBridge.getEnemyProtectionStatus() >= 2 ||
            NativeBridge.getAmbientLevel() >= arCameraView.enemyFocusThreshold
        arCameraView.humanVisualProtectionActive = arCameraView.humanVisualProtectionEnabled &&
            modelRuntime.humanVisualGate && arCameraView.trackingConfidence < arCameraView.argumentRealityHumanTrackingThreshold
        val head = NativeBridge.getHeadZone().coerceIn(0f, 1f)
        val chest = NativeBridge.getChestZone().coerceIn(0f, 1f)
        val abdomen = NativeBridge.getAbdomenZone().coerceIn(0f, 1f)
        val leftArm = NativeBridge.getLeftArmZone().coerceIn(0f, 1f)
        val rightArm = NativeBridge.getRightArmZone().coerceIn(0f, 1f)
        val leftLeg = NativeBridge.getLeftLegZone().coerceIn(0f, 1f)
        val rightLeg = NativeBridge.getRightLegZone().coerceIn(0f, 1f)

        bodyView.updateZones(head, chest, abdomen, leftArm, rightArm, leftLeg, rightLeg)
        bodyView.updateEyes(NativeBridge.getEyeLeftLevel(), NativeBridge.getEyeRightLevel())
        eyeBoard.leftLevel = NativeBridge.getEyeLeftLevel()
        eyeBoard.rightLevel = NativeBridge.getEyeRightLevel()
        eyeBoard.threshold = NativeBridge.getEyeVisionThreshold().coerceIn(0f, 1f)

        val speedSignal = NativeBridge.getSpeedEnergy().coerceIn(0f, 1f)
        val moveSignal = NativeBridge.getAtomMoveEnergy().coerceIn(0f, 1f)
        val waveSignal = NativeBridge.getAtomWaveEnergy().coerceIn(0f, 1f)

        speedWave.energy = if (NativeBridge.getWaveSpeed() > 0f || NativeBridge.getResonanceModeEnabled() || NativeBridge.getRoboticModeEnabled()) maxOf(speedSignal, 0.18f) else speedSignal
        moveWave.energy = if (NativeBridge.getAtomSpareMove() > 0f || NativeBridge.getRoboticModeEnabled()) maxOf(moveSignal, 0.20f) else moveSignal
        waveWave.energy = if (NativeBridge.getAtomSpareWave() > 0f || NativeBridge.getResonanceModeEnabled()) maxOf(waveSignal, 0.18f) else waveSignal

        speedWave.animationSpeed = if (waveSpeedEnabled) NativeBridge.getWaveSpeed().coerceIn(0f, 1f) else 0f
        speedWave.smoothness = NativeBridge.getWaveSmooth().coerceIn(0f, 1f)
        val atomMove = NativeBridge.getAtomSpareMove().coerceIn(0f, 1f)
        val roboticMove = if (NativeBridge.getRoboticModeEnabled()) NativeBridge.getRoboticBias().coerceIn(0f, 1f) * 0.5f else 0f
        moveWave.animationSpeed = (movementSpeedControl * 0.65f + atomMove * 0.35f + roboticMove).coerceIn(0f, 1f)
        waveWave.animationSpeed = (NativeBridge.getWaveSpareSpeed().coerceIn(0f, 1f) + if (NativeBridge.getResonanceModeEnabled()) NativeBridge.getResonanceStrength().coerceIn(0f, 1f) * 0.5f else 0f).coerceIn(0f, 1f)
        motionBoard.speed = speedSignal
        motionBoard.move = moveSignal
        motionBoard.wave = waveSignal
        motionBoard.threshold = NativeBridge.getAtomSpareAmbientThreshold().coerceIn(0f, 1f)
        val cameraColor = ((arCameraView.trackingConfidence + arCameraView.colorThreshold) * 0.5f).coerceIn(0f, 1f)
        val modelColor = modelRuntime.lastInference.let { if (it.contains("LIVE", true)) arCameraView.trackingConfidence else 0f }
        val audioColor = NativeBridge.getAmbientFftLevel().coerceIn(0f, 1f)
        val sensorColor = sensorTelemetry.motionLevel().coerceIn(0f, 1f)
        val bodyColor = ((moveSignal + speedSignal + waveSignal) / 3f).coerceIn(0f, 1f)
        val enemyColor = if (NativeBridge.getEnemyProtectionActive()) 1f else 0f
        arCameraView.cameraColorTracking = cameraColor
        arCameraView.gpuColorTracking = if (arCameraView.gpuBodyTextureEnabled && arCameraView.gpuProtectionEnabled) arCameraView.gpuColorThreshold else 0f
        arCameraView.modelColorTracking = modelColor
        arCameraView.audioColorTracking = audioColor
        arCameraView.sensorColorTracking = sensorColor
        arCameraView.bodyColorTracking = bodyColor
        arCameraView.personalBodyColorTracking = NativeBridge.getBodyOutput().coerceIn(0f, 1f)
        arCameraView.virtualColorTracking = ((arCameraView.slsLevel + arCameraView.edgeLevel) * 0.5f).coerceIn(0f, 1f)
        arCameraView.argumentRealityVirtualTracking = (
            arCameraView.virtualColorTracking * 0.45f +
                arCameraView.cameraColorTracking * 0.25f +
                arCameraView.modelColorTracking * 0.15f +
                arCameraView.audioColorTracking * 0.15f
            ).coerceIn(0f, 1f)
        arCameraView.enemyColorTracking = enemyColor
        arCameraView.systemColorTracking = maxOf(cameraColor, modelColor, audioColor, sensorColor, bodyColor, enemyColor)
        arCameraView.detectedColorLevel = arCameraView.systemColorTracking
        arCameraView.vhsTrackingLevel = if (arCameraView.vhsTrackingEnabled) {
            ((arCameraView.trackingConfidence - arCameraView.vhsTrackingThreshold) /
                (1f - arCameraView.vhsTrackingThreshold).coerceAtLeast(0.001f)).coerceIn(0f, 1f)
        } else {
            0f
        }
        arCameraView.vhsMovementLevel = (
            arCameraView.vhsTrackingLevel * 0.55f +
                sensorColor * 0.20f +
                bodyColor * 0.15f +
                arCameraView.enemyColorTracking * 0.10f
            ).coerceIn(0f, 1f)
        arCameraView.vhsSpeedLevel = (
            arCameraView.vhsTrackingLevel * 0.55f +
                speedSignal * 0.25f +
                audioColor * 0.10f +
                modelColor * 0.10f
            ).coerceIn(0f, 1f)
        arCameraView.vhsWaveLevel = (
            arCameraView.vhsTrackingLevel * 0.55f +
                waveSignal * 0.20f +
                cameraColor * 0.15f +
                arCameraView.gpuColorTracking * 0.10f
            ).coerceIn(0f, 1f)
            arCameraView.eyeVisionColourTracking = (
                (NativeBridge.getEyeLeftLevel() + NativeBridge.getEyeRightLevel()) * 0.5f
            ).coerceIn(0f, 1f)
            val eyeVisionGate = if (arCameraView.eyeVisionColourTracking >= NativeBridge.getEyeVisionThreshold()) 1f else 0f
            val virtualCommunicationGate = if (
                arCameraView.virtualColourCommunicationGateEnabled &&
                arCameraView.virtualColorTracking >= arCameraView.virtualColourCommunicationThreshold &&
                eyeVisionGate > 0f
            ) 1f else 0f
            arCameraView.virtualColourCommunicationLevel = (
                arCameraView.virtualColorTracking * virtualCommunicationGate
            ).coerceIn(0f, 1f)
        val cameraPipelineGate = 1f
        val cameraSurfaceSpeed = (
            speedSignal * 0.35f +
                cameraColor * 0.15f +
                modelColor * 0.10f +
                audioColor * 0.10f +
                sensorColor * 0.10f +
                bodyColor * 0.10f +
                arCameraView.gpuColorTracking * 0.05f +
                arCameraView.vhsTrackingLevel * 0.05f
            ) * cameraPipelineGate
        val cameraSurfaceMovement = (
            moveSignal * 0.35f +
                bodyColor * 0.15f +
                sensorColor * 0.15f +
                modelColor * 0.10f +
                audioColor * 0.10f +
                arCameraView.enemyColorTracking * 0.05f +
                arCameraView.virtualColorTracking * 0.10f
            ) * cameraPipelineGate
        val cameraSurfaceWave = (
            waveSignal * 0.35f +
                bodyColor * 0.15f +
                cameraColor * 0.10f +
                audioColor * 0.15f +
                arCameraView.gpuColorTracking * 0.10f +
                arCameraView.vhsTrackingLevel * 0.10f +
                arCameraView.systemColorTracking * 0.05f
            ) * cameraPipelineGate
        arCameraView.cameraSurfaceSpeed = cameraSurfaceSpeed.coerceIn(0f, 1f)
        arCameraView.cameraSurfaceMovement = cameraSurfaceMovement.coerceIn(0f, 1f)
        arCameraView.cameraSurfaceWave = cameraSurfaceWave.coerceIn(0f, 1f)
        val feedbackInput = (
            arCameraView.cameraSurfaceSpeed +
                arCameraView.cameraSurfaceMovement +
                arCameraView.cameraSurfaceWave +
                arCameraView.eyeVisionColourTracking
        ) * 0.25f
        arCameraView.cameraFeedbackLevel = feedbackInput.coerceIn(0f, 1f)
        arCameraView.cameraColourFeedbackLevel = (cameraColor * arCameraView.cameraFeedbackLevel).coerceIn(0f, 1f)
        arCameraView.cameraColourFeedbackDecay = (1f - arCameraView.cameraColourFeedbackLevel).coerceIn(0f, 1f)
        arCameraView.virtualVideoAnimationThreshold = arCameraView.virtualColourCommunicationThreshold
        arCameraView.virtualVideoAnimationLevel = (
            arCameraView.virtualColorTracking * 0.45f +
                arCameraView.cameraFeedbackLevel * 0.30f +
                arCameraView.cameraSurfaceMovement * 0.25f
            ).coerceIn(0f, 1f)
        arCameraView.audioReactiveFeedback = (
            audioColor * 0.55f + NativeBridge.getMicIntensity() * 0.25f +
                NativeBridge.getAmbientRms().coerceIn(0f, 1f) * 0.20f
            ).coerceIn(0f, 1f)
        arCameraView.motionRecursionFeedback = (
            cameraSurfaceMovement * 0.45f + cameraSurfaceWave * 0.35f +
                sensorColor * 0.20f
            ).coerceIn(0f, 1f)
        arCameraView.enemyFeedbackLevel = (
            enemyColor * 0.50f + NativeBridge.getMoveEnergy() * 0.20f +
                NativeBridge.getSpeedEnergy() * 0.15f + NativeBridge.getWaveEnergy() * 0.15f
            ).coerceIn(0f, 1f)
        arCameraView.enemyFeedbackProtection = if (NativeBridge.getEnemyProtectionActive()) {
            (0.55f + NativeBridge.getEnemyProtectionStatus() * 0.20f).coerceIn(0f, 1f)
        } else {
            0f
        }
        val argumentRealityAmbientLevel = audioColor
        arCameraView.argumentRealityFftLevel = NativeBridge.getAmbientFftLevel().coerceIn(0f, 1f)
        arCameraView.argumentRealityAmbientKillerBlocked =
            arCameraView.argumentRealityAmbientKillerEnabled &&
                arCameraView.argumentRealityFftLevel >= arCameraView.argumentRealityFftThreshold
        val argumentRealityAnimationLevel = ((cameraSurfaceMovement + cameraSurfaceWave) * 0.5f).coerceIn(0f, 1f)
        val argumentRealityBodyLevel = bodyColor
        val argumentRealityHumanLevel = arCameraView.trackingConfidence.coerceIn(0f, 1f)
        val argumentRealitySpikeLevel = NativeBridge.getSpikeOutput().coerceIn(0f, 1f)
        val shieldFailures = listOf(
            arCameraView.argumentRealityAmbientShieldEnabled && argumentRealityAmbientLevel < arCameraView.argumentRealityAmbientShieldThreshold,
            arCameraView.argumentRealityAnimationShieldEnabled && argumentRealityAnimationLevel < arCameraView.argumentRealityAnimationShieldThreshold,
            arCameraView.argumentRealityBodyShieldEnabled && argumentRealityBodyLevel < arCameraView.argumentRealityBodyShieldThreshold,
            arCameraView.argumentRealityHumanTrackingGateEnabled && argumentRealityHumanLevel < arCameraView.argumentRealityHumanTrackingThreshold,
            arCameraView.argumentRealityEyesShieldEnabled && arCameraView.eyeVisionColourTracking < arCameraView.argumentRealityEyesShieldThreshold,
            arCameraView.argumentRealitySpikeShieldEnabled && argumentRealitySpikeLevel >= arCameraView.argumentRealitySpikeShieldThreshold
        )
        arCameraView.argumentRealityShieldLevel = (
            argumentRealityAmbientLevel + argumentRealityAnimationLevel + argumentRealityBodyLevel +
                argumentRealityHumanLevel + arCameraView.eyeVisionColourTracking + argumentRealitySpikeLevel
            ) / 6f
        arCameraView.argumentRealityShieldBlocked = shieldFailures.any { it }
        arCameraView.argumentRealityBlocked = arCameraView.argumentRealityShieldBlocked ||
            arCameraView.argumentRealityAmbientKillerBlocked || arCameraView.humanVisualProtectionActive
        val virtualGate = if (arCameraView.virtualColourCommunicationGateEnabled) 1f else 0f
        arCameraView.cameraBrightnessLevel = ((cameraColor + arCameraView.trackingConfidence) * 0.5f).coerceIn(0f, 1f)
        arCameraView.audioBrightnessLevel = ((audioColor + NativeBridge.getAmbientLevel()) * 0.5f).coerceIn(0f, 1f)
        arCameraView.audioColourBrightnessLevel = (audioColor * arCameraView.systemColorTracking).coerceIn(0f, 1f)
        arCameraView.cameraColourBrightnessLevel = (cameraColor * arCameraView.detectedColorLevel).coerceIn(0f, 1f)
        arCameraView.gpuColourBrightnessLevel = (arCameraView.gpuColorTracking * cameraColor).coerceIn(0f, 1f)
        arCameraView.cameraSurfaceBrightnessLevel = ((cameraSurfaceSpeed + cameraSurfaceMovement + cameraSurfaceWave) / 3f).coerceIn(0f, 1f)
        arCameraView.visualBrightnessLevel = ((arCameraView.cameraBrightnessLevel + arCameraView.virtualColorTracking * virtualGate) * 0.5f).coerceIn(0f, 1f)
        arCameraView.cameraContrastLevel = ((cameraSurfaceMovement + cameraSurfaceWave) * 0.5f).coerceIn(0f, 1f)
        arCameraView.argumentRealityBrightnessLevel = (
            arCameraView.cameraBrightnessLevel * 0.45f +
                arCameraView.virtualColorTracking * 0.35f +
                arCameraView.audioColorTracking * 0.20f
            ).coerceIn(0f, 1f)
        arCameraView.argumentRealityContrastLevel = (
            arCameraView.cameraContrastLevel * 0.45f +
                arCameraView.visualContrastLevel * 0.25f +
                arCameraView.virtualColorTracking * 0.30f
            ).coerceIn(0f, 1f)
        arCameraView.argumentRealityBipolarDb = (20f * kotlin.math.log10(maxOf(arCameraView.argumentRealityVirtualTracking, 0.000001f))).coerceIn(-120f, 0f)
        arCameraView.argumentRealityCommunicationLevel = (
            arCameraView.argumentRealityVirtualTracking * 0.5f +
                arCameraView.argumentRealityBrightnessLevel * 0.25f +
                arCameraView.argumentRealityContrastLevel * 0.25f
            ).coerceIn(0f, 1f)
        arCameraView.argumentRealityCommunicationBlocked =
            arCameraView.argumentRealityCommunicationGateEnabled &&
                (arCameraView.argumentRealityCommunicationLevel < arCameraView.argumentRealityColorThreshold ||
                    arCameraView.argumentRealityBrightnessLevel < arCameraView.argumentRealityBrightnessThreshold ||
                    arCameraView.argumentRealityContrastLevel < arCameraView.argumentRealityContrastThreshold ||
                    arCameraView.argumentRealityBipolarDb < arCameraView.argumentRealityBipolarThresholdDb)
        arCameraView.argumentRealityBlocked = arCameraView.argumentRealityBlocked || arCameraView.argumentRealityCommunicationBlocked
        arCameraView.cameraCommunicationBlocked = arCameraView.cameraCommunicationBlocked || arCameraView.argumentRealityBlocked
        arCameraView.argumentReality3dActive = arCameraView.argumentReality3dEnabled
        arCameraView.argumentRealityEnemy3dProtection = arCameraView.argumentRealityEnemy3dProtectionEnabled &&
            (NativeBridge.getEnemyProtectionStatus() >= 1 || NativeBridge.getBodyEnemyProtectionActive() || arCameraView.argumentRealityBlocked)
        arCameraView.audioContrastLevel = ((audioColor + sensorColor) * 0.5f).coerceIn(0f, 1f)
        arCameraView.audioColourContrastLevel = (audioColor * arCameraView.systemColorTracking).coerceIn(0f, 1f)
        arCameraView.cameraColourContrastLevel = (cameraColor * arCameraView.cameraSurfaceMovement).coerceIn(0f, 1f)
        arCameraView.gpuColourContrastLevel = (arCameraView.gpuColorTracking * arCameraView.cameraSurfaceWave).coerceIn(0f, 1f)
        arCameraView.cameraSurfaceContrastLevel = ((cameraSurfaceSpeed + cameraSurfaceWave) * 0.5f).coerceIn(0f, 1f)
        arCameraView.visualContrastLevel = ((arCameraView.cameraContrastLevel + arCameraView.virtualColorTracking * virtualGate) * 0.5f).coerceIn(0f, 1f)
        arCameraView.bodyMotion = arCameraView.cameraSurfaceMovement
        arCameraView.bodySpeed = arCameraView.cameraSurfaceSpeed
        arCameraView.bodyWave = arCameraView.cameraSurfaceWave
        updateDirectionMixers(
            speedSignal,
            moveSignal,
            waveSignal,
            arCameraView.eyeVisionColourTracking,
            arCameraView.cameraSurfaceSpeed,
            arCameraView.cameraSurfaceMovement,
            arCameraView.cameraSurfaceWave
        )
        arCameraView.bodyPitchProtection = maxOf(
            NativeBridge.getMotionPitchLeftProtection(),
            NativeBridge.getMotionPitchRightProtection(),
            NativeBridge.getMotionPitchSpeedProtection(),
            NativeBridge.getMotionPitchMovementProtection(),
            NativeBridge.getMotionPitchWaveProtection()
        ).coerceIn(0f, 1f)
        findViewById<TextView>(R.id.txtMotionBoardSource)?.text =
            "MOTION: MIC ${if (micRunning) "LIVE" else "OFF"} + CAMERA ${arCameraView.trackingState} + ${modelRuntime.lastInference}"
        updateLiveMetrics(NativeBridge.getAmbientLevel(), NativeBridge.getAmbientRms(), NativeBridge.getAmbientFftLevel(), NativeBridge.getAmbientDb(), NativeBridge.getBipolarDb(), NativeBridge.getPitchHz())
    }

    private fun updateLiveMetrics(level: Float, rms: Float, fft: Float, db: Float, bipolarDb: Float, pitchHz: Float) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (fpsWindowStart == 0L) fpsWindowStart = now
        framesThisSecond++
        val elapsed = now - fpsWindowStart
        if (elapsed >= 1000L) {
            liveFps = (framesThisSecond * 1000L / elapsed).toInt()
            framesThisSecond = 0
            fpsWindowStart = now
        }
        val detectedPitchHz = NativeBridge.getPitchHz().toInt()
        val thresholdedPitchHz = NativeBridge.getThresholdedPitchHz().toInt()
        val thresholdedPitchDb = NativeBridge.getThresholdedPitchDb().toInt()
        val silenceThresholdValue = NativeBridge.getSilenceThreshold()
        val spikeThresholdValue = NativeBridge.getSpikeThreshold()
        findViewById<TextView>(R.id.txtAmbientLevel)?.text =
            "Level ${(level.coerceIn(0f, 1f) * 100).toInt()}%  Ambient ${db.toInt()}dB  Bipolar ${bipolarDb.toInt()}dB  RMS ${(rms.coerceIn(0f, 1f) * 100).toInt()}%  FFT ${(fft.coerceIn(0f, 1f) * 100).toInt()}%  Pitch ${pitchHz.toInt()}Hz  Detected ${detectedPitchHz}Hz  FPS $liveFps"
        findViewById<TextView>(R.id.txtSignalOutputs)?.text =
            "DOM ${NativeBridge.getDominantHz().toInt()}Hz (#${NativeBridge.getDominantHzCounter()}) | CENTROID ${NativeBridge.getSpectralCentroidHz().toInt()}Hz (#${NativeBridge.getSpectralCentroidCounter()}) | PITCH ${detectedPitchHz}Hz -> THRESH ${thresholdedPitchHz}Hz / ${thresholdedPitchDb}dB | BRAIN ${ (NativeBridge.getBrainWaveOutput() * 100).toInt()}% | SPIKE ${(NativeBridge.getSpikeOutput() * 100).toInt()}%/${NativeBridge.getSpikeCount()} @ ${"%.2f".format(spikeThresholdValue)} | SILENCE ${if (NativeBridge.getSilenceActive()) "ACTIVE" else "CLEAR"} ${NativeBridge.getSilenceLevel()} / ${"%.2f".format(silenceThresholdValue)} | FREQ ${NativeBridge.getPitchHz().toInt()}Hz"
        findViewById<TextView>(R.id.txtAmbientSpectrum)?.text =
            "DOM: ${NativeBridge.getDominantHz().toInt()}Hz (#${NativeBridge.getDominantHzCounter()}) | CENTROID: ${NativeBridge.getSpectralCentroidHz().toInt()}Hz (#${NativeBridge.getSpectralCentroidCounter()}) | PITCH: ${detectedPitchHz}Hz | THRESH: ${thresholdedPitchHz}Hz / ${thresholdedPitchDb}dB | SILENCE: ${if (NativeBridge.getSilenceActive()) "ACTIVE" else "CLEAR"} @ ${"%.2f".format(silenceThresholdValue)}"
        val enemyStatus = when (NativeBridge.getEnemyProtectionStatus()) {
            2 -> "BLOCKED"
            1 -> "WARNING"
            else -> "CLEAR"
        }
        findViewById<TextView>(R.id.txtEnemyProtectionStatus)?.text =
            "ENEMY PROTECTION $enemyStatus | ${if (NativeBridge.getEnemyProtectionActive()) "THRESHOLD HIT" else "MONITORING"} | AMBIENT HOLD ${if (NativeBridge.getEnemyAmbientSignalHold()) "ACTIVE" else "CLEAR"} | COMM ${NativeBridge.getThresholdCommunicationStatus()}"
        findViewById<TextView>(R.id.txtMotionPitchOutputs)?.text =
            "PITCH SPEED ${(NativeBridge.getPitchSpeedOutput() * 100).toInt()}% | MOVE ${(NativeBridge.getPitchMovementOutput() * 100).toInt()}% | WAVE ${(NativeBridge.getPitchWaveOutput() * 100).toInt()}% | ATOM SPEED L/R ${(NativeBridge.getAtomSpareSpeedLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareSpeedRight() * 100).toInt()}% | MOVE L/R ${(NativeBridge.getAtomSpareMoveLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareMoveRight() * 100).toInt()}% | WAVE L/R ${(NativeBridge.getAtomSpareWaveLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareWaveRight() * 100).toInt()}% | PROTECT ${(NativeBridge.getMotionPitchLeftProtection() * 100).toInt()}/${(NativeBridge.getMotionPitchRightProtection() * 100).toInt()}%"
        findViewById<TextView>(R.id.txtMotionPitchChannelLevels)?.text =
            "MOTION PITCH SPEED L/R ${(NativeBridge.getAtomSpareSpeedLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareSpeedRight() * 100).toInt()}% | MOVE L/R ${(NativeBridge.getAtomSpareMoveLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareMoveRight() * 100).toInt()}% | WAVE L/R ${(NativeBridge.getAtomSpareWaveLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareWaveRight() * 100).toInt()}%"
        findViewById<TextView>(R.id.txtAtomSpareSpatialOutputs)?.text =
            "ATOMSPARE SPEED L/R ${(NativeBridge.getAtomSpareSpeedLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareSpeedRight() * 100).toInt()}% | PITCH L/R ${(NativeBridge.getEyeLeftPitch() * 100).toInt()}/${(NativeBridge.getEyeRightPitch() * 100).toInt()}% | MOVE L/R ${(NativeBridge.getAtomSpareMoveLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareMoveRight() * 100).toInt()}% | WAVE L/R ${(NativeBridge.getAtomSpareWaveLeft() * 100).toInt()}/${(NativeBridge.getAtomSpareWaveRight() * 100).toInt()}%"
        findViewById<TextView>(R.id.txtEyePitchProtectionOutputs)?.text =
            "EYES PITCH L/R ${(NativeBridge.getEyeLeftPitch() * 100).toInt()}/${(NativeBridge.getEyeRightPitch() * 100).toInt()}% | LEVEL L/R ${(NativeBridge.getEyeLeftLevel() * 100).toInt()}/${(NativeBridge.getEyeRightLevel() * 100).toInt()}% | PROTECTION L/R ${(NativeBridge.getEyeLeftProtection() * 100).toInt()}/${(NativeBridge.getEyeRightProtection() * 100).toInt()}%"
        updateSpatialDirectionControls()
        findViewById<TextView>(R.id.txtPitchEvents)?.text =
            "Pitch threshold events: ${NativeBridge.getPitchThresholdEvents()} | detected ${NativeBridge.getPitchHz().toInt()}Hz | thresholded ${NativeBridge.getThresholdedPitchHz().toInt()}Hz | dB ${NativeBridge.getThresholdedPitchDb().toInt()}dB | db threshold ${NativeBridge.getDbThreshold().toInt()}dB | spike threshold ${"%.2f".format(NativeBridge.getSpikeThreshold())} | silence threshold ${"%.2f".format(NativeBridge.getSilenceThreshold())}"
        findViewById<TextView>(R.id.txtAmbientActions)?.text =
            "Kill ${if (NativeBridge.getAmbientKillActive()) "ACTIVE" else "OFF"} | Shift ${if (NativeBridge.getAmbientShiftActive()) "ACTIVE" else "OFF"} | Peak reduction ${NativeBridge.getPeakLimiterReductionDb().toInt()}dB | Silence ${if (NativeBridge.getSilenceActive()) "ACTIVE" else "OFF"} ${NativeBridge.getSilenceLevel()} | Spike count ${NativeBridge.getSpikeCount()}"
        findViewById<TextView>(R.id.txtAmbientModes)?.text =
            "AtomSpare analysis: ${if (NativeBridge.getAtomAmbientActive()) "ACTIVE" else "QUIET"} | WaveSpare analysis: ${if (NativeBridge.getWaveAmbientActive()) "ACTIVE" else "QUIET"}"
        findViewById<TextView>(R.id.txtEyeOutputs)?.text =
            "EYES CAMERA: ${arCameraView.trackingState} | L/R PITCH ${(NativeBridge.getEyeLeftPitch() * 100).toInt()}/${(NativeBridge.getEyeRightPitch() * 100).toInt()} | OUTPUT ${(NativeBridge.getEyeLeftLevel() * 100).toInt()}/${(NativeBridge.getEyeRightLevel() * 100).toInt()} | bipolar ${NativeBridge.getEyeBipolarDb().toInt()}dB"
        findViewById<TextView>(R.id.txtMaskStatus)?.text =
            "INNER ${if (NativeBridge.getInnerVoiceMaskActive()) "ACTIVE" else "OFF"} | LOUD ${if (NativeBridge.getLoudSpeechMaskActive()) "ACTIVE" else "OFF"}"
        val bodyNames = listOf("HEAD", "CHEST", "ABDOMEN", "L-ARM", "R-ARM", "L-LEG", "R-LEG", "BRAIN", "NECK", "HEART", "BODY", "CNS", "FACE", "PELVIS", "TEETH", "BRAIN GLAND")
        findViewById<TextView>(R.id.txtBodyEnemyStatus)?.text = "${if (NativeBridge.getBodyEnemyProtectionActive()) "ENEMY BODY PROTECTION ACTIVE" else "ENEMY BODY PROTECTION OFF"} | INSIDE ${if (NativeBridge.getBodyInsideProtectionActive()) "PROTECTED" else "CLEAR"} | OUTSIDE ${if (NativeBridge.getBodyOutsideProtectionActive()) "PROTECTED" else "CLEAR"} | DOM ${NativeBridge.getDominantHz().toInt()}Hz #${NativeBridge.getDominantHzCounter()} | CENTROID ${NativeBridge.getSpectralCentroidHz().toInt()}Hz #${NativeBridge.getSpectralCentroidCounter()} | " + bodyNames.joinToString("  ") { name -> val i = bodyNames.indexOf(name); "$name ${(NativeBridge.getBodyAmbientLevel(i) * 100f).toInt()}%/${NativeBridge.getBodyAmbientBipolarDb(i).toInt()}dB/${NativeBridge.getBodyAmbientCounter(i)}" }
        findViewById<TextView>(R.id.txtWaveSpareLevel)?.text =
            "WaveSpare level ${(NativeBridge.getWaveSpareLevel().coerceIn(0f, 1f) * 100).toInt()}% | ${if (NativeBridge.getWaveSpareActive()) "ACTIVE" else "QUIET"} | bipolar ${NativeBridge.getWaveSpareBipolarDb().toInt()}dB"
        findViewById<TextView>(R.id.txtArgumentRealityColourStatus)?.text =
            "ARGUMENT COLOUR VIRTUAL TRACKING ${(arCameraView.argumentRealityVirtualTracking * 100).toInt()}% | BRIGHTNESS ${(arCameraView.argumentRealityBrightnessLevel * 100).toInt()}% / TH ${(arCameraView.argumentRealityBrightnessThreshold * 100).toInt()}% | CONTRAST ${(arCameraView.argumentRealityContrastLevel * 100).toInt()}% / TH ${(arCameraView.argumentRealityContrastThreshold * 100).toInt()}% | BIPOLAR ${arCameraView.argumentRealityBipolarDb.toInt()}dB / TH ${arCameraView.argumentRealityBipolarThresholdDb.toInt()}dB | COMM ${if (!arCameraView.argumentRealityCommunicationGateEnabled) "OFF" else if (arCameraView.argumentRealityCommunicationBlocked) "BLOCKED" else "OPEN"}"
        findViewById<TextView>(R.id.txtArgumentRealityShieldStatus)?.text =
            "SHIELDS AMBIENT ${if (arCameraView.argumentRealityAmbientShieldEnabled) "ON" else "OFF"} | ANIMATION ${if (arCameraView.argumentRealityAnimationShieldEnabled) "ON" else "OFF"} | BODY ${if (arCameraView.argumentRealityBodyShieldEnabled) "ON" else "OFF"} | HUMAN ${if (arCameraView.argumentRealityHumanTrackingGateEnabled) "ON" else "OFF"} | EYES ${if (arCameraView.argumentRealityEyesShieldEnabled) "ON" else "OFF"} | SPIKE ${if (arCameraView.argumentRealitySpikeShieldEnabled) "ON" else "OFF"} | LEVEL ${(arCameraView.argumentRealityShieldLevel * 100).toInt()}% | ${if (arCameraView.argumentRealityBlocked) "BLOCKED" else "OPEN"}"
        findViewById<TextView>(R.id.txtArgumentRealityAmbientKillerStatus)?.text =
            "AR AMBIENT KILLER ${if (arCameraView.argumentRealityAmbientKillerEnabled) "ON" else "OFF"} | FFT ${(arCameraView.argumentRealityFftLevel * 100).toInt()}% | THRESHOLD ${(arCameraView.argumentRealityFftThreshold * 100).toInt()}% | ${if (arCameraView.argumentRealityAmbientKillerBlocked) "BLOCKED" else "OPEN"}"
        updateRawFeatureTelemetry()
    }

    private fun bindRawFeatureTelemetry() {
        val container = findViewById<LinearLayout>(R.id.rawFeatureTelemetry) ?: return
        val rows = listOf(
            "DOM detected Hz" to { (NativeBridge.getDominantHz() / 4000f).coerceIn(0f, 1f) },
            "Centroid detected Hz" to { (NativeBridge.getSpectralCentroidHz() / 4000f).coerceIn(0f, 1f) },
            "Thresholded movement output" to { NativeBridge.getThresholdedMovementOutput() },
            "Thresholded movement level" to { NativeBridge.getThresholdedMovementLevel() },
            "Thresholded movement threshold" to { NativeBridge.getThresholdedMovementThreshold() },
            "Thresholded speed output" to { NativeBridge.getThresholdedSpeedOutput() },
            "Thresholded speed level" to { NativeBridge.getThresholdedSpeedLevel() },
            "Thresholded speed threshold" to { NativeBridge.getThresholdedSpeedThreshold() },
            "Thresholded waves output" to { NativeBridge.getThresholdedWaveOutput() },
            "Thresholded waves level" to { NativeBridge.getThresholdedWaveLevel() },
            "Thresholded waves threshold" to { NativeBridge.getThresholdedWaveThreshold() },
            "Ambient level" to { NativeBridge.getAmbientLevel() },
            "Ambient threshold" to { NativeBridge.getAmbientThresholdLevel() },
            "Ambient bipolar dB" to { ((NativeBridge.getAmbientBipolarThreshold() + 120f) / 120f).coerceIn(0f, 1f) },
            "Ambient spike" to { NativeBridge.getSpikeOutput() },
            "Head spike" to { NativeBridge.getHeadZone() * NativeBridge.getSpikeOutput() },
            "Body spike" to { NativeBridge.getBodyOutput() * NativeBridge.getSpikeOutput() },
            "Amplifier output" to {
                if (NativeBridge.getAmplifierEnabled()) {
                    (NativeBridge.getRawMicPeak() * (1f + NativeBridge.getAmplifierGain() * NativeBridge.getAmplifierLevel())).coerceIn(0f, 1f)
                } else {
                    0f
                }
            },
            "Amplifier protection" to { if (NativeBridge.getAmplifierEnabled() && NativeBridge.getRawMicPeak() >= NativeBridge.getAmplifierThreshold()) 1f else 0f },
            "Amplifier gain" to { (NativeBridge.getAmplifierGain() / 8f).coerceIn(0f, 1f) },
            "Communication gate enabled" to { if (NativeBridge.getCommunicationGateEnabled()) 1f else 0f },
            "Communication gate blocked" to { if (NativeBridge.getCommunicationGateBlocked()) 1f else 0f },
            "Communication gate state" to { NativeBridge.getCommunicationGateState().coerceIn(0, 2).toFloat() / 2f },
            "Echo waves" to { NativeBridge.getWaveSpareWaveOutput() },
            "Echo movement" to { NativeBridge.getWaveSpareMoveOutput() },
            "Echo speed" to { NativeBridge.getWaveSpareSpeedOutput() },
            "Intensity waves" to { NativeBridge.getWaveEnergy() },
            "Intensity movement" to { NativeBridge.getMoveEnergy() },
            "Intensity speed" to { NativeBridge.getSpeedEnergy() },
            "Imagination waves" to { NativeBridge.getPitchWaveOutput() },
            "Imagination movement" to { NativeBridge.getPitchMovementOutput() },
            "Imagination speed" to { NativeBridge.getPitchSpeedOutput() },
            "AtomSpare speed left" to { NativeBridge.getAtomSpareSpeedLeft() },
            "AtomSpare speed right" to { NativeBridge.getAtomSpareSpeedRight() },
            "AtomSpare pitch left" to { NativeBridge.getEyeLeftPitch() },
            "AtomSpare pitch right" to { NativeBridge.getEyeRightPitch() },
            "AtomSpare move left" to { NativeBridge.getAtomSpareMoveLeft() },
            "AtomSpare move right" to { NativeBridge.getAtomSpareMoveRight() },
            "AtomSpare wave left" to { NativeBridge.getAtomSpareWaveLeft() },
            "AtomSpare wave right" to { NativeBridge.getAtomSpareWaveRight() },
            "Eye protection left" to { NativeBridge.getEyeLeftProtection() },
            "Eye protection right" to { NativeBridge.getEyeRightProtection() },
            "Camera surface waves" to { arCameraView.cameraSurfaceWave },
            "Camera surface movement" to { arCameraView.cameraSurfaceMovement },
            "Camera surface speed" to { arCameraView.cameraSurfaceSpeed },
            "Audio reactive feedback" to { arCameraView.audioReactiveFeedback },
            "Motion recursion feedback" to { arCameraView.motionRecursionFeedback },
            "Enemy feedback level" to { arCameraView.enemyFeedbackLevel },
            "Enemy feedback protection" to { arCameraView.enemyFeedbackProtection },
            "ARCore depth supported" to { if (arCameraView.arCoreDepthSupported) 1f else 0f },
            "ARCore depth mm" to { (arCameraView.arCoreDepthMm / 5000f).coerceIn(0f, 1f) },
            "ARCore depth scale" to { arCameraView.arCoreDepthNormalized },
            "ARCore tracked planes" to { (arCameraView.arCoreTrackedPlanes / 16f).coerceIn(0f, 1f) },
            "ARCore camera X metres" to { (arCameraView.arCorePoseX / 10f).coerceIn(-1f, 1f).let { (it + 1f) * 0.5f } },
            "ARCore camera Y metres" to { (arCameraView.arCorePoseY / 10f).coerceIn(-1f, 1f).let { (it + 1f) * 0.5f } },
            "ARCore camera Z metres" to { (arCameraView.arCorePoseZ / 10f).coerceIn(-1f, 1f).let { (it + 1f) * 0.5f } },
            "ARCore camera distance" to { (arCameraView.arCorePoseDistance / 10f).coerceIn(0f, 1f) },
            "ARCore camera yaw" to { ((arCameraView.arCorePoseYaw / Math.PI.toFloat()) + 1f) * 0.5f },
            "ARCore camera pitch" to { ((arCameraView.arCorePosePitch / (Math.PI.toFloat() * 0.5f)) + 1f) * 0.5f },
            "ARCore camera roll" to { ((arCameraView.arCorePoseRoll / Math.PI.toFloat()) + 1f) * 0.5f },
            "VHS tracking" to { arCameraView.vhsTrackingLevel },
            "VHS movement" to { arCameraView.vhsMovementLevel },
            "VHS speed" to { arCameraView.vhsSpeedLevel },
            "VHS waves" to { arCameraView.vhsWaveLevel },
            "Colour waves" to { NativeBridge.getEyeVisionThreshold().let { threshold -> ((NativeBridge.getEyeLeftLevel() + NativeBridge.getEyeRightLevel()) * 0.5f).coerceAtLeast(threshold * 0.0f) } },
            "Colour movement" to { ((NativeBridge.getEyeLeftPitch() + NativeBridge.getEyeRightPitch()) * 0.5f).coerceIn(0f, 1f) },
            "Colour speed" to { NativeBridge.getEyePingPongLevel().coerceIn(0f, 1f) },
            "Camera colour tracking" to { arCameraView.cameraColorTracking },
            "Camera colour level" to { arCameraView.cameraColorTracking },
            "Camera colour threshold" to { arCameraView.colorThreshold },
            "Camera colour bipolar" to { ((20f * kotlin.math.log10(maxOf(arCameraView.cameraColorTracking, 0.000001f)) + 120f) / 120f).coerceIn(0f, 1f) },
            "Detected colour" to { arCameraView.detectedColorLevel },
            "GPU colour tracking" to { arCameraView.gpuColorTracking },
            "Model colour tracking" to { arCameraView.modelColorTracking },
            "Audio colour tracking" to { arCameraView.audioColorTracking },
            "Sensor colour tracking" to { arCameraView.sensorColorTracking },
            "Body colour tracking" to { arCameraView.bodyColorTracking },
            "Personal body colour" to { arCameraView.personalBodyColorTracking },
            "Virtual colour" to { arCameraView.virtualColorTracking },
            "Enemy colour" to { arCameraView.enemyColorTracking },
            "System colour" to { arCameraView.systemColorTracking },
            "Eye vision colour" to { arCameraView.eyeVisionColourTracking },
            "Virtual colour communication" to { arCameraView.virtualColourCommunicationLevel },
            "Camera feedback" to { arCameraView.cameraFeedbackLevel },
            "Camera video feedback" to { arCameraView.cameraFeedbackLevel },
            "Camera colour feedback" to { arCameraView.cameraColourFeedbackLevel },
            "Camera colour feedback decay" to { arCameraView.cameraColourFeedbackDecay },
            "Camera video feedback threshold" to { arCameraView.cameraFeedbackThreshold },
            "Camera video loop protection" to { if (arCameraView.videoLoopProtectionActive) 1f else 0f },
            "Camera video loop frame age" to { (arCameraView.videoFrameAgeMs.coerceAtMost(5000L) / 5000f).toFloat() },
            "Video feedback enabled" to { if (arCameraView.videoFeedbackEnabled) 1f else 0f },
            "Video feedback gain" to { arCameraView.videoFeedbackGain },
            "Video feedback decay" to { arCameraView.videoFeedbackDecay },
            "Video feedback depth" to { arCameraView.videoFeedbackDepth },
            "Video feedback threshold" to { arCameraView.videoFeedbackThreshold },
            "Video feedback limiter" to { arCameraView.videoFeedbackLimiter },
            "Camera brightness" to { arCameraView.cameraBrightnessLevel },
            "Camera video brightness" to { arCameraView.cameraBrightnessLevel },
            "Camera video brightness threshold" to { arCameraView.cameraThreshold },
            "Camera video brightness bipolar" to { ((20f * kotlin.math.log10(maxOf(arCameraView.cameraBrightnessLevel, 0.000001f)) + 120f) / 120f).coerceIn(0f, 1f) },
            "Audio brightness" to { arCameraView.audioBrightnessLevel },
            "Audio colour brightness" to { arCameraView.audioColourBrightnessLevel },
            "Camera colour brightness" to { arCameraView.cameraColourBrightnessLevel },
            "Video colour brightness level" to { arCameraView.cameraColourBrightnessLevel },
            "Video colour brightness threshold" to { arCameraView.colorThreshold },
            "Video colour brightness bipolar" to { ((20f * kotlin.math.log10(maxOf(arCameraView.cameraColourBrightnessLevel, 0.000001f)) + 120f) / 120f).coerceIn(0f, 1f) },
            "GPU colour brightness" to { arCameraView.gpuColourBrightnessLevel },
            "Camera surface brightness" to { arCameraView.cameraSurfaceBrightnessLevel },
            "Visual brightness" to { arCameraView.visualBrightnessLevel },
            "Camera contrast" to { arCameraView.cameraContrastLevel },
            "Camera video contrast" to { arCameraView.cameraContrastLevel },
            "Camera video contrast threshold" to { arCameraView.cameraFeedbackThreshold },
            "Camera video contrast bipolar" to { ((20f * kotlin.math.log10(maxOf(arCameraView.cameraContrastLevel, 0.000001f)) + 120f) / 120f).coerceIn(0f, 1f) },
            "Audio contrast" to { arCameraView.audioContrastLevel },
            "Audio colour contrast" to { arCameraView.audioColourContrastLevel },
            "Camera colour contrast" to { arCameraView.cameraColourContrastLevel },
            "Video colour contrast level" to { arCameraView.cameraColourContrastLevel },
            "Video colour contrast threshold" to { arCameraView.cameraFeedbackThreshold },
            "Video colour contrast bipolar" to { ((20f * kotlin.math.log10(maxOf(arCameraView.cameraColourContrastLevel, 0.000001f)) + 120f) / 120f).coerceIn(0f, 1f) },
            "GPU colour contrast" to { arCameraView.gpuColourContrastLevel },
            "Camera surface contrast" to { arCameraView.cameraSurfaceContrastLevel },
            "Visual contrast" to { arCameraView.visualContrastLevel },
            "Audio colour feedback" to { (arCameraView.audioColorTracking * arCameraView.cameraFeedbackLevel).coerceIn(0f, 1f) },
            "Audio colour decay" to { (1f - arCameraView.audioColorTracking).coerceIn(0f, 1f) },
            "Visual colour feedback" to { (arCameraView.systemColorTracking * arCameraView.cameraFeedbackLevel).coerceIn(0f, 1f) },
            "Visual colour decay" to { (1f - arCameraView.systemColorTracking).coerceIn(0f, 1f) },
            "Virtual video feedback level" to { arCameraView.virtualColourCommunicationLevel },
            "Virtual video feedback threshold" to { arCameraView.virtualColourCommunicationThreshold },
            "Virtual video feedback gate" to { if (arCameraView.virtualColourCommunicationGateEnabled) 1f else 0f },
            "Virtual video feedback decay" to { (1f - arCameraView.virtualColourCommunicationLevel).coerceIn(0f, 1f) },
            "Virtual video animation level" to { arCameraView.virtualVideoAnimationLevel },
            "Virtual video animation threshold" to { arCameraView.virtualVideoAnimationThreshold },
            "Argument reality virtual colour tracking" to { arCameraView.argumentRealityVirtualTracking },
            "Argument reality colour brightness level" to { arCameraView.argumentRealityBrightnessLevel },
            "Argument reality colour brightness threshold" to { arCameraView.argumentRealityBrightnessThreshold },
            "Argument reality colour contrast level" to { arCameraView.argumentRealityContrastLevel },
            "Argument reality colour contrast threshold" to { arCameraView.argumentRealityContrastThreshold },
            "Argument reality colour feedback" to { (arCameraView.argumentRealityCommunicationLevel * arCameraView.cameraFeedbackLevel).coerceIn(0f, 1f) },
            "Argument reality colour decay" to { (1f - arCameraView.argumentRealityCommunicationLevel).coerceIn(0f, 1f) },
            "Argument reality colour bipolar" to { ((arCameraView.argumentRealityBipolarDb + 120f) / 120f).coerceIn(0f, 1f) },
            "Argument reality colour bipolar threshold" to { ((arCameraView.argumentRealityBipolarThresholdDb + 10000f) / 20000f).coerceIn(0f, 1f) },
            "Argument reality intensity" to { arCameraView.argumentRealityIntensity },
            "Argument reality scale" to { (arCameraView.argumentRealityScale / 10f).coerceIn(0f, 1f) },
            "Argument reality 3D active" to { if (arCameraView.argumentReality3dActive) 1f else 0f },
            "Argument reality 3D depth" to { arCameraView.argumentReality3dDepth },
            "Argument reality enemy 3D protection" to { if (arCameraView.argumentRealityEnemy3dProtection) 1f else 0f },
            "Argument reality geometry density" to { arCameraView.geometryDensity },
            "Argument reality plane gain" to { arCameraView.planeGain },
            "Argument reality wall gain" to { arCameraView.wallGain },
            "Argument reality curve gain" to { arCameraView.curveGain },
            "Argument reality ring gain" to { arCameraView.ringGain },
            "Argument reality tracked planes" to { (arCameraView.arCoreTrackedPlanes / 16f).coerceIn(0f, 1f) },
            "Argument reality shield level" to { arCameraView.argumentRealityShieldLevel },
            "Argument reality ambient shield" to { if (arCameraView.argumentRealityAmbientShieldEnabled && NativeBridge.getAmbientFftLevel() >= arCameraView.argumentRealityAmbientShieldThreshold) 1f else 0f },
            "Argument reality animation shield" to { if (arCameraView.argumentRealityAnimationShieldEnabled && arCameraView.cameraSurfaceMovement >= arCameraView.argumentRealityAnimationShieldThreshold) 1f else 0f },
            "Argument reality body shield" to { if (arCameraView.argumentRealityBodyShieldEnabled && arCameraView.bodyColorTracking >= arCameraView.argumentRealityBodyShieldThreshold) 1f else 0f },
            "Argument reality human tracking gate" to { if (arCameraView.argumentRealityHumanTrackingGateEnabled && arCameraView.trackingConfidence >= arCameraView.argumentRealityHumanTrackingThreshold) 1f else 0f },
            "Argument reality eyes shield" to { if (arCameraView.argumentRealityEyesShieldEnabled && arCameraView.eyeVisionColourTracking >= arCameraView.argumentRealityEyesShieldThreshold) 1f else 0f },
            "Argument reality spike shield" to { if (arCameraView.argumentRealitySpikeShieldEnabled && NativeBridge.getSpikeOutput() < arCameraView.argumentRealitySpikeShieldThreshold) 1f else 0f },
            "Argument reality enemy active" to { if (NativeBridge.getEnemyProtectionActive()) 1f else 0f },
            "Argument reality enemy counter" to { NativeBridge.getEnemyProtectionStatus().toFloat() / 2f },
            "Argument reality enemy mirror" to { if (NativeBridge.getEnemyProtectionActive()) 0f else 1f },
            "Argument reality warrior counter" to { ((NativeBridge.getEnemyProtectionStatus() + NativeBridge.getSpikeCount()) / 16f).coerceIn(0f, 1f) },
            "Argument reality enemy curve" to { if (NativeBridge.getMoveEnergy() >= NativeBridge.getEnemyCurveThreshold()) 1f else 0f },
            "Argument reality enemy plane" to { if (NativeBridge.getMoveEnergy() >= NativeBridge.getEnemyPlaneThreshold()) 1f else 0f },
            "Argument reality enemy wall" to { if (NativeBridge.getMoveEnergy() >= NativeBridge.getEnemyWallThreshold()) 1f else 0f },
            "Argument reality enemy ring" to { if (NativeBridge.getMoveEnergy() >= NativeBridge.getEnemyRingThreshold()) 1f else 0f },
            "Argument reality warp protection" to { (NativeBridge.getWarpRaw() * arCameraView.argumentRealityShieldLevel).coerceIn(0f, 1f) },
            "Argument reality stutter protection" to { (NativeBridge.getStutterRaw() * arCameraView.argumentRealityShieldLevel).coerceIn(0f, 1f) },
            "Argument reality warp counter" to { (NativeBridge.getWarpCounter() / 8f).coerceIn(0f, 1f) },
            "Argument reality stutter counter" to { (NativeBridge.getStutterCounter() / 8f).coerceIn(0f, 1f) },
            "Argument reality body pitch" to { arCameraView.bodyPitchProtection },
            "Argument reality body spike" to { NativeBridge.getBodyOutput() * NativeBridge.getSpikeOutput() },
            "Argument reality shield blocked" to { if (arCameraView.argumentRealityBlocked) 1f else 0f },
            "AI human visual gate" to { if (modelRuntime.humanVisualGate) 1f else 0f },
            "AI human visual protection" to { if (arCameraView.humanVisualProtectionActive) 1f else 0f },
            "AI pose landmarks" to { (modelRuntime.poseLandmarkCount / 33f).coerceIn(0f, 1f) },
            "AI face count" to { (modelRuntime.faceCount / 4f).coerceIn(0f, 1f) },
            "AI hand count" to { (modelRuntime.handCount / 4f).coerceIn(0f, 1f) },
            "AI human OBB width" to { (modelRuntime.humanBoundsRight - modelRuntime.humanBoundsLeft).coerceIn(0f, 1f) },
            "AI human OBB height" to { (modelRuntime.humanBoundsBottom - modelRuntime.humanBoundsTop).coerceIn(0f, 1f) },
            "Model body animation level" to { arCameraView.bodyMotion },
            "Model body animation threshold" to { arCameraView.argumentRealityAnimationShieldThreshold },
            "Model body animation output" to { (arCameraView.bodyMotion * arCameraView.bodySpeed).coerceIn(0f, 1f) },
            "Estimated breathing rate" to { modelRuntime.breathingRate },
            "Estimated inhale level" to { modelRuntime.inhaleLevel },
            "Estimated exhale level" to { modelRuntime.exhaleLevel },
            "Vulkan runtime available" to { if (NativeBridge.getVulkanAvailable()) 1f else 0f },
            "Quantum scene active" to { if (arCameraView.quantumSceneEnabled) 1f else 0f },
            "Quantum particle energy" to { arCameraView.quantumParticleEnergy },
            "Quantum particle density" to { arCameraView.quantumParticleDensity },
            "Quantum particle scale" to { arCameraView.quantumParticleScale },
            "Quantum particle threshold" to { arCameraView.quantumParticleThreshold },
            "Argument reality FFT level" to { arCameraView.argumentRealityFftLevel },
            "Argument reality FFT threshold" to { arCameraView.argumentRealityFftThreshold },
            "Argument reality ambient killer" to { if (arCameraView.argumentRealityAmbientKillerEnabled) 1f else 0f },
            "Argument reality ambient killer blocked" to { if (arCameraView.argumentRealityAmbientKillerBlocked) 1f else 0f },
            "Argument reality communication gate" to { if (arCameraView.argumentRealityCommunicationGateEnabled) 1f else 0f },
            "Argument reality communication blocked" to { if (arCameraView.argumentRealityCommunicationBlocked) 1f else 0f },
            "Argument reality head spike" to { NativeBridge.getHeadZone() * NativeBridge.getSpikeOutput() },
            "Argument reality head ambient" to { NativeBridge.getBodyAmbientLevel(0) },
            "Argument reality head protection" to { NativeBridge.getHeadZone() * arCameraView.argumentRealityShieldLevel },
            "Argument reality echo" to { NativeBridge.getWaveSpareWaveOutput() },
            "Argument reality body wave" to { NativeBridge.getAtomWaveEnergy() },
            "Argument reality body movement" to { NativeBridge.getMoveEnergy() },
            "Argument reality body speed" to { NativeBridge.getSpeedEnergy() },
            "Argument reality movement protection" to { if (NativeBridge.getMoveEnergy() >= NativeBridge.getThresholdedMovementThreshold()) 1f else 0f },
            "Argument reality movement threshold" to { NativeBridge.getThresholdedMovementThreshold() },
            "Argument reality speed protection" to { if (NativeBridge.getSpeedEnergy() >= NativeBridge.getThresholdedSpeedThreshold()) 1f else 0f },
            "Argument reality speed threshold" to { NativeBridge.getThresholdedSpeedThreshold() },
            "Argument reality wave protection" to { if (NativeBridge.getWaveEnergy() >= NativeBridge.getThresholdedWaveThreshold()) 1f else 0f },
            "Argument reality wave threshold" to { NativeBridge.getThresholdedWaveThreshold() },
            "Argument reality intention level" to { NativeBridge.getIntentionLevel() },
            "Argument reality intention gate" to { if (NativeBridge.getIntentionGateOpen()) 1f else 0f },
            "Argument reality intention threshold" to { ((NativeBridge.getIntentionGateThreshold() + 1000f) / 2000f).coerceIn(0f, 1f) },
            "Argument reality imagination colour" to { NativeBridge.getImaginationSpaceIntensity() },
            "Argument reality imagination gate" to { NativeBridge.getGateAmount() },
            "Argument reality imagination threshold" to { NativeBridge.getIntentionGateThreshold().let { ((it + 1000f) / 2000f).coerceIn(0f, 1f) } },
            "Argument reality atomspare movement" to { NativeBridge.getAtomSpareMoveLeft().coerceIn(0f, 1f) },
            "Argument reality atomspare wave" to { NativeBridge.getAtomSpareWaveLeft().coerceIn(0f, 1f) },
            "Argument reality atomspare speed" to { NativeBridge.getAtomSpareSpeedLeft().coerceIn(0f, 1f) },
            "Argument reality wavespare movement" to { NativeBridge.getWaveSpareMoveOutput() },
            "Argument reality wavespare wave" to { NativeBridge.getWaveSpareWaveOutput() },
            "Argument reality wavespare speed" to { NativeBridge.getWaveSpareSpeedOutput() },
            "Enemy movement threshold" to { NativeBridge.getEnemyMovementThreshold() },
            "Enemy movement output" to { NativeBridge.getMoveEnergy() },
            "Enemy speed threshold" to { NativeBridge.getEnemySpeedThreshold() },
            "Enemy speed output" to { NativeBridge.getSpeedEnergy() },
            "Enemy wave threshold" to { NativeBridge.getEnemyWaveThreshold() },
            "Enemy wave output" to { NativeBridge.getWaveEnergy() },
            "Argument reality pussy energy" to { NativeBridge.getBodyAmbientLevel(13) },
            "Argument reality pussy amplifier" to { (NativeBridge.getBodyAmbientLevel(13) * NativeBridge.getAmplifierLevel()).coerceIn(0f, 1f) },
            "Audio visual gate" to { if (NativeBridge.getMicIntensityEnabled()) 1f else 0f },
            "Audio visual level" to { NativeBridge.getMicIntensity() },
            "Audio visual threshold" to { NativeBridge.getMicIntensityThreshold() },
            "Audio visual colour" to { arCameraView.audioColorTracking },
            "Audio visual brightness" to { arCameraView.audioBrightnessLevel },
            "Audio visual contrast" to { arCameraView.audioContrastLevel },
            "Audio visual communication" to { arCameraView.virtualColourCommunicationLevel },
            "Audio visual decay" to { (1f - arCameraView.audioColorTracking).coerceIn(0f, 1f) },
            "Direction left speed" to { directionValues["LEFT_SPEED"] ?: 0f },
            "Direction left movement" to { directionValues["LEFT_MOVE"] ?: 0f },
            "Direction left waves" to { directionValues["LEFT_WAVE"] ?: 0f },
            "Direction left pitch" to { directionValues["LEFT_PITCH"] ?: 0f },
            "Direction left resonance" to { directionValues["LEFT_RESONANCE"] ?: 0f },
            "Direction right speed" to { directionValues["RIGHT_SPEED"] ?: 0f },
            "Direction right movement" to { directionValues["RIGHT_MOVE"] ?: 0f },
            "Direction right waves" to { directionValues["RIGHT_WAVE"] ?: 0f },
            "Direction right pitch" to { directionValues["RIGHT_PITCH"] ?: 0f },
            "Direction right resonance" to { directionValues["RIGHT_RESONANCE"] ?: 0f },
            "Direction center speed" to { directionValues["CENTER_SPEED"] ?: 0f },
            "Direction center movement" to { directionValues["CENTER_MOVE"] ?: 0f },
            "Direction center waves" to { directionValues["CENTER_WAVE"] ?: 0f },
            "Direction center pitch" to { directionValues["CENTER_PITCH"] ?: 0f },
            "Direction center resonance" to { directionValues["CENTER_RESONANCE"] ?: 0f },
            "Direction up speed" to { directionValues["UP_SPEED"] ?: 0f },
            "Direction up movement" to { directionValues["UP_MOVE"] ?: 0f },
            "Direction up waves" to { directionValues["UP_WAVE"] ?: 0f },
            "Direction up pitch" to { directionValues["UP_PITCH"] ?: 0f },
            "Direction up resonance" to { directionValues["UP_RESONANCE"] ?: 0f },
            "Direction down speed" to { directionValues["DOWN_SPEED"] ?: 0f },
            "Direction down movement" to { directionValues["DOWN_MOVE"] ?: 0f },
            "Direction down waves" to { directionValues["DOWN_WAVE"] ?: 0f },
            "Direction down pitch" to { directionValues["DOWN_PITCH"] ?: 0f },
            "Direction down resonance" to { directionValues["DOWN_RESONANCE"] ?: 0f },
            "Direction front speed" to { directionValues["FRONT_SPEED"] ?: 0f },
            "Direction front movement" to { directionValues["FRONT_MOVE"] ?: 0f },
            "Direction front waves" to { directionValues["FRONT_WAVE"] ?: 0f },
            "Direction front pitch" to { directionValues["FRONT_PITCH"] ?: 0f },
            "Direction front resonance" to { directionValues["FRONT_RESONANCE"] ?: 0f },
            "Direction back speed" to { directionValues["BACK_SPEED"] ?: 0f },
            "Direction back movement" to { directionValues["BACK_MOVE"] ?: 0f },
            "Direction back waves" to { directionValues["BACK_WAVE"] ?: 0f },
            "Direction back pitch" to { directionValues["BACK_PITCH"] ?: 0f },
            "Direction back resonance" to { directionValues["BACK_RESONANCE"] ?: 0f },
            "WaveSpare left pitch" to { directionValues["LEFT_PITCH"] ?: 0f },
            "WaveSpare right pitch" to { directionValues["RIGHT_PITCH"] ?: 0f },
            "WaveSpare center pitch" to { directionValues["CENTER_PITCH"] ?: 0f },
            "WaveSpare up pitch" to { directionValues["UP_PITCH"] ?: 0f },
            "WaveSpare down pitch" to { directionValues["DOWN_PITCH"] ?: 0f },
            "WaveSpare front pitch" to { directionValues["FRONT_PITCH"] ?: 0f },
            "WaveSpare back pitch" to { directionValues["BACK_PITCH"] ?: 0f },
            "WaveSpare level" to { NativeBridge.getWaveSpareLevel() },
            "WaveSpare threshold" to { NativeBridge.getWaveSpareThreshold() },
            "WaveSpare bipolar" to { ((NativeBridge.getWaveSpareBipolarDb() + 1000f) / 2000f).coerceIn(0f, 1f) },
            "Body waves" to { NativeBridge.getAtomWaveEnergy() },
            "Body movement" to { NativeBridge.getMoveEnergy() },
            "Body speed" to { NativeBridge.getBodyOutput() },
            "Sensor colour brightness" to { arCameraView.sensorColorTracking },
            "Sensor colour contrast" to { (arCameraView.sensorColorTracking - arCameraView.colorThreshold).coerceAtLeast(0f) },
            "Sensor colour threshold" to { arCameraView.colorThreshold },
            "Pussy ambient" to { NativeBridge.getBodyAmbientLevel(13) },
            "Pussy amplifier" to { NativeBridge.getBodyAmbientLevel(13) * NativeBridge.getAmplifierLevel() },
            "Face ambient" to { NativeBridge.getBodyAmbientLevel(12) },
            "Brain ambient" to { NativeBridge.getBodyAmbientLevel(7) },
            "Neck ambient" to { NativeBridge.getBodyAmbientLevel(8) },
            "Eye ambient" to { ((NativeBridge.getEyeLeftLevel() + NativeBridge.getEyeRightLevel()) * 0.5f).coerceIn(0f, 1f) },
            "Heart ambient" to { NativeBridge.getBodyAmbientLevel(9) },
            "Legs ambient" to { ((NativeBridge.getBodyAmbientLevel(5) + NativeBridge.getBodyAmbientLevel(6)) * 0.5f).coerceIn(0f, 1f) },
            "Noise ambient" to { NativeBridge.getAmbientRms().coerceIn(0f, 1f) },
            "Brain gland ambient" to { NativeBridge.getBodyAmbientLevel(15) },
            "Ear lines" to { NativeBridge.getEyeLeftLevel().coerceIn(0f, 1f) },
            "Eye lines" to { NativeBridge.getEyeRightLevel().coerceIn(0f, 1f) },
            "Brain glands" to { NativeBridge.getBodyAmbientLevel(15) },
            "Body ambient threshold" to { NativeBridge.getBodyAmbientThreshold(10) }
        )
        rawFeatureBoard = RawFeatureBoardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (420 * resources.displayMetrics.density).toInt()
            )
        }
        container.addView(rawFeatureBoard, 0)
        rows.forEach { (name, provider) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 4, 0, 4)
            }
            val title = TextView(this).apply {
                text = name
                setTextColor(android.graphics.Color.WHITE)
            }
            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val levelLabel = TextView(this).apply {
                text = "Level"
                setTextColor(android.graphics.Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(42, -2)
            }
            val level = SeekBar(this).apply {
                max = 100
                progress = 100
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val thresholdLabel = TextView(this).apply {
                text = "Th"
                setTextColor(android.graphics.Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(24, -2)
            }
            val threshold = SeekBar(this).apply {
                max = 100
                progress = 30
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val bipolarLabel = TextView(this).apply {
                text = "dB"
                setTextColor(android.graphics.Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(24, -2)
            }
            val bipolarThreshold = SeekBar(this).apply {
                max = 2000
                progress = 400
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                contentDescription = "$name bipolar threshold from -10000dB to +10000dB"
            }
            val output = TextView(this).apply {
                setTextColor(android.graphics.Color.WHITE)
                text = "RAW 0% | LEVEL 0% | TH 30% | BIPOLAR -120dB"
            }
            controls.addView(levelLabel)
            controls.addView(level)
            controls.addView(thresholdLabel)
            controls.addView(threshold)
            controls.addView(bipolarLabel)
            controls.addView(bipolarThreshold)
            row.addView(title)
            row.addView(controls)
            row.addView(output)
            container.addView(row)
            val featureRow = RawFeatureRow(
                name,
                provider,
                output,
                level,
                threshold,
                bipolarThreshold,
                { directionCounters[name.uppercase().removePrefix("DIRECTION_").replace(' ', '_')] ?: 0 }
            )
            rawFeatureRows += featureRow
            level.setOnSeekBarChangeListener(simpleSeek { updateRawFeatureTelemetry() })
            threshold.setOnSeekBarChangeListener(simpleSeek { updateRawFeatureTelemetry() })
            bipolarThreshold.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    updateRawFeatureTelemetry()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
    }

    private fun updateRawFeatureTelemetry() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastRawTelemetryUpdateMs < 100L) return
        lastRawTelemetryUpdateMs = now
        if (::rawFeatureBoard.isInitialized) {
            rawFeatureBoard.channels = rawFeatureRows.map { row ->
                RawFeatureBoardView.Channel(
                    row.name,
                    row.provider().coerceIn(0f, 1f),
                    row.threshold.progress / 100f
                )
            }
        }
        rawFeatureRows.forEach { row ->
            val raw = row.provider().coerceIn(0f, 1f)
            val level = row.level.progress / 100f
            val threshold = row.threshold.progress / 100f
            val active = raw >= threshold
            val scaled = if (active) (raw * level).coerceIn(0f, 1f) else 0f
            val db = 20f * kotlin.math.log10(maxOf(raw, 0.000001f))
            val bipolar = 20f * kotlin.math.log10(maxOf(scaled, 0.000001f))
            val bipolarThreshold = row.bipolarThreshold.progress * 10f - 10000f
            val bipolarActive = bipolar >= bipolarThreshold
            row.output.text = "${row.name.uppercase()} | RAW ${(raw * 100).toInt()}% | OUTPUT ${(scaled * 100).toInt()}% | LEVEL ${(level * 100).toInt()}% | TH ${(threshold * 100).toInt()}% | ${if (active) "ACTIVE" else "QUIET"} | BIPOLAR ${bipolar.toInt()}dB | TH ${bipolarThreshold.toInt()}dB | ${if (bipolarActive) "PASS" else "HOLD"} | COUNT ${row.counter()} (RAW ${db.toInt()}dB)"
        }
    }

    private fun bindSpatialDirectionControls() {
        val container = findViewById<LinearLayout>(R.id.spatialDirectionControls) ?: return
        val directions = listOf(
            "LEFT" to { directionValues["LEFT_SPEED"] ?: 0f },
            "RIGHT" to { directionValues["RIGHT_SPEED"] ?: 0f },
            "FRONT" to { directionValues["FRONT_SPEED"] ?: 0f },
            "BACK" to { directionValues["BACK_SPEED"] ?: 0f },
            "CENTER" to { directionValues["CENTER_SPEED"] ?: 0f },
            "UP" to { directionValues["UP_SPEED"] ?: 0f },
            "DOWN" to { directionValues["DOWN_SPEED"] ?: 0f }
        )
        val signals = listOf(
            "WARP" to { direction: String ->
                val base = directions.first { it.first == direction }.second()
                (base * NativeBridge.getWarpRaw()).coerceIn(0f, 1f)
            },
            "STUTTER" to { direction: String ->
                val base = directions.first { it.first == direction }.second()
                (base * NativeBridge.getStutterRaw()).coerceIn(0f, 1f)
            }
        )
        signals.forEach { (signalName, signalProvider) ->
            directions.forEach { (directionName, _) ->
                val name = "$signalName $directionName"
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, 3, 0, 3)
                }
                val title = TextView(this).apply {
                    text = name
                    setTextColor(android.graphics.Color.WHITE)
                }
                val threshold = SeekBar(this).apply {
                    max = 100
                    progress = 50
                    layoutParams = LinearLayout.LayoutParams(-1, -2)
                }
                val output = TextView(this).apply {
                    setTextColor(android.graphics.Color.WHITE)
                    text = "$name | LEVEL 0% | THRESHOLD 50% | OUTPUT 0%"
                }
                row.addView(title)
                row.addView(threshold)
                row.addView(output)
                container.addView(row)
                val spatialRow = SpatialDirectionRow(name, { signalProvider(directionName) }, output, threshold)
                spatialDirectionRows += spatialRow
                threshold.setOnSeekBarChangeListener(simpleSeek { updateSpatialDirectionControls() })
            }
        }
        updateSpatialDirectionControls()
    }

    private fun updateSpatialDirectionControls() {
        spatialDirectionRows.forEach { row ->
            val level = row.provider().coerceIn(0f, 1f)
            val threshold = row.threshold.progress / 100f
            val output = if (level >= threshold) level else 0f
            row.output.text = "${row.name} | LEVEL ${(level * 100).toInt()}% | THRESHOLD ${(threshold * 100).toInt()}% | OUTPUT ${(output * 100).toInt()}% | ${if (output > 0f) "ACTIVE" else "QUIET"}"
        }
    }

    private fun updateDirectionMixers(
        speed: Float,
        movement: Float,
        wave: Float,
        eye: Float,
        cameraSpeed: Float,
        cameraMovement: Float,
        cameraWave: Float
    ) {
        val left = (eye * 0.65f + (1f - cameraMovement) * 0.35f).coerceIn(0f, 1f)
        val right = ((1f - eye) * 0.65f + cameraMovement * 0.35f).coerceIn(0f, 1f)
        val center = ((left + right + speed) / 3f).coerceIn(0f, 1f)
        val up = ((NativeBridge.getHeadZone() + NativeBridge.getChestZone()) * 0.5f).coerceIn(0f, 1f)
        val down = ((NativeBridge.getAbdomenZone() + NativeBridge.getLeftLegZone() + NativeBridge.getRightLegZone()) / 3f).coerceIn(0f, 1f)
        val front = ((cameraSpeed + cameraWave + arCameraView.trackingConfidence) / 3f).coerceIn(0f, 1f)
        val back = ((audioColorForDirection() + arCameraView.enemyColorTracking + arCameraView.virtualColorTracking) / 3f).coerceIn(0f, 1f)
        val directions = mapOf(
            "LEFT" to left, "RIGHT" to right, "CENTER" to center,
            "UP" to up, "DOWN" to down, "FRONT" to front, "BACK" to back
        )
        directions.forEach { (name, base) ->
            mapOf(
                "SPEED" to (base * speed).coerceIn(0f, 1f),
                "MOVE" to (base * movement + cameraMovement * 0.2f).coerceIn(0f, 1f),
                "WAVE" to (base * wave + cameraWave * 0.2f).coerceIn(0f, 1f),
                "PITCH" to (base * NativeBridge.getPitchOutputLevel()).coerceIn(0f, 1f),
                "RESONANCE" to if (NativeBridge.getResonanceModeEnabled()) {
                    (base * NativeBridge.getResonanceStrength()).coerceIn(0f, 1f)
                } else {
                    0f
                }
            ).forEach { (kind, value) ->
                val key = "${name}_${kind}"
                directionValues[key] = value
                if (value >= 0.5f) directionCounters[key] = (directionCounters[key] ?: 0) + 1
            }
        }
    }

    private fun audioColorForDirection(): Float =
        NativeBridge.getAmbientFftLevel().coerceIn(0f, 1f)

    override fun onPause() {
        super.onPause()
        sensorTelemetry.stop()
        modelRuntime.close()
        arCameraView.onPauseSession()
        stopMicCapture()
    }

    override fun onResume() {
        super.onResume()
        sensorTelemetry.start()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            arCameraView.onResumeSession()
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startMicCapture()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        sensorTelemetry.stop()
        arCameraView.closeSession()
        stopMicCapture()
        NativeBridge.nativeRelease()
        super.onDestroy()
    }
}