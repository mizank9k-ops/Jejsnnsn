package com.atomicworld.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

class WaveSpareBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {
    private var running = false
    private var thread: Thread? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init { holder.addCallback(this) }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this, "wavespare-board").also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join(300)
        thread = null
    }

    override fun run() {
        while (running) {
            val canvas = holder.lockCanvas()
            if (canvas != null) {
                try { drawBoard(canvas) } finally { holder.unlockCanvasAndPost(canvas) }
            }
            Thread.sleep(33)
        }
    }

    private fun drawBoard(canvas: Canvas) {
        val width = canvas.width.toFloat()
        val height = canvas.height.toFloat()
        canvas.drawColor(Color.rgb(8, 20, 28))
        paint.style = Paint.Style.FILL
        paint.color = Color.CYAN
        paint.textSize = 24f
        canvas.drawText("WAVESPARE BOARD  MIC -> WAVESPARE  RAW OUTPUT", 12f, 28f, paint)

        val speed = NativeBridge.getWaveSpareSpeedOutput().coerceIn(0f, 1f)
        val move = NativeBridge.getWaveSpareMoveOutput().coerceIn(0f, 1f)
        val wave = NativeBridge.getWaveSpareWaveOutput().coerceIn(0f, 1f)
        val threshold = NativeBridge.getWaveSpareThreshold().coerceIn(0f, 1f)
        val bipolar = NativeBridge.getWaveSpareBipolarDb()
        val active = NativeBridge.getWaveSpareActive()
        val baseline = height * 0.72f
        drawBar(canvas, width * 0.18f, baseline, speed, Color.CYAN, "SPEED")
        drawBar(canvas, width * 0.50f, baseline, move, Color.GREEN, "MOVE")
        drawBar(canvas, width * 0.82f, baseline, wave, Color.YELLOW, "WAVE")

        paint.color = Color.WHITE
        paint.textSize = 17f
        canvas.drawText("THRESHOLD ${(threshold * 100f).toInt()}%  |  ${if (active) "ACTIVE" else "QUIET"}", 12f, height - 32f, paint)
        canvas.drawText("RAW SPEED ${(speed * 100f).toInt()}%  MOVE ${(move * 100f).toInt()}%  WAVE ${(wave * 100f).toInt()}%  BIPOLAR ${bipolar.toInt()}dB", 12f, height - 10f, paint)
    }

    private fun drawBar(canvas: Canvas, x: Float, baseline: Float, value: Float, color: Int, label: String) {
        val barHeight = value * 68f
        paint.color = color
        paint.style = Paint.Style.FILL
        canvas.drawRect(x - 20f, baseline - barHeight, x + 20f, baseline, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawRect(x - 24f, baseline - 72f, x + 24f, baseline + 2f, paint)
        paint.style = Paint.Style.FILL
        paint.textSize = 17f
        canvas.drawText("$label ${(value * 100f).toInt()}%", x - 34f, baseline + 24f, paint)
    }
}
