package com.atomicworld.app

import android.content.Context
import android.media.Image
import com.google.mediapipe.framework.image.MediaImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

class ModelRuntime(context: Context) {
    var status: String = "MODELS NOT LOADED"
        private set
    private var pose: PoseLandmarker? = null
    private var face: FaceLandmarker? = null
    private var hand: HandLandmarker? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val lastTimestamp = AtomicLong(-1L)
    @Volatile var lastInference: String = "INFERENCE WAITING"
        private set
    @Volatile var poseLandmarkCount = 0
        private set
    @Volatile var faceCount = 0
        private set
    @Volatile var handCount = 0
        private set
    @Volatile var humanBoundsLeft = 0f
        private set
    @Volatile var humanBoundsTop = 0f
        private set
    @Volatile var humanBoundsRight = 0f
        private set
    @Volatile var humanBoundsBottom = 0f
        private set
    @Volatile var humanVisualGate = false
        private set
    @Volatile var breathingRate = 0f
        private set
    @Volatile var inhaleLevel = 0f
        private set
    @Volatile var exhaleLevel = 0f
        private set
    private var previousChestY = Float.NaN
    private var previousBreathTimestamp = -1L

    init {
        runCatching {
            val poseOptions = PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(base("models/pose_landmarker_full.task"))
                .setRunningMode(RunningMode.VIDEO)
                .build()
            val faceOptions = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(base("models/face_landmarker.task"))
                .setRunningMode(RunningMode.VIDEO)
                .build()
            val handOptions = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base("models/hand_landmarker.task"))
                .setRunningMode(RunningMode.VIDEO)
                .build()
            pose = PoseLandmarker.createFromOptions(context, poseOptions)
            face = FaceLandmarker.createFromOptions(context, faceOptions)
            hand = HandLandmarker.createFromOptions(context, handOptions)
            status = "MODELS LOADED: POSE FACE HAND"
        }.onFailure {
            status = "MODEL LOAD ERROR: ${it.javaClass.simpleName}"
        }
    }

    private fun base(asset: String): BaseOptions = BaseOptions.builder()
        .setModelAssetPath(asset)
        .build()

    fun process(image: Image, timestampMs: Long) {
        if (timestampMs <= lastTimestamp.get()) {
            image.close()
            return
        }
        lastTimestamp.set(timestampMs)
        executor.execute {
            runCatching {
                val mpImage = MediaImageBuilder(image).build()
                val poseResult = pose?.detectForVideo(mpImage, timestampMs)
                val faceResult = face?.detectForVideo(mpImage, timestampMs)
                val handResult = hand?.detectForVideo(mpImage, timestampMs)
                val poseLandmarks = poseResult?.landmarks()?.firstOrNull().orEmpty()
                poseLandmarkCount = poseLandmarks.size
                faceCount = faceResult?.faceLandmarks()?.size ?: 0
                handCount = handResult?.landmarks()?.size ?: 0
                if (poseLandmarks.isNotEmpty()) {
                    humanBoundsLeft = poseLandmarks.minOf { it.x() }.coerceIn(0f, 1f)
                    humanBoundsTop = poseLandmarks.minOf { it.y() }.coerceIn(0f, 1f)
                    humanBoundsRight = poseLandmarks.maxOf { it.x() }.coerceIn(0f, 1f)
                    humanBoundsBottom = poseLandmarks.maxOf { it.y() }.coerceIn(0f, 1f)
                } else {
                    humanBoundsLeft = 0f
                    humanBoundsTop = 0f
                    humanBoundsRight = 0f
                    humanBoundsBottom = 0f
                }
                humanVisualGate = poseLandmarks.isNotEmpty() || faceCount > 0
                if (poseLandmarks.size > 12) {
                    val chestY = (poseLandmarks[11].y() + poseLandmarks[12].y()) * 0.5f
                    if (!previousChestY.isNaN() && previousBreathTimestamp > 0L) {
                        val delta = chestY - previousChestY
                        val elapsedSeconds = ((timestampMs - previousBreathTimestamp).coerceAtLeast(1L)) / 1000f
                        breathingRate = (kotlin.math.abs(delta) / elapsedSeconds * 6f).coerceIn(0f, 1f)
                        inhaleLevel = (-delta * 24f).coerceIn(0f, 1f)
                        exhaleLevel = (delta * 24f).coerceIn(0f, 1f)
                    }
                    previousChestY = chestY
                    previousBreathTimestamp = timestampMs
                }
                lastInference = "INFERENCE LIVE POSE $poseLandmarkCount FACE $faceCount HAND $handCount"
            }.onFailure {
                lastInference = "INFERENCE ERROR: ${it.javaClass.simpleName}"
            }.also {
                image.close()
            }
        }
    }

    fun close() {
        executor.shutdownNow()
        pose?.close()
        face?.close()
        hand?.close()
    }
}
