package com.atomicworld.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

class MotionBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {
    @Volatile var speed = 0f
    @Volatile var move = 0f
    @Volatile var wave = 0f
    @Volatile var threshold = 0.2f
    @Volatile var modelName = "MOTION MODEL"
    private var phase = 0f
    private var running = false
    private var thread: Thread? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init { holder.addCallback(this) }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this, "motion-board").also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join(300)
        thread = null
    }

    override fun run() {
        while (running) {
            val canvas = holder.lockCanvas()
            if (canvas != null) {
                try { drawBoard(canvas) } finally { holder.unlockCanvasAndPost(canvas) }
            }
            phase += 0.12f
            Thread.sleep(33)
        }
    }

    private fun drawBoard(canvas: Canvas) {
        val width = canvas.width.toFloat()
        val height = canvas.height.toFloat()
        canvas.drawColor(Color.rgb(10, 18, 28))
        paint.style = Paint.Style.FILL
        paint.color = Color.CYAN
        paint.textSize = 24f
        canvas.drawText("ATOMSPARE BOARD  MIC -> ATOMSPARE  $modelName", 12f, 28f, paint)
        drawSignal(canvas, width * 0.18f, height * 0.56f, speed, Color.CYAN, "SPEED")
        drawSignal(canvas, width * 0.50f, height * 0.56f, move, Color.GREEN, "MOVE")
        drawSignal(canvas, width * 0.82f, height * 0.56f, wave, Color.YELLOW, "WAVE")
    }

    private fun drawSignal(canvas: Canvas, x: Float, baseline: Float, level: Float, color: Int, label: String) {
        val value = level.coerceIn(0f, 1f)
        val barHeight = value * 75f
        paint.color = color
        paint.style = Paint.Style.FILL
        canvas.drawRect(x - 18f, baseline - barHeight, x + 18f, baseline, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawRect(x - 22f, baseline - 78f, x + 22f, baseline + 2f, paint)
        paint.style = Paint.Style.FILL
        paint.textSize = 18f
        canvas.drawText("$label ${(value * 100).toInt()}%", x - 35f, baseline + 28f, paint)
        paint.color = Color.WHITE
        canvas.drawCircle(x, baseline - barHeight, 4f + kotlin.math.abs(kotlin.math.sin(phase)) * 3f, paint)
    }
}
