package com.atomicworld.app

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

/**
 * Body diagram SurfaceView – visual detection board for AtomSpare zones.
 */
class BodyDiagramView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    @Volatile private var running = false

    // Zone energies 0..1
    @Volatile var head = 0f
    @Volatile var chest = 0f
    @Volatile var abdomen = 0f
    @Volatile var leftArm = 0f
    @Volatile var rightArm = 0f
    @Volatile var leftLeg = 0f
    @Volatile var rightLeg = 0f
    @Volatile var eyeLeft = 0f
    @Volatile var eyeRight = 0f
    @Volatile var eyeModelName = "EYE MODEL"

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#1A2333")
    }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#00E5FF")
    }
    private val zonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        textAlign = Paint.Align.CENTER
    }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        textSize = 36f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    init {
        holder.addCallback(this)
        setZOrderOnTop(false)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        try { thread?.join(300) } catch (_: InterruptedException) {}
    }

    override fun run() {
        while (running) {
            val canvas = holder.lockCanvas() ?: continue
            try {
                drawBody(canvas)
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }
            try { Thread.sleep(33) } catch (_: InterruptedException) {}
        }
    }

    private fun drawBody(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val h = canvas.height.toFloat()
        canvas.drawColor(Color.parseColor("#0B0F1A"))

        canvas.drawText("ATOMSPARE DETECTION BOARD  $eyeModelName", w / 2f, 50f, titlePaint)

        val cx = w / 2f
        val scale = h * 0.72f
        val top = h * 0.12f

        drawEye(canvas, cx - scale * 0.045f, top + scale * 0.075f, eyeLeft, "L")
        drawEye(canvas, cx + scale * 0.045f, top + scale * 0.075f, eyeRight, "R")

        // Head
        drawZone(canvas, cx, top + scale * 0.08f, scale * 0.09f, head, "HEAD")

        // Chest
        val chestRect = RectF(cx - scale * 0.14f, top + scale * 0.18f,
            cx + scale * 0.14f, top + scale * 0.38f)
        drawZoneRect(canvas, chestRect, chest, "CHEST")

        // Abdomen
        val abdRect = RectF(cx - scale * 0.12f, top + scale * 0.38f,
            cx + scale * 0.12f, top + scale * 0.55f)
        drawZoneRect(canvas, abdRect, abdomen, "ABDOMEN")

        // Left Arm
        val laRect = RectF(cx - scale * 0.32f, top + scale * 0.20f,
            cx - scale * 0.16f, top + scale * 0.45f)
        drawZoneRect(canvas, laRect, leftArm, "L-ARM")

        // Right Arm
        val raRect = RectF(cx + scale * 0.16f, top + scale * 0.20f,
            cx + scale * 0.32f, top + scale * 0.45f)
        drawZoneRect(canvas, raRect, rightArm, "R-ARM")

        // Left Leg
        val llRect = RectF(cx - scale * 0.13f, top + scale * 0.55f,
            cx - scale * 0.02f, top + scale * 0.92f)
        drawZoneRect(canvas, llRect, leftLeg, "L-LEG")

        // Right Leg
        val rlRect = RectF(cx + scale * 0.02f, top + scale * 0.55f,
            cx + scale * 0.13f, top + scale * 0.92f)
        drawZoneRect(canvas, rlRect, rightLeg, "R-LEG")
    }

    private fun drawZone(canvas: Canvas, x: Float, y: Float, r: Float, energy: Float, label: String) {
        zonePaint.color = energyToColor(energy)
        canvas.drawCircle(x, y, r, zonePaint)
        canvas.drawCircle(x, y, r, outlinePaint)
        canvas.drawText(label, x, y + r + 28f, textPaint)
    }

    private fun drawZoneRect(canvas: Canvas, rect: RectF, energy: Float, label: String) {
        zonePaint.color = energyToColor(energy)
        canvas.drawRoundRect(rect, 18f, 18f, zonePaint)
        canvas.drawRoundRect(rect, 18f, 18f, outlinePaint)
        canvas.drawText(label, rect.centerX(), rect.bottom + 26f, textPaint)
    }

    private fun drawEye(canvas: Canvas, x: Float, y: Float, energy: Float, label: String) {
        zonePaint.color = energyToColor(energy)
        canvas.drawCircle(x, y, 16f + energy.coerceIn(0f, 1f) * 10f, zonePaint)
        canvas.drawCircle(x, y, 16f + energy.coerceIn(0f, 1f) * 10f, outlinePaint)
        canvas.drawText("EYE-$label", x, y - 30f, textPaint)
    }

    private fun energyToColor(e: Float): Int {
        val t = e.coerceIn(0f, 1f)
        // From dark blue → cyan → yellow → red
        return when {
            t < 0.33f -> {
                val k = t / 0.33f
                Color.rgb((20 + 30 * k).toInt(), (40 + 80 * k).toInt(), (80 + 100 * k).toInt())
            }
            t < 0.66f -> {
                val k = (t - 0.33f) / 0.33f
                Color.rgb((50 + 180 * k).toInt(), (120 + 100 * k).toInt(), (180 - 100 * k).toInt())
            }
            else -> {
                val k = (t - 0.66f) / 0.34f
                Color.rgb((230 + 25 * k).toInt(), (220 - 180 * k).toInt(), (80 - 60 * k).toInt())
            }
        }
    }

    fun updateZones(
        head: Float, chest: Float, abdomen: Float,
        leftArm: Float, rightArm: Float,
        leftLeg: Float, rightLeg: Float
    ) {
        this.head = head
        this.chest = chest
        this.abdomen = abdomen
        this.leftArm = leftArm
        this.rightArm = rightArm
        this.leftLeg = leftLeg
        this.rightLeg = rightLeg
    }

    fun updateEyes(left: Float, right: Float) {
        eyeLeft = left.coerceIn(0f, 1f)
        eyeRight = right.coerceIn(0f, 1f)
    }
}