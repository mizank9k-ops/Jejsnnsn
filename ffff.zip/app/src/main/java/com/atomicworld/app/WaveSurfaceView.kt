package com.atomicworld.app

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.sin

/**
 * SurfaceView showing live AtomSpare Wave energy as oscillating waveform.
 */
class WaveSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile var energy = 0.3f
    @Volatile var animationSpeed = 0.5f
    @Volatile var smoothness = 0.6f
    @Volatile var label = "WAVE"

    private val bgPaint = Paint().apply { color = Color.parseColor("#0B0F1A") }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.parseColor("#00E5FF")
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#3300E5FF")
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 32f
        textAlign = Paint.Align.LEFT
    }

    private var phase = 0f

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        try { thread?.join(300) } catch (_: InterruptedException) {}
    }

    override fun run() {
        while (running) {
            val canvas = holder.lockCanvas() ?: continue
            try {
                drawWave(canvas)
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }
            val motionScale = (0.08f + animationSpeed.coerceIn(0f, 1f) * 0.55f) * (0.8f + smoothness.coerceIn(0f, 1f) * 0.7f)
            phase += motionScale
            try { Thread.sleep(30) } catch (_: InterruptedException) {}
        }
    }

    private fun drawWave(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val h = canvas.height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val mid = h / 2f
        val visualEnergy = energy.coerceIn(0f, 1f) *
            (0.6f + smoothness.coerceIn(0f, 1f) * 0.9f)
        val amp = (h * 0.35f) * visualEnergy

        val path = Path()
        path.moveTo(0f, mid)
        val steps = 60
        for (i in 0..steps) {
            val x = w * i / steps
            val y = mid + sin(phase + i * 0.25f * (1.0f + smoothness.coerceIn(0f, 1f))) * amp
            path.lineTo(x, y)
        }
        path.lineTo(w, h)
        path.lineTo(0f, h)
        path.close()

        canvas.drawPath(path, fillPaint)

        // Outline
        val outline = Path()
        outline.moveTo(0f, mid)
        for (i in 0..steps) {
            val x = w * i / steps
            val y = mid + sin(phase + i * 0.25f * (1.0f + smoothness.coerceIn(0f, 1f))) * amp
            outline.lineTo(x, y)
        }
        canvas.drawPath(outline, linePaint)

        val displayValue = (energy * 100f).coerceIn(0f, 100f)
        canvas.drawText("$label  ${"%.0f".format(displayValue)}%", 16f, 40f, textPaint)
    }
}