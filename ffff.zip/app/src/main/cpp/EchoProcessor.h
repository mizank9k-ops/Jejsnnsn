#pragma once
#include <atomic>
#include <cmath>
#include <algorithm>

class EchoProcessor {
public:
    EchoProcessor();
    void process(float* left, float* right, int numFrames);

    void setEnabled(bool v)           { enabled.store(v); }
    void setDelayMs(float v)          { delayMs.store(v); }
    void setFeedback(float v)         { feedback.store(v); }
    void setMix(float v)              { mix.store(v); }
    void setGateEnabled(bool v)       { gateEnabled.store(v); }
    void setGateThreshold(float v)    { gateThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    
    // Echo Protection and Smoothing
    void setProtectionEnabled(bool v) { protectionEnabled.store(v); }
    void setSmoothingFactor(float v)  { smoothingFactor.store(std::clamp(v, 0.0f, 1.0f)); }
    bool getProtectionActive() const  { return protectionActive.load(); }

private:
    std::atomic<bool>  enabled{true};
    std::atomic<float> delayMs{160.0f};
    std::atomic<float> feedback{0.32f};
    std::atomic<float> mix{0.38f};
    std::atomic<bool> gateEnabled{true};
    std::atomic<float> gateThreshold{0.40f};
    
    // Protection and smoothing
    std::atomic<bool>  protectionEnabled{true};
    std::atomic<float> smoothingFactor{0.5f};
    std::atomic<bool>  protectionActive{false};
    
    float lastOutL = 0.0f;
    float lastOutR = 0.0f;
    float lastFeedbackL = 0.0f;
    float lastFeedbackR = 0.0f;

    static constexpr int MAX_DELAY = 48000 * 2;
    static constexpr float MAX_AMPLITUDE = 1.5f;
    
    float delayL[MAX_DELAY]{};
    float delayR[MAX_DELAY]{};
    int writePos = 0;
    
    inline float applySoftClipping(float x) const {
        if (x > 1.0f)  return 1.0f - expf(-(x - 1.0f) * 2.0f);
        if (x < -1.0f) return -1.0f + expf((x + 1.0f) * 2.0f);
        return x;
    }
};