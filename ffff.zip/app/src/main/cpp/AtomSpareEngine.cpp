#include "AtomSpareEngine.h"
#include <cstring>

AtomSpareEngine::AtomSpareEngine() {
    for (int i = 0; i < 16; ++i) {
        bodyThresholds[i].store(0.3f);
        bodyLevels[i].store(0.0f);
        bodyBipolarDb[i].store(-120.0f);
        bodyCounters[i].store(0);
    }
}

void AtomSpareEngine::setAdvancedValue(int control, float value) {
    value = std::clamp(value, 0.0f, 1.0f);
    switch (control) {
        case WIND_LEVEL: windLevel.store(value); break;
        case WIND_THRESHOLD: windThreshold.store(value); break;
        case MOVEMENT_SPEED: movementSpeed.store(value); break;
        case MOVEMENT_THRESHOLD: movementThreshold.store(value); break;
        case MOVEMENT_SMOOTH: movementSmooth.store(value); break;
        case ATOM_INTENSITY: atomIntensity.store(value); break;
        case WAVE_INTENSITY: waveIntensity.store(value); break;
        case VISUAL_THRESHOLD: visualThreshold.store(value); break;
        case ECHO_THRESHOLD: echoThreshold.store(value); break;
        case PITCH_SPEED: pitchSpeed.store(value); break;
        case PITCH_LEVEL: pitchLevel.store(value); break;
        case PITCH_THRESHOLD: pitchThreshold.store(value); break;
        case PITCH_SMOOTH: pitchSmooth.store(value); break;
        case EYE_MOVE_SPEED: eyeMoveSpeed.store(value); break;
        case EYE_WAVE_LEVEL: eyeWaveLevel.store(value); break;
        case EYE_THRESHOLD: eyeThreshold.store(value); break;
        case EYE_PITCH_THRESHOLD: eyePitchThreshold.store(value); break;
        case EYE_PROTECTION_THRESHOLD: eyeProtectionThreshold.store(value); break;
        case EYE_VISION_THRESHOLD: eyeVisionThreshold.store(value); break;
        default: break;
    }
}

void AtomSpareEngine::setAdvancedEnabled(int control, bool enabled) {
    switch (control) {
        case WIND_LEVEL: windEnabled.store(enabled); break;
        case ATOM_INTENSITY: atomGateEnabled.store(enabled); break;
        case WAVE_INTENSITY: waveGateEnabled.store(enabled); break;
        case VISUAL_THRESHOLD: visualGateEnabled.store(enabled); break;
        case ECHO_THRESHOLD: echoGateEnabled.store(enabled); break;
        case EYE_MOVE_SPEED: eyeMoveEnabled.store(enabled); break;
        case EYE_WAVE_LEVEL: eyeWaveEnabled.store(enabled); break;
        case EYE_VISION_THRESHOLD: eyeVisionEnabled.store(enabled); break;
        case EYE_PROTECTION_THRESHOLD: eyeProtectionEnabled.store(enabled); break;
        default: break;
    }
}

void AtomSpareEngine::process(float* left, float* right, int numFrames) {
    if (!left || !right || numFrames <= 0) return;

    if (!microphoneEnabled.load()) {
        rawMicRms.store(0.0f);
        rawMicPeak.store(0.0f);
        std::fill(left, left + numFrames, 0.0f);
        std::fill(right, right + numFrames, 0.0f);
        return;
    }

    const float inputGain = microphoneGain.load();
    float rawSquares = 0.0f;
    float rawPeak = 0.0f;
    for (int i = 0; i < numFrames; ++i) {
        left[i] *= inputGain;
        right[i] *= inputGain;
        const float rawMono = 0.5f * (left[i] + right[i]);
        if (amplifierEnabled.load() && std::fabs(rawMono) >= amplifierThreshold.load()) {
            const float amplifier = 1.0f + amplifierGain.load() * amplifierLevel.load();
            left[i] *= amplifier;
            right[i] *= amplifier;
        }
        rawSquares += rawMono * rawMono;
        rawPeak = std::max(rawPeak, std::fabs(rawMono));
    }
    rawMicRms.store(std::sqrt(rawSquares / static_cast<float>(numFrames)));
    rawMicPeak.store(std::clamp(rawPeak, 0.0f, 1.0f));

    float speedVal = atomSpareSpeed.load();
    float moveVal  = atomSpareMove.load();
    float waveVal  = atomSpareWave.load();
    float waveSpareWaveVal = waveSpareWave.load();
    float resonanceVal = resonanceStrength.load();
    float roboticVal = roboticBias.load();

    bool speedOn = atomSpareSpeedEnabled.load();
    bool moveOn  = atomSpareMoveEnabled.load();
    bool waveOn  = atomSpareWaveEnabled.load();
    bool waveSpareWaveOn = waveSpareWaveEnabled.load();
    bool resonanceOn = resonanceModeEnabled.load();
    bool roboticOn = roboticModeEnabled.load();

    float sumAbs = 0.0f;
    float sumDiff = 0.0f;
    float sumWave = 0.0f;
    float sumMotion = 0.0f;
    float sumSquares = 0.0f;
    float sumBipolarSquares = 0.0f;
    float sumLeftEnergy = 0.0f;
    float sumRightEnergy = 0.0f;
    int zeroCrossings = 0;
    int spikes = 0;
    const float configuredSpikeThreshold = spikeThreshold.load();

    for (int i = 0; i < numFrames; ++i) {
        float l = left[i];
        float r = right[i];
        float absL = std::fabs(l);
        float absR = std::fabs(r);
        float energy = 0.5f * (absL + absR);
        float diff   = std::fabs(l - r);
        float mono = 0.5f * (l + r);
        float motion = std::fabs(mono - previousInput);
        float bipolar = 0.5f * (l - r);
        sumLeftEnergy += absL;
        sumRightEnergy += absR;
        if (i > 0 && ((mono >= 0.0f) != (previousInput >= 0.0f))) zeroCrossings++;
        previousInput = mono;
        sumSquares += mono * mono;
        sumBipolarSquares += bipolar * bipolar;
        float pitchRate = 0.04f + pitchSpeed.load() * 0.16f;
        float pitchPulse = 1.0f + pitchLevel.load() * 0.25f * std::sin(i * pitchRate);
        float wave = energy * (0.6f + 0.4f * std::sin(i * 0.15f)) * pitchPulse;
        if (energy < pitchThreshold.load()) wave *= 0.5f + pitchSmooth.load() * 0.5f;

        float resonancePulse = resonanceOn ? (1.0f + resonanceVal * std::sin(i * 0.09f + resonanceVal * 3.0f)) : 1.0f;
        float roboticPulse = roboticOn ? (1.0f + roboticVal * std::cos(i * 0.11f + roboticVal * 4.0f)) : 1.0f;
        float pulseMix = resonancePulse * roboticPulse;

        energy *= pulseMix;
        wave *= pulseMix;

        sumAbs  += energy;
        sumDiff += (diff + motion * 2.5f) * pulseMix;
        sumMotion += motion;
        sumWave += wave;
        if (motion >= configuredSpikeThreshold) spikes++;

        if (speedOn) {
            float activeSpeed = energy >= atomSpareSpeedThreshold.load() ? speedVal : 0.0f;
            if (energy < atomSpaceCurvatureThreshold.load()) activeSpeed = 0.0f;
            float atten = 1.0f - (activeSpeed * 0.55f * energy * atomSpareSpeedBoost.load());
            atten = std::clamp(atten, 0.2f, 1.0f);
            left[i]  *= atten;
            right[i] *= atten;
        }

        if (moveOn) {
            float shift = (moveVal - 0.5f) * 0.8f;
            left[i]  *= (1.0f - shift);
            right[i] *= (1.0f + shift);
        }

        if (waveOn) {
            float mod = 1.0f - waveVal * 0.4f * std::sin(i * 0.08f + waveVal * 6.28f);
            mod = std::pow(std::max(mod, 0.0f), 1.0f + atomSpaceCurvature.load() * 0.4f);
            left[i]  *= mod;
            right[i] *= mod;
        }
        if (waveSpareWaveOn) {
            float mod = 1.0f - waveSpareWaveVal * 0.25f * std::cos(i * 0.06f + waveSpareWaveVal * 6.28f);
            if (waveSpareLevel.load() < waveSpaceCurvatureThreshold.load()) mod = 1.0f;
            mod = std::pow(std::max(mod, 0.0f), 1.0f + waveSpaceCurvature.load() * 0.4f);
            left[i] *= mod;
            right[i] *= mod;
        }

        if (resonanceOn) {
            float resonanceMod = 1.0f + resonanceVal * 0.35f;
            left[i] *= resonanceMod;
            right[i] *= resonanceMod;
        }

        if (roboticOn) {
            float roboticShift = (roboticVal - 0.5f) * 0.7f;
            left[i] *= (1.0f + roboticShift);
            right[i] *= (1.0f - roboticShift);
        }

        if (audioGenEnabled.load()) {
            float generated = std::sin(audioGenPhase) * audioGenDensity.load() * 0.12f;
            left[i] += generated;
            right[i] += generated;
            audioGenPhase += 0.02f + audioGenSpeed.load() * 0.18f;
            if (audioGenPhase > 6.28318530718f) audioGenPhase -= 6.28318530718f;
        }

        if (globalEffectsEnabled.load()) {
            float mix = globalEffectsMix.load();
            left[i] *= 1.0f - mix * 0.15f;
            right[i] *= 1.0f - mix * 0.15f;
        }
    }

    float invN = 1.0f / static_cast<float>(numFrames);
    float avgEnergy = sumAbs * invN;
    float avgDiff   = sumDiff * invN;
    float avgWave   = sumWave * invN;
    float avgMotion = sumMotion * invN;
    float waveSpareLevelValue = std::clamp(avgWave * (0.5f + waveSpareSpeed.load()), 0.0f, 1.0f);
    waveSpareLevel.store(waveSpareLevelValue);
    waveSpareActive.store(waveSpareSpeedEnabled.load() && waveSpareLevelValue >= waveSpareThreshold.load());
    argumentActive.store(avgEnergy >= argumentThreshold.load());
    ambientLevel.store(ambientAnalysisEnabled.load() ? std::clamp(avgEnergy, 0.0f, 1.0f) : 0.0f);
    float rms = std::sqrt(sumSquares * invN);
    const float rawMicEnergy = std::clamp(rms * 4.0f + rawMicPeak.load() * 2.0f + std::clamp(dominantHz.load() / 2000.0f, 0.0f, 1.0f) * 0.35f, 0.0f, 1.0f);
    const float confidence = std::clamp(rawMicEnergy * 0.7f + std::clamp(spectralCentroidHz.load() / 2000.0f, 0.0f, 1.0f) * 0.3f, 0.0f, 1.0f);
    const float intensity = micIntensityEnabled.load() ? std::clamp(rawMicEnergy * micIntensityBias.load(), 0.0f, 1.0f) : 0.0f;
    micIntensityRaw.store(rawMicEnergy);
    micIntensityConfidence.store(confidence);
    micIntensity.store(intensity > micIntensityThreshold.load() ? intensity : 0.0f);
    ambientRms.store(rms);
    float db = 20.0f * std::log10(std::max(rms, 0.000001f));
    ambientDb.store(std::clamp(db, -300.0f, 0.0f));
    float bipolarRms = std::sqrt(sumBipolarSquares * invN);
    float bipolarDbValue = 20.0f * std::log10(std::max(bipolarRms, 0.000001f));
    bipolarDb.store(std::clamp(bipolarDbValue, -120.0f, 0.0f));
    float detectedPitch = static_cast<float>(zeroCrossings) * 0.5f * 16000.0f * invN;
    pitchHz.store(detectedPitch);
    float warpSignal = std::clamp(std::fabs(avgMotion - ambientLevel.load()) + std::fabs(avgDiff - avgWave) * 0.8f, 0.0f, 1.0f);
    float stutterSignal = std::clamp(std::fabs(avgWave - ambientLevel.load()) + std::fabs(detectedPitch / 2000.0f) * 0.5f, 0.0f, 1.0f);
    int warpEvents = warpSignal >= warpThreshold.load() ? 1 : 0;
    int stutterEvents = stutterSignal >= stutterThreshold.load() ? 1 : 0;
    warpCounter.store(warpEvents);
    stutterCounter.store(stutterEvents);
    warpHz.store(std::clamp(detectedPitch * (0.5f + warpSignal), 0.0f, 4000.0f));
    stutterHz.store(std::clamp(detectedPitch * (0.35f + stutterSignal), 0.0f, 4000.0f));
    warpRaw.store(warpSignal);
    stutterRaw.store(stutterSignal);
    warpDb.store(std::clamp((20.0f * std::log10(std::max(warpSignal, 0.000001f)) + 120.0f) * 0.5f, -120.0f, 0.0f));
    stutterDb.store(std::clamp((20.0f * std::log10(std::max(stutterSignal, 0.000001f)) + 120.0f) * 0.5f, -120.0f, 0.0f));
    warpBipolar.store(std::clamp(warpDb.load() + 10.0f, -120.0f, 0.0f));
    stutterBipolar.store(std::clamp(stutterDb.load() + 20.0f, -120.0f, 0.0f));

    const int previousWarpDirection = warpDirection.load();
    const int previousStutterDirection = stutterDirection.load();
    int nextWarpDirection = 0;
    int nextStutterDirection = 0;
    if (warpRaw.load() >= warpThreshold.load()) nextWarpDirection = 1;
    else if (warpRaw.load() <= 0.0f) nextWarpDirection = 0;
    else nextWarpDirection = -1;
    if (stutterRaw.load() >= stutterThreshold.load()) nextStutterDirection = 1;
    else if (stutterRaw.load() <= 0.0f) nextStutterDirection = 0;
    else nextStutterDirection = -1;
    warpDirection.store(nextWarpDirection);
    stutterDirection.store(nextStutterDirection);
    if (nextWarpDirection != previousWarpDirection) {
        if (nextWarpDirection > 0) warpDirectionUpCounter.fetch_add(1);
        else if (nextWarpDirection < 0) warpDirectionDownCounter.fetch_add(1);
    }
    if (nextStutterDirection != previousStutterDirection) {
        if (nextStutterDirection > 0) stutterDirectionUpCounter.fetch_add(1);
        else if (nextStutterDirection < 0) stutterDirectionDownCounter.fetch_add(1);
    }
    const bool silent = rms <= silenceThreshold.load();
    silenceActive.store(silent);
    silenceLevel.store(std::clamp(rms / std::max(silenceThreshold.load(), 0.000001f), 0.0f, 1.0f));
    const float thresholdPitchNormalized = std::clamp(detectedPitch / 1920.0f, 0.0f, 1.0f);
    thresholdedPitchHz.store(thresholdPitchNormalized >= pitchOutputThreshold.load() ? detectedPitch * pitchOutputLevel.load() : 0.0f);
    thresholdedPitchDb.store(thresholdPitchNormalized >= pitchOutputThreshold.load() ? std::clamp(db * pitchOutputLevel.load(), -120.0f, 0.0f) : -120.0f);
    spikeCount.store(spikes);
    spikeOutput.store(std::clamp(static_cast<float>(spikes) / static_cast<float>(numFrames), 0.0f, 1.0f));
    const bool innerVoice = innerVoiceMaskEnabled.load() && detectedPitch >= 80.0f && detectedPitch / 1920.0f <= innerVoiceMaskThreshold.load();
    const bool loudSpeech = loudSpeechMaskEnabled.load() && db >= loudSpeechMaskThreshold.load() && detectedPitch >= 80.0f;
    innerVoiceMaskActive.store(innerVoice);
    loudSpeechMaskActive.store(loudSpeech);
    float maskGain = 1.0f;
    if (innerVoice) maskGain *= innerVoiceMaskGain.load();
    if (loudSpeech) maskGain *= loudSpeechMaskGain.load();
    if (maskGain < 1.0f) {
        for (int i = 0; i < numFrames; ++i) { left[i] *= maskGain; right[i] *= maskGain; }
    }
    bool pitchEvent = db >= dbThreshold.load() && detectedPitch >= 80.0f;
    if (pitchEvent && !pitchEventActive) pitchThresholdEvents.fetch_add(1);
    pitchEventActive = pitchEvent;
    float excessDb = db - dbThreshold.load();
    float killAmount = ambientKillEnabled.load() ? std::clamp(excessDb / 10.0f, 0.0f, 1.0f) : 0.0f;
    float shiftAmount = ambientShiftEnabled.load() ? std::clamp(excessDb / 15.0f, 0.0f, 1.0f) : 0.0f;
    float ambientCurve = ambientLevel.load() >= ambientSpaceCurvatureThreshold.load()
        ? 1.0f + ambientSpaceCurvature.load() * 2.0f : 1.0f;
    killAmount = std::pow(killAmount, ambientCurve);
    shiftAmount = std::pow(shiftAmount, ambientCurve);
    ambientKillActive.store(killAmount > 0.15f);
    ambientShiftActive.store(shiftAmount > 0.10f);
    float previousPeak = peakHoldDb.load();
    peakHoldDb.store(std::max(previousPeak - 0.5f, db));
    float limiterReduction = db > peakLimiterDb.load()
        ? (db - peakLimiterDb.load()) * (1.0f - 1.0f / peakLimiterRatio.load())
        : 0.0f;
    peakLimiterReductionDb.store(limiterReduction);
    if (ambientKillEnabled.load() && killAmount > 0.0f) {
        float gain = 1.0f - killAmount;
        for (int i = 0; i < numFrames; ++i) { left[i] *= gain; right[i] *= gain; }
    }
    if (ambientShiftEnabled.load() && shiftAmount > 0.0f) {
        for (int i = 1; i < numFrames; ++i) {
            float shiftedLeft = left[i] * (1.0f - shiftAmount) + left[i - 1] * shiftAmount;
            float shiftedRight = right[i] * (1.0f - shiftAmount) + right[i - 1] * shiftAmount;
            left[i] = shiftedLeft;
            right[i] = shiftedRight;
        }
    }
    if (limiterReduction > 0.0f) {
        float limiterGain = std::pow(10.0f, -limiterReduction / 20.0f);
        for (int i = 0; i < numFrames; ++i) {
            left[i] *= limiterGain;
            right[i] *= limiterGain;
        }
    }
    float spectrumPower = 0.0f;
    float weightedSpectrum = 0.0f;
    float dominantPower = 0.0f;
    int dominantBin = 0;
    float lowBandPower = 0.0f;
    for (int bin = 1; bin <= 32; ++bin) {
        float real = 0.0f;
        float imag = 0.0f;
        for (int i = 0; i < numFrames; ++i) {
            float sample = 0.5f * (left[i] + right[i]);
            float angle = 6.28318530718f * static_cast<float>(bin * i) / static_cast<float>(numFrames);
            real += sample * std::cos(angle);
            imag -= sample * std::sin(angle);
        }
        float magnitude = std::sqrt(real * real + imag * imag) * invN;
        float frequency = static_cast<float>(bin * 16000) / static_cast<float>(numFrames);
        spectrumPower += magnitude;
        weightedSpectrum += frequency * magnitude;
        if (magnitude > dominantPower) {
            dominantPower = magnitude;
            dominantBin = bin;
        }
        if (bin <= 4) lowBandPower += magnitude;
    }
    ambientFftLevel.store(std::clamp(spectrumPower * 1.5f, 0.0f, 1.0f));
    dominantHz.store(static_cast<float>(dominantBin * 16000) / static_cast<float>(numFrames));
    spectralCentroidHz.store(spectrumPower > 0.000001f ? weightedSpectrum / spectrumPower : 0.0f);
    float intentionPower = 0.0f;
    float intentionWeighted = 0.0f;
    for (int bin = 1; bin <= 32; ++bin) {
        const float frequency = static_cast<float>(bin * 16000) / static_cast<float>(numFrames);
        if (frequency >= intentionLowHz.load() && frequency <= intentionHighHz.load()) {
            float real = 0.0f;
            float imag = 0.0f;
            for (int i = 0; i < numFrames; ++i) {
                float sample = 0.5f * (left[i] + right[i]);
                float angle = 6.28318530718f * static_cast<float>(bin * i) / static_cast<float>(numFrames);
                real += sample * std::cos(angle);
                imag -= sample * std::sin(angle);
            }
            const float magnitude = std::sqrt(real * real + imag * imag) * invN;
            intentionPower += magnitude;
            intentionWeighted += frequency * magnitude;
        }
    }
    const float intentionLevelValue = std::clamp(intentionPower * 1.5f, 0.0f, 1.0f);
    const float intentionDb = 20.0f * std::log10(std::max(intentionLevelValue, 0.000001f));
    const float thresholdNormalized = std::clamp((intentionGateThreshold.load() + 1000.0f) / 2000.0f, 0.0f, 1.0f);
    const bool intentionDetected = intentionLevelValue >= thresholdNormalized;
    const int mode = atmosphereMode.load();
    const bool gateOpen = !antiAmbianceEnabled.load() || mode == 0 || (mode == 1 && intentionDetected) || (mode == 2 && intentionDetected);
    const float targetGate = gateOpen ? 1.0f : (mode == 1 ? 0.18f : 0.0f);
    const float smoothingMs = gateOpen ? gateAttackMs.load() : gateReleaseMs.load();
    const float smoothing = std::clamp(static_cast<float>(numFrames) * 1000.0f / (16000.0f * std::max(smoothingMs, 1.0f)), 0.001f, 1.0f);
    const float nextGate = gateAmount.load() + (targetGate - gateAmount.load()) * smoothing;
    intentionLevel.store(intentionLevelValue);
    intentionGateOpen.store(gateOpen);
    gateAmount.store(nextGate);
    if (antiAmbianceEnabled.load() && mode != 0) {
        const float preserve = std::clamp(nextGate * imaginationSpaceIntensity.load(), 0.0f, 1.0f);
        for (int i = 0; i < numFrames; ++i) {
            left[i] *= preserve;
            right[i] *= preserve;
        }
    }
    const float dominantValue = static_cast<float>(dominantBin * 16000) / static_cast<float>(numFrames);
    const float centroidValue = spectrumPower > 0.000001f ? weightedSpectrum / spectrumPower : 0.0f;
    const bool spectrumBipolarPass = bipolarDbValue >= spectrumBipolarThreshold.load();
    dominantLevel.store(spectrumBipolarPass && dominantValue >= dominantThreshold.load() ? std::clamp(dominantPower * 4.0f, 0.0f, 1.0f) : 0.0f);
    centroidLevel.store(spectrumBipolarPass && centroidValue >= centroidThreshold.load() ? std::clamp(spectrumPower * 1.5f, 0.0f, 1.0f) : 0.0f);
    if (dominantBin > 0) dominantHzCounter.fetch_add(1);
    if (spectrumPower > 0.000001f) spectralCentroidCounter.fetch_add(1);
    brainWaveOutput.store(std::clamp(lowBandPower * 4.0f, 0.0f, 1.0f));
    const bool ambientThresholdPassed =
        avgEnergy >= ambientThresholdLevel.load() &&
        bipolarDbValue >= ambientBipolarThreshold.load();
    atomAmbientActive.store(ambientAnalysisEnabled.load() && ambientThresholdPassed &&
                            avgEnergy >= atomSpareAmbientThreshold.load() && !silent);
    waveAmbientActive.store(ambientAnalysisEnabled.load() && ambientThresholdPassed &&
                            ambientFftLevel.load() >= waveSpareAmbientThreshold.load());

    float protectionLimit = thresholdValue.load();
    bool overLimit = avgEnergy >= protectionLimit;
    if (protectionBlockEnabled.load() && overLimit) {
        thresholdViolations.fetch_add(1);
        protectionActive.store(true);
        if (blockingMode.load() == 2) {
            std::fill(left, left + numFrames, 0.0f);
            std::fill(right, right + numFrames, 0.0f);
        } else if (blockingMode.load() == 1) {
            for (int i = 0; i < numFrames; ++i) {
                left[i] *= 0.35f;
                right[i] *= 0.35f;
            }
        }
    } else {
        protectionActive.store(false);
    }
    if (commThresholdEnabled.load()) {
        commStatus.store(avgEnergy >= commThreshold.load() ? 2 : 0);
    } else {
        commStatus.store(0);
    }

    float motionFloor = (speedOn || moveOn || waveOn || resonanceOn || roboticOn) ? 0.12f : 0.0f;
    float speedFloor  = (speedOn || waveOn) ? 0.10f : 0.0f;
    float moveFloor   = (moveOn || roboticOn) ? 0.14f : 0.0f;
    float windSignal = windEnabled.load()
        ? std::max(0.0f, avgMotion - windThreshold.load()) * windLevel.load() * 3.0f
        : 0.0f;
    float motionSignal = std::max(avgMotion * 3.0f, avgDiff) *
        (0.25f + movementSpeed.load() * 1.25f) + windSignal;
    if (motionSignal < movementThreshold.load()) motionSignal *= 0.25f;

    float resonanceBoost = resonanceOn ? (1.0f + resonanceVal * 0.8f) : 1.0f;
    float roboticBoost = roboticOn ? (1.0f + roboticVal * 0.9f) : 1.0f;

    avgEnergy = std::max(avgEnergy, speedFloor);
    avgDiff   = std::max(motionSignal, moveFloor);
    avgWave   = std::max(avgWave, motionFloor);

    envSpeed += (avgEnergy - envSpeed) * 0.18f;
    float moveSmoothing = 0.05f + movementSmooth.load() * 0.25f;
    envMove  += (avgDiff   - envMove)  * moveSmoothing;
    envWave  += (avgWave   - envWave)  * 0.18f;

    const float speedCapBoost = virtualSpeedCapEnabled.load() ? std::max(1.0f, virtualSpeedCapMultiplier.load()) : 1.0f;
    float speedOutput = std::clamp(envSpeed * 2.2f * resonanceBoost * roboticBoost * (0.4f + atomIntensity.load()) * speedCapBoost, 0.0f, 4.0f);
    float moveOutput = std::clamp(envMove * 2.5f * (1.0f + roboticVal * 0.5f) * speedCapBoost, 0.0f, 4.0f);
    float waveOutput = std::clamp(envWave * 2.0f * resonanceBoost * (0.4f + waveIntensity.load()) * speedCapBoost, 0.0f, 4.0f);
    if (ambientAnalysisEnabled.load()) {
        if (ambientSpeedGateEnabled.load() && ambientLevel.load() < ambientSpeedThreshold.load()) speedOutput = 0.0f;
        if (ambientMotionGateEnabled.load() && ambientLevel.load() < ambientMotionThreshold.load()) moveOutput = 0.0f;
        if (ambientWaveGateEnabled.load() && ambientLevel.load() < ambientWaveThreshold.load()) waveOutput = 0.0f;
    }
    const float atomMoveOutput = moveOutput;
    const float atomWaveOutput = waveOutput;
    float waveSpareWaveOutputValue = 0.0f;
    float waveSpareMoveOutputValue = 0.0f;
    if (waveSpareSpeedEnabled.load()) {
        float bipolarWarp = waveSpareBipolarDb.load() / 1000.0f;
        waveSpareWaveOutputValue = std::clamp(waveSpareLevelValue * (0.5f + waveSpareSpeed.load()) * (1.0f + bipolarWarp * 0.25f), 0.0f, 1.0f);
        waveOutput = std::clamp(waveOutput * 0.5f + waveSpareWaveOutputValue * 0.5f, 0.0f, 1.0f);
    } else {
        waveOutput = 0.0f;
    }
    if (waveSpareSpeedEnabled.load() && waveSpareLevelValue >= waveSpareThreshold.load()) {
        waveSpareMoveOutputValue = std::clamp(waveSpareMovement.load() * waveSpareLevelValue * 0.7f, 0.0f, 1.0f);
        moveOutput = std::clamp(moveOutput + waveSpareMoveOutputValue, 0.0f, 1.0f);
    }

    if (ambientAnalysisEnabled.load()) {
        float atomSensitivity = 0.7f + (1.0f - atomSpareAmbientThreshold.load()) * 0.6f;
        float waveSensitivity = 0.7f + (1.0f - waveSpareAmbientThreshold.load()) * 0.6f;
        speedOutput = std::clamp(speedOutput * atomSensitivity, 0.0f, 1.0f);
        waveOutput = std::clamp(waveOutput * waveSensitivity, 0.0f, 1.0f);
    }

    if (!atomGateEnabled.load()) speedOutput = 0.0f;
    if (!waveGateEnabled.load()) waveOutput = 0.0f;

    const float pitchSignal = std::clamp((detectedPitch - 80.0f) / 1920.0f, 0.0f, 1.0f);
    const float pitchMotion = std::clamp(avgMotion * 4.0f, 0.0f, 1.0f);
    const float pitchSpeedValue = std::clamp(speedOutput * pitchSignal, 0.0f, 1.0f);
    const float pitchMovementValue = std::clamp(moveOutput * pitchSignal, 0.0f, 1.0f);
    const float pitchWaveValue = std::clamp(waveOutput * pitchSignal, 0.0f, 1.0f);
    const float channelTotal = std::max(sumLeftEnergy + sumRightEnergy, 0.000001f);
    const float leftChannelLevel = std::clamp((sumLeftEnergy * 2.0f) / channelTotal, 0.0f, 2.0f);
    const float rightChannelLevel = std::clamp((sumRightEnergy * 2.0f) / channelTotal, 0.0f, 2.0f);
    pitchSpeedOutput.store(pitchSpeedValue);
    pitchMovementOutput.store(pitchMovementValue);
    pitchWaveOutput.store(pitchWaveValue);
    atomSpareSpeedLeft.store(std::clamp(speedOutput * leftChannelLevel, 0.0f, 1.0f));
    atomSpareSpeedRight.store(std::clamp(speedOutput * rightChannelLevel, 0.0f, 1.0f));
    atomSpareMoveLeft.store(std::clamp(moveOutput * leftChannelLevel, 0.0f, 1.0f));
    atomSpareMoveRight.store(std::clamp(moveOutput * rightChannelLevel, 0.0f, 1.0f));
    atomSpareWaveLeft.store(std::clamp(waveOutput * leftChannelLevel, 0.0f, 1.0f));
    atomSpareWaveRight.store(std::clamp(waveOutput * rightChannelLevel, 0.0f, 1.0f));
    const float stereoCenterLevel = std::clamp(1.0f - std::fabs(leftChannelLevel - rightChannelLevel), 0.0f, 1.0f);
    warpLeft.store(std::clamp(warpSignal * leftChannelLevel, 0.0f, 1.0f));
    warpRight.store(std::clamp(warpSignal * rightChannelLevel, 0.0f, 1.0f));
    warpCenter.store(std::clamp(warpSignal * stereoCenterLevel, 0.0f, 1.0f));
    stutterLeft.store(std::clamp(stutterSignal * leftChannelLevel, 0.0f, 1.0f));
    stutterRight.store(std::clamp(stutterSignal * rightChannelLevel, 0.0f, 1.0f));
    stutterCenter.store(std::clamp(stutterSignal * stereoCenterLevel, 0.0f, 1.0f));
    if (motionPitchProtectionEnabled.load()) {
        const float leftProtection = std::clamp(pitchSignal * (0.5f + pitchMotion * 0.5f), 0.0f, 1.0f);
        const float rightProtection = std::clamp(pitchSignal * (0.5f + pitchMotion * 0.5f), 0.0f, 1.0f);
        motionPitchLeftProtection.store(leftProtection >= motionPitchThreshold.load() ? leftProtection : 0.0f);
        motionPitchRightProtection.store(rightProtection >= motionPitchThreshold.load() ? rightProtection : 0.0f);
        motionPitchSpeedProtection.store(pitchSpeedValue >= motionPitchSpeedThreshold.load() ? pitchSpeedValue : 0.0f);
        motionPitchMovementProtection.store(pitchMovementValue >= motionPitchMovementThreshold.load() ? pitchMovementValue : 0.0f);
        motionPitchWaveProtection.store(pitchWaveValue >= motionPitchWaveThreshold.load() ? pitchWaveValue : 0.0f);
    } else {
        motionPitchLeftProtection.store(0.0f);
        motionPitchRightProtection.store(0.0f);
        motionPitchSpeedProtection.store(0.0f);
        motionPitchMovementProtection.store(0.0f);
        motionPitchWaveProtection.store(0.0f);
    }

    // Apply protection independently to speed, movement, and wave outputs.
    if (protectionBlockEnabled.load()) {
        bool motionOverLimit = moveOutput >= protectionLimit;
        bool waveOverLimit = waveOutput >= protectionLimit;
        if (motionOverLimit || waveOverLimit) protectionActive.store(true);
        if (blockingMode.load() == 2) {
            if (motionOverLimit) moveOutput = 0.0f;
            if (waveOverLimit) waveOutput = 0.0f;
        } else if (blockingMode.load() == 1) {
            if (motionOverLimit) moveOutput *= 0.35f;
            if (waveOverLimit) waveOutput *= 0.35f;
        }
    }

    const bool enemyEnabled = enemyProtectionEnabled.load();
    const bool enemyAmbient = ambientLevel.load() >= enemyAmbientThreshold.load() && !silent;
    const bool enemyAmbientHold = enemyEnabled && enemyAmbient;
    enemyAmbientSignalHold.store(enemyAmbientHold);
    const bool enemyMovement = moveOutput >= enemyMovementThreshold.load();
    const bool enemySpeed = speedOutput >= enemySpeedThreshold.load();
    const bool enemyWave = waveOutput >= enemyWaveThreshold.load();
    const bool enemyPitch = detectedPitch >= enemyPitchThreshold.load();
    const bool enemyCommunication = avgEnergy >= enemyCommunicationThreshold.load();
    const bool enemySpeaker = avgEnergy >= enemySpeakerThreshold.load();
    const bool enemyGeometry = moveOutput >= enemyCurveThreshold.load() || moveOutput >= enemyPlaneThreshold.load() ||
        moveOutput >= enemyWallThreshold.load() || moveOutput >= enemyRingThreshold.load();
    const bool enemyTriggered = enemyEnabled &&
        (enemyAmbient || enemyMovement || enemySpeed || enemyWave || enemyPitch || enemyCommunication || enemySpeaker || enemyGeometry);
    const bool hardEnemyBlock = enemyHardBlock.load() || blockingMode.load() == 2;
    enemyProtectionActive.store(enemyTriggered);
    enemyProtectionStatus.store(enemyTriggered ? (hardEnemyBlock ? 2 : 1) : 0);
    if (enemyTriggered) {
        const float outputGain = hardEnemyBlock ? 0.0f : 0.2f;
        if (enemySpeed) speedOutput *= outputGain;
        if (enemyMovement) moveOutput *= outputGain;
        if (enemyWave) waveOutput *= outputGain;
        if (enemyPitch || enemyCommunication || enemySpeaker || enemyAmbient) {
            for (int i = 0; i < numFrames; ++i) {
                left[i] *= outputGain;
                right[i] *= outputGain;
            }
        }
    }
    if (enemyAmbientHold) {
        speedOutput = 0.0f;
        moveOutput = 0.0f;
        waveOutput = 0.0f;
        pitchSpeedOutput.store(0.0f);
        pitchMovementOutput.store(0.0f);
        pitchWaveOutput.store(0.0f);
        atomSpareSpeedLeft.store(0.0f);
        atomSpareSpeedRight.store(0.0f);
        atomSpareMoveLeft.store(0.0f);
        atomSpareMoveRight.store(0.0f);
        atomSpareWaveLeft.store(0.0f);
        atomSpareWaveRight.store(0.0f);
        warpLeft.store(0.0f);
        warpRight.store(0.0f);
        warpCenter.store(0.0f);
        stutterLeft.store(0.0f);
        stutterRight.store(0.0f);
        stutterCenter.store(0.0f);
        std::fill(left, left + numFrames, 0.0f);
        std::fill(right, right + numFrames, 0.0f);
    }

    const float thresholdedMovementValue = moveOutput >= ambientMotionThreshold.load() ? moveOutput : 0.0f;
    const float thresholdedSpeedValue = speedOutput >= ambientSpeedThreshold.load() ? speedOutput : 0.0f;
    const float thresholdedWaveValue = waveOutput >= ambientWaveThreshold.load() ? waveOutput : 0.0f;
    thresholdedMovementOutput.store(thresholdedMovementValue);
    thresholdedMovementLevel.store(moveOutput);
    thresholdedMovementThreshold.store(ambientMotionThreshold.load());
    thresholdedSpeedOutput.store(thresholdedSpeedValue);
    thresholdedSpeedLevel.store(speedOutput);
    thresholdedSpeedThreshold.store(ambientSpeedThreshold.load());
    thresholdedWaveOutput.store(thresholdedWaveValue);
    thresholdedWaveLevel.store(waveOutput);
    thresholdedWaveThreshold.store(ambientWaveThreshold.load());
    speedEnergy.store(speedOutput);
    moveEnergy.store(moveOutput);
    waveEnergy.store(waveOutput);
    atomMoveEnergy.store(std::clamp(atomMoveOutput, 0.0f, 1.0f));
    atomWaveEnergy.store(std::clamp(atomWaveOutput, 0.0f, 1.0f));
    waveSpareSpeedOutput.store(waveSpareSpeedEnabled.load() ? waveSpareSpeed.load() * waveSpareLevelValue : 0.0f);
    waveSpareMoveOutput.store(waveSpareMoveOutputValue);
    waveSpareWaveOutput.store(waveSpareWaveOutputValue);

    float base = speedOutput;
    float movementBase = moveOutput;
    float waveBase = waveOutput;
    float visualFactor = visualGateEnabled.load() ? 1.0f : 0.0f;
    if (visualGateEnabled.load() && base < visualThreshold.load()) visualFactor = 0.25f;
    headZone.store(std::clamp((base * 0.65f + movementBase * 0.15f + waveBase * 0.20f) * visualFactor, 0.0f, 1.0f));
    chestZone.store(std::clamp((base * 0.70f + movementBase * 0.15f + waveBase * 0.15f + roboticVal * 0.18f) * visualFactor, 0.0f, 1.0f));
    abdomenZone.store(std::clamp((base * 0.45f + movementBase * 0.40f + waveBase * 0.15f) * visualFactor, 0.0f, 1.0f));
    leftArmZone.store(std::clamp((base * 0.35f + movementBase * 0.55f + waveBase * 0.10f + roboticVal * 0.2f) * visualFactor, 0.0f, 1.0f));
    rightArmZone.store(std::clamp((base * 0.35f + movementBase * 0.55f + waveBase * 0.10f + roboticVal * 0.2f) * visualFactor, 0.0f, 1.0f));
    leftLegZone.store(std::clamp((base * 0.30f + movementBase * 0.35f + waveBase * 0.35f) * visualFactor, 0.0f, 1.0f));
    rightLegZone.store(std::clamp((base * 0.30f + movementBase * 0.35f + waveBase * 0.35f) * visualFactor, 0.0f, 1.0f));

    const float bodyValues[16] = {
        headZone.load(), chestZone.load(), abdomenZone.load(),
        leftArmZone.load(), rightArmZone.load(), leftLegZone.load(), rightLegZone.load(),
        chestZone.load() * 0.9f, headZone.load() * 0.85f, abdomenZone.load() * 0.8f,
        chestZone.load() * 0.75f, headZone.load() * 0.7f, waveBase, moveOutput,
        headZone.load() * 0.75f, headZone.load() * 0.8f
    };
    float bodySum = 0.0f;
    for (float bodyValue : bodyValues) bodySum += bodyValue;
    bodyOutput.store(std::clamp(bodySum / 16.0f, 0.0f, 1.0f));
    const float bodyBipolar = bipolarDb.load();
    bool bodyEnemyMovement = false;
    for (int i = 0; i < 16; ++i) {
        bodyLevels[i].store(bodyValues[i]);
        bodyBipolarDb[i].store(bodyBipolar);
        if (bodyValues[i] >= bodyThresholds[i].load()) bodyCounters[i].fetch_add(1);
        bodyEnemyMovement = bodyEnemyMovement || bodyValues[i] >= bodyEnemyMovementThreshold.load();
    }
    bodyEnemyProtectionActive.store(bodyEnemyProtectionEnabled.load() && bodyEnemyMovement);
    const float insideValue = std::max({bodyValues[7], bodyValues[8], bodyValues[9], bodyValues[10], bodyValues[11], bodyValues[15]});
    const float outsideValue = std::max({bodyValues[0], bodyValues[3], bodyValues[4], bodyValues[5], bodyValues[6], bodyValues[12], bodyValues[14]});
    bodyInsideProtectionActive.store(bodyInsideProtectionEnabled.load() && insideValue >= bodyInsideThreshold.load());
    bodyOutsideProtectionActive.store(bodyOutsideProtectionEnabled.load() && outsideValue >= bodyOutsideThreshold.load());

    float eyeMotion = std::clamp(moveOutput * (0.35f + eyeMoveSpeed.load()), 0.0f, 1.0f);
    float eyeWave = std::clamp(waveOutput * (0.5f + eyeWaveLevel.load()), 0.0f, 1.0f);
    float pitchNormalized = std::clamp((pitchHz.load() - 80.0f) / 1920.0f, 0.0f, 1.0f);
    float eyePingPong = eyePingPongEnabled.load() ? std::sin(audioGenPhase) * eyePingPongLevel.load() : 0.0f;
    if (!eyeMoveEnabled.load()) eyeMotion = 0.0f;
    if (!eyeWaveEnabled.load()) eyeWave = 0.0f;
    if (eyeMotion < eyeThreshold.load()) eyeMotion *= 0.2f;
    if (pitchHz.load() > 0.0f && pitchNormalized < eyePitchThreshold.load()) eyeWave *= 0.2f;
    if (eyeProtectionEnabled.load() && ambientRms.load() > eyeProtectionThreshold.load()) {
        eyeMotion = 0.0f;
        eyeWave = 0.0f;
    }
    if (!eyeVisionEnabled.load() || ambientLevel.load() < std::max(eyeVisionThreshold.load(), eyeAmbientThreshold.load())) {
        eyeMotion *= 0.25f;
        eyeWave *= 0.25f;
    }
    float bipolarEye = eyeBipolarDb.load() / 1000.0f;
    eyeLeftPitch.store(std::clamp(pitchNormalized * (1.0f + bipolarEye * 0.2f), 0.0f, 1.0f));
    eyeRightPitch.store(std::clamp(pitchNormalized * (1.0f - bipolarEye * 0.2f), 0.0f, 1.0f));
    eyeLeftLevel.store(std::clamp(eyeMotion * 0.9f + eyeWave * 0.1f + eyePingPong * 0.08f, 0.0f, 1.0f));
    eyeRightLevel.store(std::clamp(eyeMotion * 0.85f + eyeWave * 0.15f - eyePingPong * 0.08f, 0.0f, 1.0f));
    eyeLeftProtection.store(eyeProtectionEnabled.load() && eyeLeftLevel.load() >= eyeProtectionThreshold.load() ? eyeLeftLevel.load() : 0.0f);
    eyeRightProtection.store(eyeProtectionEnabled.load() && eyeRightLevel.load() >= eyeProtectionThreshold.load() ? eyeRightLevel.load() : 0.0f);
}