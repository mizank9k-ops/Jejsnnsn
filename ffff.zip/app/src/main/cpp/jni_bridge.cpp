#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <dlfcn.h>
#include "AtomSpareEngine.h"
#include "EchoProcessor.h"

#define LOG_TAG "AtomicWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static AtomSpareEngine* atomEngine = nullptr;
static EchoProcessor*   echoProc   = nullptr;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_atomicworld_app_NativeBridge_getVulkanAvailable(JNIEnv*, jobject) {
    void* vulkan = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
    if (!vulkan) return JNI_FALSE;
    const bool available = dlsym(vulkan, "vkGetInstanceProcAddr") != nullptr;
    dlclose(vulkan);
    return available ? JNI_TRUE : JNI_FALSE;
}

// ========== Init / Release ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_nativeInit(JNIEnv*, jobject) {
    if (!atomEngine) atomEngine = new AtomSpareEngine();
    if (!echoProc)   echoProc   = new EchoProcessor();
    LOGI("Native engines initialized");
}

JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_nativeRelease(JNIEnv*, jobject) {
    delete atomEngine; atomEngine = nullptr;
    delete echoProc;   echoProc   = nullptr;
    LOGI("Native engines released");
}

JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_nativeProcess(
        JNIEnv* env, jobject,
        jfloatArray jLeft, jfloatArray jRight, jint frames) {

    if (!atomEngine || !echoProc) return;

    jfloat* left  = env->GetFloatArrayElements(jLeft, nullptr);
    jfloat* right = env->GetFloatArrayElements(jRight, nullptr);
    const jsize leftLength = env->GetArrayLength(jLeft);
    const jsize rightLength = env->GetArrayLength(jRight);
    const jint safeFrames = std::max(0, std::min({frames, static_cast<jint>(leftLength), static_cast<jint>(rightLength)}));

    if (left && right && safeFrames > 0) {
        atomEngine->process(left, right, safeFrames);
        echoProc->process(left, right, safeFrames);
    }

    env->ReleaseFloatArrayElements(jLeft, left, 0);
    env->ReleaseFloatArrayElements(jRight, right, 0);
}

// ========== AtomSpare Speed ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareSpeed(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAtomSpareSpeed(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareSpeedEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAtomSpareSpeedEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareSpeedThreshold(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAtomSpareSpeedThreshold(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareSpeedBoost(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAtomSpareSpeedBoost(v);
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getAtomSpareSpeed(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomSpareSpeed() : 0.5f;
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getAtomSpareSpeedThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomSpareSpeedThreshold() : 0.3f;
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getAtomSpareSpeedBoost(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomSpareSpeedBoost() : 1.0f;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAtomSpaceCurvature(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAtomSpaceCurvature(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAtomSpaceCurvatureThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAtomSpaceCurvatureThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpaceCurvature(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpaceCurvature() : 0.5f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpaceCurvatureThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpaceCurvatureThreshold() : 0.3f; }

// ========== AtomSpare Move ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareMove(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAtomSpareMove(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareMoveEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAtomSpareMoveEnabled(v);
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getAtomSpareMove(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomSpareMove() : 0.5f;
}

// ========== AtomSpare Wave ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareWave(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAtomSpareWave(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAtomSpareWaveEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAtomSpareWaveEnabled(v);
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getAtomSpareWave(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomSpareWave() : 0.5f;
}

// ========== WaveSpare Speed / Wave ==========
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareSpeed(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSpareSpeed(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareSpeedEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setWaveSpareSpeedEnabled(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareWave(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSpareWave(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareWaveEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setWaveSpareWaveEnabled(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareMovement(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSpareMovement(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareThreshold(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSpareThreshold(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareBipolarDb(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSpareBipolarDb(v);
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareSpeed(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareSpeed() : 0.5f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareWave(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareWave() : 0.5f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareMovement(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareMovement() : 0.5f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareThreshold() : 0.3f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareBipolarDb(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareBipolarDb() : 0.0f;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setVirtualSpeedCapEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setVirtualSpeedCapEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setVirtualSpeedCapMultiplier(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setVirtualSpeedCapMultiplier(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getVirtualSpeedCapEnabled(JNIEnv*, jobject) { return atomEngine ? atomEngine->getVirtualSpeedCapEnabled() : false; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getVirtualSpeedCapMultiplier(JNIEnv*, jobject) { return atomEngine ? atomEngine->getVirtualSpeedCapMultiplier() : 1.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMicIntensityEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setMicIntensityEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMicIntensityBias(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setMicIntensityBias(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMicIntensityThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setMicIntensityThreshold(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getMicIntensityEnabled(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicIntensityEnabled() : true; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMicIntensityBias(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicIntensityBias() : 1.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMicIntensityThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicIntensityThreshold() : 0.25f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMicIntensity(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicIntensity() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMicIntensityRaw(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicIntensityRaw() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMicIntensityConfidence(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicIntensityConfidence() : 0.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpaceCurvature(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setWaveSpaceCurvature(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpaceCurvatureThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setWaveSpaceCurvatureThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpaceCurvature(JNIEnv*, jobject) { return atomEngine ? atomEngine->getWaveSpaceCurvature() : 0.5f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpaceCurvatureThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getWaveSpaceCurvatureThreshold() : 0.3f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareLevel() : 0.0f;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareActive(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareActive() : false;
}

// ========== Detection energies ==========
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getSpeedEnergy(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getSpeedEnergy() : 0.0f;
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getMoveEnergy(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getMoveEnergy() : 0.0f;
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getWaveEnergy(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveEnergy() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomMoveEnergy(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomMoveEnergy() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomWaveEnergy(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomWaveEnergy() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareSpeedOutput(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareSpeedOutput() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareMoveOutput(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareMoveOutput() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareWaveOutput(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareWaveOutput() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedMovementOutput(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedMovementOutput() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedMovementLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedMovementLevel() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedMovementThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedMovementThreshold() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedSpeedOutput(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedSpeedOutput() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedSpeedLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedSpeedLevel() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedSpeedThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedSpeedThreshold() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedWaveOutput(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedWaveOutput() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedWaveLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedWaveLevel() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedWaveThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdedWaveThreshold() : 0.0f;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getCommunicationGateEnabled(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getCommunicationGateEnabled() : false;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getCommunicationGateBlocked(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getCommunicationGateBlocked() : false;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getCommunicationGateState(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getCommunicationGateState() : 0;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPitchSpeedOutput(JNIEnv*, jobject) { return atomEngine ? atomEngine->getPitchSpeedOutput() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPitchMovementOutput(JNIEnv*, jobject) { return atomEngine ? atomEngine->getPitchMovementOutput() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPitchWaveOutput(JNIEnv*, jobject) { return atomEngine ? atomEngine->getPitchWaveOutput() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpareSpeedLeft(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpareSpeedLeft() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpareSpeedRight(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpareSpeedRight() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpareMoveLeft(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpareMoveLeft() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpareMoveRight(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpareMoveRight() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpareWaveLeft(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpareWaveLeft() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpareWaveRight(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtomSpareWaveRight() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpLeft(JNIEnv*, jobject) { return atomEngine ? atomEngine->getWarpLeft() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpRight(JNIEnv*, jobject) { return atomEngine ? atomEngine->getWarpRight() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpCenter(JNIEnv*, jobject) { return atomEngine ? atomEngine->getWarpCenter() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterLeft(JNIEnv*, jobject) { return atomEngine ? atomEngine->getStutterLeft() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterRight(JNIEnv*, jobject) { return atomEngine ? atomEngine->getStutterRight() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterCenter(JNIEnv*, jobject) { return atomEngine ? atomEngine->getStutterCenter() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMotionPitchLeftProtection(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMotionPitchLeftProtection() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMotionPitchRightProtection(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMotionPitchRightProtection() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMotionPitchSpeedProtection(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMotionPitchSpeedProtection() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMotionPitchMovementProtection(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMotionPitchMovementProtection() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMotionPitchWaveProtection(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMotionPitchWaveProtection() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeLeftProtection(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEyeLeftProtection() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeRightProtection(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEyeRightProtection() : 0.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMotionPitchProtectionEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setMotionPitchProtectionEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMotionPitchThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setMotionPitchThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMotionPitchSpeedThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setMotionPitchSpeedThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMotionPitchMovementThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setMotionPitchMovementThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMotionPitchWaveThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setMotionPitchWaveThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyCurveThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyCurveThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyPlaneThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyPlaneThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyWallThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyWallThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyRingThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyRingThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyCurveThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyCurveThreshold() : 0.7f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyPlaneThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyPlaneThreshold() : 0.7f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyWallThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyWallThreshold() : 0.7f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyRingThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyRingThreshold() : 0.7f; }

// ========== Body diagram zones ==========
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getHeadZone(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getHeadZone() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getChestZone(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getChestZone() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAbdomenZone(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAbdomenZone() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getLeftArmZone(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getLeftArmZone() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getRightArmZone(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getRightArmZone() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getLeftLegZone(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getLeftLegZone() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getRightLegZone(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getRightLegZone() : 0.0f;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setBodyAmbientThreshold(JNIEnv*, jobject, jint i, jfloat v) { if (atomEngine) atomEngine->setBodyAmbientThreshold(i, v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getBodyAmbientThreshold(JNIEnv*, jobject, jint i) { return atomEngine ? atomEngine->getBodyAmbientThreshold(i) : 0.3f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getBodyAmbientLevel(JNIEnv*, jobject, jint i) { return atomEngine ? atomEngine->getBodyAmbientLevel(i) : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getBodyAmbientBipolarDb(JNIEnv*, jobject, jint i) { return atomEngine ? atomEngine->getBodyAmbientBipolarDb(i) : -120.0f; }
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getBodyAmbientCounter(JNIEnv*, jobject, jint i) { return atomEngine ? atomEngine->getBodyAmbientCounter(i) : 0; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setBodyEnemyProtectionEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setBodyEnemyProtectionEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setBodyEnemyMovementThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setBodyEnemyMovementThreshold(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getBodyEnemyProtectionActive(JNIEnv*, jobject) { return atomEngine ? atomEngine->getBodyEnemyProtectionActive() : false; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setBodyInsideThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setBodyInsideThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setBodyOutsideThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setBodyOutsideThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setBodyInsideProtectionEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setBodyInsideProtectionEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setBodyOutsideProtectionEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setBodyOutsideProtectionEnabled(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getBodyInsideProtectionActive(JNIEnv*, jobject) { return atomEngine ? atomEngine->getBodyInsideProtectionActive() : false; }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getBodyOutsideProtectionActive(JNIEnv*, jobject) { return atomEngine ? atomEngine->getBodyOutsideProtectionActive() : false; }

// ========== Echo ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setEchoEnabled(JNIEnv*, jobject, jboolean v) {
    if (echoProc) echoProc->setEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setEchoDelayMs(JNIEnv*, jobject, jfloat v) {
    if (echoProc) echoProc->setDelayMs(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setEchoFeedback(JNIEnv*, jobject, jfloat v) {
    if (echoProc) echoProc->setFeedback(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setEchoMix(JNIEnv*, jobject, jfloat v) {
    if (echoProc) echoProc->setMix(v);
}

// ========== Echo Protection and Smoothing ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setEchoProtectionEnabled(JNIEnv*, jobject, jboolean v) {
    if (echoProc) echoProc->setProtectionEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setEchoSmoothingFactor(JNIEnv*, jobject, jfloat v) {
    if (echoProc) echoProc->setSmoothingFactor(v);
}
JNIEXPORT jboolean JNICALL
Java_com_atomicworld_app_NativeBridge_getEchoProtectionActive(JNIEnv*, jobject) {
    return echoProc ? echoProc->getProtectionActive() : false;
}

// ========== Wave Speed and Smooth ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setWaveSpeed(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSpeed(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setWaveSmooth(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSmooth(v);
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getWaveSpeed(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpeed() : 0.5f;
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getWaveSmooth(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSmooth() : 0.6f;
}

// ========== Ambient live analysis ==========
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientAnalysisEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAmbientAnalysisEnabled(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAtomSpareAmbientThreshold(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAtomSpareAmbientThreshold(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveSpareAmbientThreshold(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setWaveSpareAmbientThreshold(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientThresholdLocked(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAmbientThresholdLocked(v);
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientAnalysisEnabled(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientAnalysisEnabled() : true;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientMotionThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmbientMotionThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientSpeedThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmbientSpeedThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientWaveThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmbientWaveThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientMotionGateEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setAmbientMotionGateEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientSpeedGateEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setAmbientSpeedGateEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientWaveGateEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setAmbientWaveGateEnabled(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientMotionThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmbientMotionThreshold() : 0.2f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientSpeedThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmbientSpeedThreshold() : 0.3f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientWaveThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmbientWaveThreshold() : 0.3f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAtomSpareAmbientThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomSpareAmbientThreshold() : 0.3f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWaveSpareAmbientThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveSpareAmbientThreshold() : 0.3f;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientThresholdLocked(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientThresholdLocked() : false;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAtomAmbientThresholdLocked(JNIEnv*, jobject, jboolean value) {
    if (atomEngine) atomEngine->setAtomAmbientThresholdLocked(value);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWaveAmbientThresholdLocked(JNIEnv*, jobject, jboolean value) {
    if (atomEngine) atomEngine->setWaveAmbientThresholdLocked(value);
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAtomAmbientThresholdLocked(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomAmbientThresholdLocked() : false;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getWaveAmbientThresholdLocked(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveAmbientThresholdLocked() : false;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAtomAmbientActive(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAtomAmbientActive() : false;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getWaveAmbientActive(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWaveAmbientActive() : false;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientLevel() : 0.0f;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientThresholdLevel(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAmbientThresholdLevel(v);
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientThresholdLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientThresholdLevel() : 0.30f;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientBipolarThreshold(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAmbientBipolarThreshold(v);
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientBipolarThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientBipolarThreshold() : -120.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientRms(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientRms() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientFftLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientFftLevel() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientDb(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientDb() : -60.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getBodyOutput(JNIEnv*, jobject) { return atomEngine ? atomEngine->getBodyOutput() : 0.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmplifierEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setAmplifierEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmplifierLevel(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmplifierLevel(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmplifierGain(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmplifierGain(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmplifierThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmplifierThreshold(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAmplifierEnabled(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmplifierEnabled() : false; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmplifierLevel(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmplifierLevel() : 0.5f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmplifierGain(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmplifierGain() : 1.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmplifierThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmplifierThreshold() : 0.1f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getDominantHz(JNIEnv*, jobject) { return atomEngine ? atomEngine->getDominantHz() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getSpectralCentroidHz(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSpectralCentroidHz() : 0.0f; }
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getDominantHzCounter(JNIEnv*, jobject) { return atomEngine ? atomEngine->getDominantHzCounter() : 0; }
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getSpectralCentroidCounter(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSpectralCentroidCounter() : 0; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getSpikeOutput(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSpikeOutput() : 0.0f; }
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getSpikeCount(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSpikeCount() : 0; }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getSilenceActive(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSilenceActive() : true; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getBrainWaveOutput(JNIEnv*, jobject) { return atomEngine ? atomEngine->getBrainWaveOutput() : 0.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setSpikeThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setSpikeThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getSpikeThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSpikeThreshold() : 0.35f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setSilenceThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setSilenceThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getSilenceThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSilenceThreshold() : 0.02f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMicrophoneEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setMicrophoneEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setMicrophoneGain(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setMicrophoneGain(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getMicrophoneEnabled(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicrophoneEnabled() : true; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getMicrophoneGain(JNIEnv*, jobject) { return atomEngine ? atomEngine->getMicrophoneGain() : 1.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getRawMicRms(JNIEnv*, jobject) { return atomEngine ? atomEngine->getRawMicRms() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getRawMicPeak(JNIEnv*, jobject) { return atomEngine ? atomEngine->getRawMicPeak() : 0.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientSpaceCurvature(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmbientSpaceCurvature(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientSpaceCurvatureThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setAmbientSpaceCurvatureThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientSpaceCurvature(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmbientSpaceCurvature() : 0.5f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientSpaceCurvatureThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAmbientSpaceCurvatureThreshold() : 0.3f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getBipolarDb(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getBipolarDb() : -120.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPitchHz(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getPitchHz() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedPitchHz(JNIEnv*, jobject) { return atomEngine ? atomEngine->getThresholdedPitchHz() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getThresholdedPitchDb(JNIEnv*, jobject) { return atomEngine ? atomEngine->getThresholdedPitchDb() : -120.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setPitchOutputThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setPitchOutputThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setPitchOutputLevel(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setPitchOutputLevel(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPitchOutputThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getPitchOutputThreshold() : 0.25f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPitchOutputLevel(JNIEnv*, jobject) { return atomEngine ? atomEngine->getPitchOutputLevel() : 0.5f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setDominantThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setDominantThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setDominantLevel(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setDominantLevel(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getDominantThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getDominantThreshold() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getDominantLevel(JNIEnv*, jobject) { return atomEngine ? atomEngine->getDominantLevel() : 0.5f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setCentroidThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setCentroidThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setCentroidLevel(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setCentroidLevel(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getCentroidThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getCentroidThreshold() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getCentroidLevel(JNIEnv*, jobject) { return atomEngine ? atomEngine->getCentroidLevel() : 0.5f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setSpectrumBipolarThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setSpectrumBipolarThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getSpectrumBipolarThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSpectrumBipolarThreshold() : -120.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getSilenceLevel(JNIEnv*, jobject) { return atomEngine ? atomEngine->getSilenceLevel() : 0.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setArgumentThreshold(JNIEnv*, jobject, jfloat value) {
    if (atomEngine) atomEngine->setArgumentThreshold(value);
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getArgumentThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getArgumentThreshold() : 0.3f;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getArgumentActive(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getArgumentActive() : false;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setDbThreshold(JNIEnv*, jobject, jfloat value) {
    if (atomEngine) atomEngine->setDbThreshold(value);
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getDbThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getDbThreshold() : -45.0f;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWarpThreshold(JNIEnv*, jobject, jfloat value) {
    if (atomEngine) atomEngine->setWarpThreshold(value);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setStutterThreshold(JNIEnv*, jobject, jfloat value) {
    if (atomEngine) atomEngine->setStutterThreshold(value);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setWarpBipolarThreshold(JNIEnv*, jobject, jfloat value) {
    if (atomEngine) atomEngine->setWarpBipolarThreshold(value);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setStutterBipolarThreshold(JNIEnv*, jobject, jfloat value) {
    if (atomEngine) atomEngine->setStutterBipolarThreshold(value);
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpThreshold() : 0.5f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterThreshold() : 0.5f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpBipolarThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpBipolarThreshold() : -80.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterBipolarThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterBipolarThreshold() : -90.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpHz(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpHz() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterHz(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterHz() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpDb(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpDb() : -120.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterDb(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterDb() : -120.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpRaw(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpRaw() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterRaw(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterRaw() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getWarpBipolar(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpBipolar() : -120.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getStutterBipolar(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterBipolar() : -120.0f;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getWarpCounter(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpCounter() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getStutterCounter(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterCounter() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getWarpDirection(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpDirection() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getStutterDirection(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterDirection() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getWarpDirectionUpCounter(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpDirectionUpCounter() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getWarpDirectionDownCounter(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getWarpDirectionDownCounter() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getStutterDirectionUpCounter(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterDirectionUpCounter() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getStutterDirectionDownCounter(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getStutterDirectionDownCounter() : 0;
}
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getPitchThresholdEvents(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getPitchThresholdEvents() : 0;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setInnerVoiceMaskEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setInnerVoiceMaskEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setInnerVoiceMaskGain(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setInnerVoiceMaskGain(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setInnerVoiceMaskThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setInnerVoiceMaskThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setLoudSpeechMaskEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setLoudSpeechMaskEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setLoudSpeechMaskGain(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setLoudSpeechMaskGain(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setLoudSpeechMaskThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setLoudSpeechMaskThreshold(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getInnerVoiceMaskActive(JNIEnv*, jobject) { return atomEngine ? atomEngine->getInnerVoiceMaskActive() : false; }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getLoudSpeechMaskActive(JNIEnv*, jobject) { return atomEngine ? atomEngine->getLoudSpeechMaskActive() : false; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientKillEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAmbientKillEnabled(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAmbientShiftEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAmbientShiftEnabled(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setPeakLimiterDb(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setPeakLimiterDb(v);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setPeakLimiterRatio(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setPeakLimiterRatio(v);
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPeakHoldDb(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getPeakHoldDb() : -300.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getPeakLimiterReductionDb(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getPeakLimiterReductionDb() : 0.0f;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientKillActive(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientKillActive() : false;
}
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAmbientShiftActive(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getAmbientShiftActive() : false;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAntiAmbianceEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setAntiAmbianceEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAtmosphereMode(JNIEnv*, jobject, jint v) { if (atomEngine) atomEngine->setAtmosphereMode(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setIntentionGateThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setIntentionGateThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setImaginationSpaceIntensity(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setImaginationSpaceIntensity(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setIntentionLowHz(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setIntentionLowHz(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setIntentionHighHz(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setIntentionHighHz(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setGateAttackMs(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setGateAttackMs(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setGateReleaseMs(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setGateReleaseMs(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getAntiAmbianceEnabled(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAntiAmbianceEnabled() : false; }
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getAtmosphereMode(JNIEnv*, jobject) { return atomEngine ? atomEngine->getAtmosphereMode() : 2; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getIntentionGateThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getIntentionGateThreshold() : -1000.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getImaginationSpaceIntensity(JNIEnv*, jobject) { return atomEngine ? atomEngine->getImaginationSpaceIntensity() : 1.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getIntentionLowHz(JNIEnv*, jobject) { return atomEngine ? atomEngine->getIntentionLowHz() : 200.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getIntentionHighHz(JNIEnv*, jobject) { return atomEngine ? atomEngine->getIntentionHighHz() : 4000.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getGateAttackMs(JNIEnv*, jobject) { return atomEngine ? atomEngine->getGateAttackMs() : 20.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getGateReleaseMs(JNIEnv*, jobject) { return atomEngine ? atomEngine->getGateReleaseMs() : 120.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getIntentionLevel(JNIEnv*, jobject) { return atomEngine ? atomEngine->getIntentionLevel() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getGateAmount(JNIEnv*, jobject) { return atomEngine ? atomEngine->getGateAmount() : 0.0f; }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getIntentionGateOpen(JNIEnv*, jobject) { return atomEngine ? atomEngine->getIntentionGateOpen() : false; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeLeftLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getEyeLeftLevel() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeRightLevel(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getEyeRightLevel() : 0.0f;
}
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeVisionThreshold(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getEyeVisionThreshold() : 0.3f;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEyePingPongEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setEyePingPongEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEyePingPongLevel(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEyePingPongLevel(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEyeBipolarDb(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEyeBipolarDb(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEyeAmbientThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEyeAmbientThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyePingPongLevel(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEyePingPongLevel() : 0.5f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeBipolarDb(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEyeBipolarDb() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeAmbientThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEyeAmbientThreshold() : 0.3f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeLeftPitch(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEyeLeftPitch() : 0.0f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEyeRightPitch(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEyeRightPitch() : 0.0f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAdvancedValue(JNIEnv*, jobject, jint control, jfloat value) {
    if (atomEngine) atomEngine->setAdvancedValue(control, value);
    if (echoProc && control == AtomSpareEngine::ECHO_THRESHOLD) echoProc->setGateThreshold(value);
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setAdvancedEnabled(JNIEnv*, jobject, jint control, jboolean enabled) {
    if (atomEngine) atomEngine->setAdvancedEnabled(control, enabled);
    if (echoProc && control == AtomSpareEngine::ECHO_THRESHOLD) echoProc->setGateEnabled(enabled);
}

// ========== Resonance / Robotic ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setResonanceModeEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setResonanceModeEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setResonanceStrength(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setResonanceStrength(v);
}
JNIEXPORT jboolean JNICALL
Java_com_atomicworld_app_NativeBridge_getResonanceModeEnabled(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getResonanceModeEnabled() : false;
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getResonanceStrength(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getResonanceStrength() : 0.45f;
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setRoboticModeEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setRoboticModeEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setRoboticBias(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setRoboticBias(v);
}
JNIEXPORT jboolean JNICALL
Java_com_atomicworld_app_NativeBridge_getRoboticModeEnabled(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getRoboticModeEnabled() : false;
}
JNIEXPORT jfloat JNICALL
Java_com_atomicworld_app_NativeBridge_getRoboticBias(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getRoboticBias() : 0.50f;
}

// ========== Global Effects ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setGlobalEffectsEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setGlobalEffectsEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setGlobalEffectsMix(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setGlobalEffectsMix(v);
}
JNIEXPORT jboolean JNICALL
Java_com_atomicworld_app_NativeBridge_getGlobalEffectsEnabled(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getGlobalEffectsEnabled() : false;
}

// ========== Audio Generation ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAudioGenerationEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setAudioGenerationEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAudioGenSpeed(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAudioGenSpeed(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setAudioGenDensity(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setAudioGenDensity(v);
}
JNIEXPORT jbyteArray JNICALL
Java_com_atomicworld_app_NativeBridge_generateAtomicSound(JNIEnv* env, jobject, jfloat freq, jint dur) {
    // Generate a simple atomic sound (frequency sweep with harmonics)
    int sampleCount = (int)(48000.0f * dur / 1000.0f);
    jbyteArray result = env->NewByteArray(sampleCount * 2);
    
    jbyte* buffer = env->GetByteArrayElements(result, nullptr);
    float phase = 0.0f;
    float phaseIncr = (freq * 2.0f * 3.14159f) / 48000.0f;
    
    for (int i = 0; i < sampleCount; ++i) {
        float sample = sinf(phase) * 0.7f;
        phase += phaseIncr;
        if (phase > 6.28318f) phase -= 6.28318f;
        
        short value = (short)(sample * 32767.0f);
        buffer[i * 2] = (jbyte)(value & 0xFF);
        buffer[i * 2 + 1] = (jbyte)((value >> 8) & 0xFF);
    }
    
    env->ReleaseByteArrayElements(result, buffer, 0);
    return result;
}

// ========== Protection and Blocking ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setProtectionBlockEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setProtectionBlockEnabled(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setThresholdValue(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setThresholdValue(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setBlockingMode(JNIEnv*, jobject, jint mode) {
    if (atomEngine) atomEngine->setBlockingMode(mode);
}
JNIEXPORT jboolean JNICALL
Java_com_atomicworld_app_NativeBridge_getProtectionActive(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getProtectionActive() : false;
}
JNIEXPORT jint JNICALL
Java_com_atomicworld_app_NativeBridge_getThresholdViolations(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdViolations() : 0;
}

// ========== Communication Threshold ==========
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setCommunicationThreshold(JNIEnv*, jobject, jfloat v) {
    if (atomEngine) atomEngine->setCommunicationThreshold(v);
}
JNIEXPORT void JNICALL
Java_com_atomicworld_app_NativeBridge_setThresholdCommunicationBlockEnabled(JNIEnv*, jobject, jboolean v) {
    if (atomEngine) atomEngine->setThresholdCommunicationBlockEnabled(v);
}
JNIEXPORT jint JNICALL
Java_com_atomicworld_app_NativeBridge_getThresholdCommunicationStatus(JNIEnv*, jobject) {
    return atomEngine ? atomEngine->getThresholdCommunicationStatus() : 0;
}
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyProtectionEnabled(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setEnemyProtectionEnabled(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyAmbientThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyAmbientThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyAmbientThresholdLocked(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setEnemyAmbientThresholdLocked(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyAmbientThresholdLocked(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyAmbientThresholdLocked() : false; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyMovementThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyMovementThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemySpeedThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemySpeedThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyWaveThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyWaveThreshold(v); }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyMovementThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyMovementThreshold() : 0.7f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEnemySpeedThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemySpeedThreshold() : 0.7f; }
JNIEXPORT jfloat JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyWaveThreshold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyWaveThreshold() : 0.7f; }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyPitchThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyPitchThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyCommunicationThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemyCommunicationThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemySpeakerThreshold(JNIEnv*, jobject, jfloat v) { if (atomEngine) atomEngine->setEnemySpeakerThreshold(v); }
JNIEXPORT void JNICALL Java_com_atomicworld_app_NativeBridge_setEnemyHardBlock(JNIEnv*, jobject, jboolean v) { if (atomEngine) atomEngine->setEnemyHardBlock(v); }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyProtectionActive(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyProtectionActive() : false; }
JNIEXPORT jint JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyProtectionStatus(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyProtectionStatus() : 0; }
JNIEXPORT jboolean JNICALL Java_com_atomicworld_app_NativeBridge_getEnemyAmbientSignalHold(JNIEnv*, jobject) { return atomEngine ? atomEngine->getEnemyAmbientSignalHold() : false; }

} // extern "C"