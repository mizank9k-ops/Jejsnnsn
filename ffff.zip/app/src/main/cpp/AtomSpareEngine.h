#pragma once
#include <atomic>
#include <cmath>
#include <algorithm>
#include <array>

class AtomSpareEngine {
public:
    enum AdvancedControl {
        WIND_LEVEL = 0, WIND_THRESHOLD, MOVEMENT_SPEED, MOVEMENT_THRESHOLD,
        MOVEMENT_SMOOTH, ATOM_INTENSITY, WAVE_INTENSITY, VISUAL_THRESHOLD,
        ECHO_THRESHOLD, PITCH_SPEED, PITCH_LEVEL, PITCH_THRESHOLD, PITCH_SMOOTH,
        EYE_MOVE_SPEED, EYE_WAVE_LEVEL, EYE_THRESHOLD, EYE_PITCH_THRESHOLD,
        EYE_PROTECTION_THRESHOLD, EYE_VISION_THRESHOLD
    };

    AtomSpareEngine();
    ~AtomSpareEngine() = default;

    void process(float* left, float* right, int numFrames);

    // ===== AtomSpare Speed =====
    void setAtomSpareSpeed(float v)       { atomSpareSpeed.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAtomSpareSpeedEnabled(bool v) { atomSpareSpeedEnabled.store(v); }
    void setAtomSpareSpeedThreshold(float v) { atomSpareSpeedThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAtomSpareSpeedBoost(float v) { atomSpareSpeedBoost.store(std::clamp(v, 0.0f, 2.0f)); }
    float getAtomSpareSpeed() const       { return atomSpareSpeed.load(); }
    float getAtomSpareSpeedThreshold() const { return atomSpareSpeedThreshold.load(); }
    float getAtomSpareSpeedBoost() const { return atomSpareSpeedBoost.load(); }
    void setAtomSpaceCurvature(float v) { atomSpaceCurvature.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAtomSpaceCurvatureThreshold(float v) { atomSpaceCurvatureThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getAtomSpaceCurvature() const { return atomSpaceCurvature.load(); }
    float getAtomSpaceCurvatureThreshold() const { return atomSpaceCurvatureThreshold.load(); }

    // ===== AtomSpare Move =====
    void setAtomSpareMove(float v)        { atomSpareMove.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAtomSpareMoveEnabled(bool v)  { atomSpareMoveEnabled.store(v); }
    float getAtomSpareMove() const        { return atomSpareMove.load(); }

    // ===== AtomSpare Wave =====
    void setAtomSpareWave(float v)        { atomSpareWave.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAtomSpareWaveEnabled(bool v)  { atomSpareWaveEnabled.store(v); }
    float getAtomSpareWave() const        { return atomSpareWave.load(); }

    // ===== WaveSpare Speed / Wave =====
    void setWaveSpareSpeed(float v) { waveSpareSpeed.store(std::clamp(v, 0.0f, 1.0f)); }
    void setWaveSpareSpeedEnabled(bool v) { waveSpareSpeedEnabled.store(v); }
    void setWaveSpareWave(float v) { waveSpareWave.store(std::clamp(v, 0.0f, 1.0f)); }
    void setWaveSpareWaveEnabled(bool v) { waveSpareWaveEnabled.store(v); }
    void setWaveSpareMovement(float v) { waveSpareMovement.store(std::clamp(v, 0.0f, 1.0f)); }
    void setWaveSpareThreshold(float v) { waveSpareThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setWaveSpareBipolarDb(float v) { waveSpareBipolarDb.store(std::clamp(v, -1000.0f, 1000.0f)); }
    float getWaveSpareSpeed() const { return waveSpareSpeed.load(); }
    float getWaveSpareWave() const { return waveSpareWave.load(); }
    float getWaveSpareMovement() const { return waveSpareMovement.load(); }
    float getWaveSpareThreshold() const { return waveSpareThreshold.load(); }
    float getWaveSpareBipolarDb() const { return waveSpareBipolarDb.load(); }
    void setVirtualSpeedCapEnabled(bool v) { virtualSpeedCapEnabled.store(v); }
    void setVirtualSpeedCapMultiplier(float v) { virtualSpeedCapMultiplier.store(std::clamp(v, 1.0f, 100.0f)); }
    bool getVirtualSpeedCapEnabled() const { return virtualSpeedCapEnabled.load(); }
    float getVirtualSpeedCapMultiplier() const { return virtualSpeedCapMultiplier.load(); }
    void setMicIntensityEnabled(bool v) { micIntensityEnabled.store(v); }
    void setMicIntensityBias(float v) { micIntensityBias.store(std::clamp(v, 0.0f, 5.0f)); }
    void setMicIntensityThreshold(float v) { micIntensityThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    bool getMicIntensityEnabled() const { return micIntensityEnabled.load(); }
    float getMicIntensityBias() const { return micIntensityBias.load(); }
    float getMicIntensityThreshold() const { return micIntensityThreshold.load(); }
    float getMicIntensity() const { return micIntensity.load(); }
    float getMicIntensityRaw() const { return micIntensityRaw.load(); }
    float getMicIntensityConfidence() const { return micIntensityConfidence.load(); }
    void setWaveSpaceCurvature(float v) { waveSpaceCurvature.store(std::clamp(v, 0.0f, 1.0f)); }
    void setWaveSpaceCurvatureThreshold(float v) { waveSpaceCurvatureThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getWaveSpaceCurvature() const { return waveSpaceCurvature.load(); }
    float getWaveSpaceCurvatureThreshold() const { return waveSpaceCurvatureThreshold.load(); }
    float getWaveSpareLevel() const { return waveSpareLevel.load(); }
    bool getWaveSpareActive() const { return waveSpareActive.load(); }

    // ===== Wave Speed and Smooth =====
    void setWaveSpeed(float v)            { waveSpeed.store(std::clamp(v, 0.0f, 1.0f)); }
    void setWaveSmooth(float v)           { waveSmooth.store(std::clamp(v, 0.0f, 1.0f)); }
    float getWaveSpeed() const            { return waveSpeed.load(); }
    float getWaveSmooth() const           { return waveSmooth.load(); }

    // ===== Ambient Live Analysis =====
    void setAmbientAnalysisEnabled(bool v) { ambientAnalysisEnabled.store(v); }
    void setAtomSpareAmbientThreshold(float v) {
        if (!atomAmbientThresholdLocked.load()) atomSpareAmbientThreshold.store(std::clamp(v, 0.0f, 1.0f));
    }
    void setWaveSpareAmbientThreshold(float v) {
        if (!waveAmbientThresholdLocked.load()) waveSpareAmbientThreshold.store(std::clamp(v, 0.0f, 1.0f));
    }
    void setAmbientThresholdLocked(bool v) { ambientThresholdLocked.store(v); atomAmbientThresholdLocked.store(v); waveAmbientThresholdLocked.store(v); }
    void setAtomAmbientThresholdLocked(bool v) { atomAmbientThresholdLocked.store(v); }
    void setWaveAmbientThresholdLocked(bool v) { waveAmbientThresholdLocked.store(v); }
    bool getAmbientAnalysisEnabled() const { return ambientAnalysisEnabled.load(); }
    void setAmbientMotionThreshold(float v) { ambientMotionThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAmbientSpeedThreshold(float v) { ambientSpeedThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAmbientWaveThreshold(float v) { ambientWaveThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAmbientMotionGateEnabled(bool v) { ambientMotionGateEnabled.store(v); }
    void setAmbientSpeedGateEnabled(bool v) { ambientSpeedGateEnabled.store(v); }
    void setAmbientWaveGateEnabled(bool v) { ambientWaveGateEnabled.store(v); }
    float getAmbientMotionThreshold() const { return ambientMotionThreshold.load(); }
    float getAmbientSpeedThreshold() const { return ambientSpeedThreshold.load(); }
    float getAmbientWaveThreshold() const { return ambientWaveThreshold.load(); }
    float getAtomSpareAmbientThreshold() const { return atomSpareAmbientThreshold.load(); }
    float getWaveSpareAmbientThreshold() const { return waveSpareAmbientThreshold.load(); }
    bool getAmbientThresholdLocked() const { return ambientThresholdLocked.load(); }
    bool getAtomAmbientThresholdLocked() const { return atomAmbientThresholdLocked.load(); }
    bool getWaveAmbientThresholdLocked() const { return waveAmbientThresholdLocked.load(); }
    bool getAtomAmbientActive() const { return atomAmbientActive.load(); }
    bool getWaveAmbientActive() const { return waveAmbientActive.load(); }
    float getAmbientLevel() const { return ambientLevel.load(); }
    void setAmbientThresholdLevel(float v) { ambientThresholdLevel.store(std::clamp(v, 0.0f, 1.0f)); }
    float getAmbientThresholdLevel() const { return ambientThresholdLevel.load(); }
    void setAmbientBipolarThreshold(float v) { ambientBipolarThreshold.store(std::clamp(v, -120.0f, 0.0f)); }
    float getAmbientBipolarThreshold() const { return ambientBipolarThreshold.load(); }
    float getAmbientRms() const { return ambientRms.load(); }
    float getAmbientFftLevel() const { return ambientFftLevel.load(); }
    float getAmbientDb() const { return ambientDb.load(); }
    float getBodyOutput() const { return bodyOutput.load(); }
    void setAmplifierEnabled(bool v) { amplifierEnabled.store(v); }
    void setAmplifierLevel(float v) { amplifierLevel.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAmplifierGain(float v) { amplifierGain.store(std::clamp(v, 0.0f, 8.0f)); }
    void setAmplifierThreshold(float v) { amplifierThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    bool getAmplifierEnabled() const { return amplifierEnabled.load(); }
    float getAmplifierLevel() const { return amplifierLevel.load(); }
    float getAmplifierGain() const { return amplifierGain.load(); }
    float getAmplifierThreshold() const { return amplifierThreshold.load(); }
    float getDominantHz() const { return dominantHz.load(); }
    float getSpectralCentroidHz() const { return spectralCentroidHz.load(); }
    int getDominantHzCounter() const { return dominantHzCounter.load(); }
    int getSpectralCentroidCounter() const { return spectralCentroidCounter.load(); }
    void setDominantThreshold(float v) { dominantThreshold.store(std::clamp(v, 0.0f, 4000.0f)); }
    void setDominantLevel(float v) { dominantLevel.store(std::clamp(v, 0.0f, 1.0f)); }
    float getDominantThreshold() const { return dominantThreshold.load(); }
    float getDominantLevel() const { return dominantLevel.load(); }
    void setCentroidThreshold(float v) { centroidThreshold.store(std::clamp(v, 0.0f, 4000.0f)); }
    void setCentroidLevel(float v) { centroidLevel.store(std::clamp(v, 0.0f, 1.0f)); }
    float getCentroidThreshold() const { return centroidThreshold.load(); }
    float getCentroidLevel() const { return centroidLevel.load(); }
    void setSpectrumBipolarThreshold(float v) { spectrumBipolarThreshold.store(std::clamp(v, -120.0f, 0.0f)); }
    float getSpectrumBipolarThreshold() const { return spectrumBipolarThreshold.load(); }
    float getSpikeOutput() const { return spikeOutput.load(); }
    int getSpikeCount() const { return spikeCount.load(); }
    bool getSilenceActive() const { return silenceActive.load(); }
    float getSilenceLevel() const { return silenceLevel.load(); }
    float getBrainWaveOutput() const { return brainWaveOutput.load(); }
    float getThresholdedMovementOutput() const { return thresholdedMovementOutput.load(); }
    float getThresholdedMovementLevel() const { return thresholdedMovementLevel.load(); }
    float getThresholdedMovementThreshold() const { return thresholdedMovementThreshold.load(); }
    float getThresholdedSpeedOutput() const { return thresholdedSpeedOutput.load(); }
    float getThresholdedSpeedLevel() const { return thresholdedSpeedLevel.load(); }
    float getThresholdedSpeedThreshold() const { return thresholdedSpeedThreshold.load(); }
    float getThresholdedWaveOutput() const { return thresholdedWaveOutput.load(); }
    float getThresholdedWaveLevel() const { return thresholdedWaveLevel.load(); }
    float getThresholdedWaveThreshold() const { return thresholdedWaveThreshold.load(); }
    bool getCommunicationGateEnabled() const { return commThresholdEnabled.load(); }
    bool getCommunicationGateBlocked() const { return commStatus.load() == 2; }
    int getCommunicationGateState() const { return commStatus.load(); }
    void setSpikeThreshold(float v) { spikeThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getSpikeThreshold() const { return spikeThreshold.load(); }
    void setSilenceThreshold(float v) { silenceThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getSilenceThreshold() const { return silenceThreshold.load(); }
    void setMicrophoneEnabled(bool v) { microphoneEnabled.store(v); }
    void setMicrophoneGain(float v) { microphoneGain.store(std::clamp(v, 0.0f, 3.0f)); }
    bool getMicrophoneEnabled() const { return microphoneEnabled.load(); }
    float getMicrophoneGain() const { return microphoneGain.load(); }
    float getRawMicRms() const { return rawMicRms.load(); }
    float getRawMicPeak() const { return rawMicPeak.load(); }
    void setAmbientSpaceCurvature(float v) { ambientSpaceCurvature.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAmbientSpaceCurvatureThreshold(float v) { ambientSpaceCurvatureThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getAmbientSpaceCurvature() const { return ambientSpaceCurvature.load(); }
    float getAmbientSpaceCurvatureThreshold() const { return ambientSpaceCurvatureThreshold.load(); }
    float getBipolarDb() const { return bipolarDb.load(); }
    float getPitchHz() const { return pitchHz.load(); }
    float getThresholdedPitchHz() const { return thresholdedPitchHz.load(); }
    float getThresholdedPitchDb() const { return thresholdedPitchDb.load(); }
    void setPitchOutputThreshold(float v) { pitchOutputThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setPitchOutputLevel(float v) { pitchOutputLevel.store(std::clamp(v, 0.0f, 1.0f)); }
    float getPitchOutputThreshold() const { return pitchOutputThreshold.load(); }
    float getPitchOutputLevel() const { return pitchOutputLevel.load(); }
    void setArgumentThreshold(float v) { argumentThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getArgumentThreshold() const { return argumentThreshold.load(); }
    bool getArgumentActive() const { return argumentActive.load(); }
    void setDbThreshold(float v) { dbThreshold.store(std::clamp(v, -120.0f, 0.0f)); }
    float getDbThreshold() const { return dbThreshold.load(); }
    void setWarpThreshold(float v) { warpThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setStutterThreshold(float v) { stutterThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setWarpBipolarThreshold(float v) { warpBipolarThreshold.store(std::clamp(v, -120.0f, 0.0f)); }
    void setStutterBipolarThreshold(float v) { stutterBipolarThreshold.store(std::clamp(v, -120.0f, 0.0f)); }
    float getWarpThreshold() const { return warpThreshold.load(); }
    float getStutterThreshold() const { return stutterThreshold.load(); }
    float getWarpBipolarThreshold() const { return warpBipolarThreshold.load(); }
    float getStutterBipolarThreshold() const { return stutterBipolarThreshold.load(); }
    float getWarpHz() const { return warpHz.load(); }
    float getStutterHz() const { return stutterHz.load(); }
    float getWarpDb() const { return warpDb.load(); }
    float getStutterDb() const { return stutterDb.load(); }
    float getWarpRaw() const { return warpRaw.load(); }
    float getStutterRaw() const { return stutterRaw.load(); }
    float getWarpBipolar() const { return warpBipolar.load(); }
    float getStutterBipolar() const { return stutterBipolar.load(); }
    int getWarpCounter() const { return warpCounter.load(); }
    int getStutterCounter() const { return stutterCounter.load(); }
    int getWarpDirection() const { return warpDirection.load(); }
    int getStutterDirection() const { return stutterDirection.load(); }
    int getWarpDirectionUpCounter() const { return warpDirectionUpCounter.load(); }
    int getWarpDirectionDownCounter() const { return warpDirectionDownCounter.load(); }
    int getStutterDirectionUpCounter() const { return stutterDirectionUpCounter.load(); }
    int getStutterDirectionDownCounter() const { return stutterDirectionDownCounter.load(); }
    int getPitchThresholdEvents() const { return pitchThresholdEvents.load(); }
    void setInnerVoiceMaskEnabled(bool v) { innerVoiceMaskEnabled.store(v); }
    void setInnerVoiceMaskGain(float v) { innerVoiceMaskGain.store(std::clamp(v, 0.0f, 1.0f)); }
    void setInnerVoiceMaskThreshold(float v) { innerVoiceMaskThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setLoudSpeechMaskEnabled(bool v) { loudSpeechMaskEnabled.store(v); }
    void setLoudSpeechMaskGain(float v) { loudSpeechMaskGain.store(std::clamp(v, 0.0f, 1.0f)); }
    void setLoudSpeechMaskThreshold(float v) { loudSpeechMaskThreshold.store(std::clamp(v, -120.0f, 0.0f)); }
    bool getInnerVoiceMaskActive() const { return innerVoiceMaskActive.load(); }
    bool getLoudSpeechMaskActive() const { return loudSpeechMaskActive.load(); }
    void setAmbientKillEnabled(bool v) { ambientKillEnabled.store(v); }
    void setAmbientShiftEnabled(bool v) { ambientShiftEnabled.store(v); }
    void setPeakLimiterDb(float v) { peakLimiterDb.store(std::clamp(v, -120.0f, 0.0f)); }
    void setPeakLimiterRatio(float v) { peakLimiterRatio.store(std::max(v, 1.0f)); }
    float getPeakHoldDb() const { return peakHoldDb.load(); }
    float getPeakLimiterReductionDb() const { return peakLimiterReductionDb.load(); }
    bool getAmbientKillActive() const { return ambientKillActive.load(); }
    bool getAmbientShiftActive() const { return ambientShiftActive.load(); }
    void setAntiAmbianceEnabled(bool v) { antiAmbianceEnabled.store(v); }
    void setAtmosphereMode(int v) { atmosphereMode.store(std::clamp(v, 0, 2)); }
    void setIntentionGateThreshold(float v) { intentionGateThreshold.store(std::clamp(v, -1000.0f, 1000.0f)); }
    void setImaginationSpaceIntensity(float v) { imaginationSpaceIntensity.store(std::clamp(v, 0.0f, 1.0f)); }
    void setIntentionLowHz(float v) { intentionLowHz.store(std::clamp(v, 20.0f, 16000.0f)); }
    void setIntentionHighHz(float v) { intentionHighHz.store(std::clamp(v, 20.0f, 16000.0f)); }
    void setGateAttackMs(float v) { gateAttackMs.store(std::clamp(v, 1.0f, 2000.0f)); }
    void setGateReleaseMs(float v) { gateReleaseMs.store(std::clamp(v, 1.0f, 5000.0f)); }
    bool getAntiAmbianceEnabled() const { return antiAmbianceEnabled.load(); }
    int getAtmosphereMode() const { return atmosphereMode.load(); }
    float getIntentionGateThreshold() const { return intentionGateThreshold.load(); }
    float getImaginationSpaceIntensity() const { return imaginationSpaceIntensity.load(); }
    float getIntentionLowHz() const { return intentionLowHz.load(); }
    float getIntentionHighHz() const { return intentionHighHz.load(); }
    float getGateAttackMs() const { return gateAttackMs.load(); }
    float getGateReleaseMs() const { return gateReleaseMs.load(); }
    float getIntentionLevel() const { return intentionLevel.load(); }
    float getGateAmount() const { return gateAmount.load(); }
    bool getIntentionGateOpen() const { return intentionGateOpen.load(); }
    float getEyeLeftLevel() const { return eyeLeftLevel.load(); }
    float getEyeRightLevel() const { return eyeRightLevel.load(); }
    float getEyeVisionThreshold() const { return eyeVisionThreshold.load(); }
    void setEyePingPongEnabled(bool v) { eyePingPongEnabled.store(v); }
    void setEyePingPongLevel(float v) { eyePingPongLevel.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEyeBipolarDb(float v) { eyeBipolarDb.store(std::clamp(v, -1000.0f, 1000.0f)); }
    void setEyeAmbientThreshold(float v) { eyeAmbientThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getEyePingPongLevel() const { return eyePingPongLevel.load(); }
    float getEyeBipolarDb() const { return eyeBipolarDb.load(); }
    float getEyeAmbientThreshold() const { return eyeAmbientThreshold.load(); }
    float getEyeLeftPitch() const { return eyeLeftPitch.load(); }
    float getEyeRightPitch() const { return eyeRightPitch.load(); }

    void setAdvancedValue(int control, float value);
    void setAdvancedEnabled(int control, bool enabled);

    // ===== Resonance / Robotic =====
    void setResonanceModeEnabled(bool v)  { resonanceModeEnabled.store(v); }
    void setResonanceStrength(float v)    { resonanceStrength.store(std::clamp(v, 0.0f, 1.0f)); }
    bool getResonanceModeEnabled() const  { return resonanceModeEnabled.load(); }
    float getResonanceStrength() const    { return resonanceStrength.load(); }

    void setRoboticModeEnabled(bool v)    { roboticModeEnabled.store(v); }
    void setRoboticBias(float v)           { roboticBias.store(std::clamp(v, 0.0f, 1.0f)); }
    bool getRoboticModeEnabled() const    { return roboticModeEnabled.load(); }
    float getRoboticBias() const           { return roboticBias.load(); }

    // ===== Global Effects =====
    void setGlobalEffectsEnabled(bool v)  { globalEffectsEnabled.store(v); }
    void setGlobalEffectsMix(float v)     { globalEffectsMix.store(std::clamp(v, 0.0f, 1.0f)); }
    bool getGlobalEffectsEnabled() const  { return globalEffectsEnabled.load(); }

    // ===== Audio Generation =====
    void setAudioGenerationEnabled(bool v) { audioGenEnabled.store(v); }
    void setAudioGenSpeed(float v)         { audioGenSpeed.store(std::clamp(v, 0.0f, 1.0f)); }
    void setAudioGenDensity(float v)       { audioGenDensity.store(std::clamp(v, 0.0f, 1.0f)); }

    // ===== Protection and Blocking =====
    void setProtectionBlockEnabled(bool v) { protectionBlockEnabled.store(v); }
    void setThresholdValue(float v)       { thresholdValue.store(std::clamp(v, 0.0f, 1.0f)); }
    void setBlockingMode(int mode)        { blockingMode.store(std::clamp(mode, 0, 2)); } // 0=off, 1=soft, 2=hard
    bool getProtectionActive() const      { return protectionActive.load(); }
    int getThresholdViolations() const    { return thresholdViolations.load(); }

    // ===== Communication Threshold =====
    void setCommunicationThreshold(float v) { commThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setThresholdCommunicationBlockEnabled(bool v) { commThresholdEnabled.store(v); }
    int getThresholdCommunicationStatus() const { return commStatus.load(); } // 0=ok, 1=warning, 2=blocked
    void setEnemyProtectionEnabled(bool v) { enemyProtectionEnabled.store(v); }
    void setEnemyAmbientThreshold(float v) { if (!enemyAmbientThresholdLocked.load()) enemyAmbientThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemyAmbientThresholdLocked(bool v) { enemyAmbientThresholdLocked.store(v); }
    bool getEnemyAmbientThresholdLocked() const { return enemyAmbientThresholdLocked.load(); }
    void setEnemyMovementThreshold(float v) { enemyMovementThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemySpeedThreshold(float v) { enemySpeedThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemyWaveThreshold(float v) { enemyWaveThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getEnemyMovementThreshold() const { return enemyMovementThreshold.load(); }
    float getEnemySpeedThreshold() const { return enemySpeedThreshold.load(); }
    float getEnemyWaveThreshold() const { return enemyWaveThreshold.load(); }
    void setEnemyPitchThreshold(float v) { enemyPitchThreshold.store(std::clamp(v, 0.0f, 4000.0f)); }
    void setEnemyCommunicationThreshold(float v) { enemyCommunicationThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemySpeakerThreshold(float v) { enemySpeakerThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemyHardBlock(bool v) { enemyHardBlock.store(v); }
    bool getEnemyProtectionActive() const { return enemyProtectionActive.load(); }
    int getEnemyProtectionStatus() const { return enemyProtectionStatus.load(); }
    bool getEnemyAmbientSignalHold() const { return enemyAmbientSignalHold.load(); }

    // Detection board values (for SurfaceView visualization)
    float getSpeedEnergy() const  { return speedEnergy.load(); }
    float getMoveEnergy() const   { return moveEnergy.load(); }
    float getWaveEnergy() const   { return waveEnergy.load(); }
    float getAtomMoveEnergy() const { return atomMoveEnergy.load(); }
    float getAtomWaveEnergy() const { return atomWaveEnergy.load(); }
    float getWaveSpareSpeedOutput() const { return waveSpareSpeedOutput.load(); }
    float getWaveSpareMoveOutput() const { return waveSpareMoveOutput.load(); }
    float getWaveSpareWaveOutput() const { return waveSpareWaveOutput.load(); }
    float getPitchSpeedOutput() const { return pitchSpeedOutput.load(); }
    float getPitchMovementOutput() const { return pitchMovementOutput.load(); }
    float getPitchWaveOutput() const { return pitchWaveOutput.load(); }
    float getAtomSpareSpeedLeft() const { return atomSpareSpeedLeft.load(); }
    float getAtomSpareSpeedRight() const { return atomSpareSpeedRight.load(); }
    float getAtomSpareMoveLeft() const { return atomSpareMoveLeft.load(); }
    float getAtomSpareMoveRight() const { return atomSpareMoveRight.load(); }
    float getAtomSpareWaveLeft() const { return atomSpareWaveLeft.load(); }
    float getAtomSpareWaveRight() const { return atomSpareWaveRight.load(); }
    float getWarpLeft() const { return warpLeft.load(); }
    float getWarpRight() const { return warpRight.load(); }
    float getWarpCenter() const { return warpCenter.load(); }
    float getStutterLeft() const { return stutterLeft.load(); }
    float getStutterRight() const { return stutterRight.load(); }
    float getStutterCenter() const { return stutterCenter.load(); }
    float getMotionPitchLeftProtection() const { return motionPitchLeftProtection.load(); }
    float getMotionPitchRightProtection() const { return motionPitchRightProtection.load(); }
    float getMotionPitchSpeedProtection() const { return motionPitchSpeedProtection.load(); }
    float getMotionPitchMovementProtection() const { return motionPitchMovementProtection.load(); }
    float getMotionPitchWaveProtection() const { return motionPitchWaveProtection.load(); }
    float getEyeLeftProtection() const { return eyeLeftProtection.load(); }
    float getEyeRightProtection() const { return eyeRightProtection.load(); }
    void setMotionPitchProtectionEnabled(bool v) { motionPitchProtectionEnabled.store(v); }
    void setMotionPitchThreshold(float v) { motionPitchThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setMotionPitchSpeedThreshold(float v) { motionPitchSpeedThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setMotionPitchMovementThreshold(float v) { motionPitchMovementThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setMotionPitchWaveThreshold(float v) { motionPitchWaveThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemyCurveThreshold(float v) { enemyCurveThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemyPlaneThreshold(float v) { enemyPlaneThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemyWallThreshold(float v) { enemyWallThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    void setEnemyRingThreshold(float v) { enemyRingThreshold.store(std::clamp(v, 0.0f, 1.0f)); }
    float getEnemyCurveThreshold() const { return enemyCurveThreshold.load(); }
    float getEnemyPlaneThreshold() const { return enemyPlaneThreshold.load(); }
    float getEnemyWallThreshold() const { return enemyWallThreshold.load(); }
    float getEnemyRingThreshold() const { return enemyRingThreshold.load(); }

    // Body diagram zones (normalized 0..1)
    float getHeadZone() const     { return headZone.load(); }
    float getChestZone() const    { return chestZone.load(); }
    float getAbdomenZone() const  { return abdomenZone.load(); }
    float getLeftArmZone() const  { return leftArmZone.load(); }
    float getRightArmZone() const { return rightArmZone.load(); }
    float getLeftLegZone() const  { return leftLegZone.load(); }
    float getRightLegZone() const { return rightLegZone.load(); }
    void setBodyAmbientThreshold(int index, float value) { if (index >= 0 && index < 16) bodyThresholds[index].store(std::clamp(value, 0.0f, 1.0f)); }
    float getBodyAmbientThreshold(int index) const { return index >= 0 && index < 16 ? bodyThresholds[index].load() : 0.3f; }
    float getBodyAmbientLevel(int index) const { return index >= 0 && index < 16 ? bodyLevels[index].load() : 0.0f; }
    float getBodyAmbientBipolarDb(int index) const { return index >= 0 && index < 16 ? bodyBipolarDb[index].load() : -120.0f; }
    int getBodyAmbientCounter(int index) const { return index >= 0 && index < 16 ? bodyCounters[index].load() : 0; }
    bool getBodyEnemyProtectionActive() const { return bodyEnemyProtectionActive.load(); }
    void setBodyEnemyProtectionEnabled(bool value) { bodyEnemyProtectionEnabled.store(value); }
    void setBodyEnemyMovementThreshold(float value) { bodyEnemyMovementThreshold.store(std::clamp(value, 0.0f, 1.0f)); }
    void setBodyInsideThreshold(float value) { bodyInsideThreshold.store(std::clamp(value, 0.0f, 1.0f)); }
    void setBodyOutsideThreshold(float value) { bodyOutsideThreshold.store(std::clamp(value, 0.0f, 1.0f)); }
    void setBodyInsideProtectionEnabled(bool value) { bodyInsideProtectionEnabled.store(value); }
    void setBodyOutsideProtectionEnabled(bool value) { bodyOutsideProtectionEnabled.store(value); }
    bool getBodyInsideProtectionActive() const { return bodyInsideProtectionActive.load(); }
    bool getBodyOutsideProtectionActive() const { return bodyOutsideProtectionActive.load(); }

private:
    std::atomic<float> atomSpareSpeed{0.50f};
    std::atomic<bool>  atomSpareSpeedEnabled{true};
    std::atomic<float> atomSpareSpeedThreshold{0.30f};
    std::atomic<float> atomSpareSpeedBoost{1.0f};
    std::atomic<float> atomSpaceCurvature{0.50f};
    std::atomic<float> atomSpaceCurvatureThreshold{0.30f};

    std::atomic<float> atomSpareMove{0.50f};
    std::atomic<bool>  atomSpareMoveEnabled{true};

    std::atomic<float> atomSpareWave{0.50f};
    std::atomic<bool>  atomSpareWaveEnabled{true};

    std::atomic<float> waveSpareSpeed{0.50f};
    std::atomic<bool> waveSpareSpeedEnabled{true};
    std::atomic<float> waveSpareWave{0.50f};
    std::atomic<bool> waveSpareWaveEnabled{true};
    std::atomic<float> waveSpareMovement{0.50f};
    std::atomic<float> waveSpareThreshold{0.30f};
    std::atomic<float> waveSpareBipolarDb{0.0f};
    std::atomic<float> waveSpaceCurvature{0.50f};
    std::atomic<float> waveSpaceCurvatureThreshold{0.30f};
    std::atomic<float> waveSpareLevel{0.0f};
    std::atomic<bool> waveSpareActive{false};
    std::atomic<bool> virtualSpeedCapEnabled{false};
    std::atomic<float> virtualSpeedCapMultiplier{1.0f};
    std::atomic<bool> micIntensityEnabled{true};
    std::atomic<float> micIntensityBias{1.0f};
    std::atomic<float> micIntensityThreshold{0.25f};
    std::atomic<float> micIntensityRaw{0.0f};
    std::atomic<float> micIntensity{0.0f};
    std::atomic<float> micIntensityConfidence{0.0f};

    std::atomic<float> waveSpeed{0.50f};
    std::atomic<float> waveSmooth{0.60f};

    std::atomic<bool> ambientAnalysisEnabled{true};
    std::atomic<float> ambientMotionThreshold{0.20f};
    std::atomic<float> ambientSpeedThreshold{0.30f};
    std::atomic<float> ambientWaveThreshold{0.30f};
    std::atomic<bool> ambientMotionGateEnabled{true};
    std::atomic<bool> ambientSpeedGateEnabled{true};
    std::atomic<bool> ambientWaveGateEnabled{true};
    std::atomic<float> atomSpareAmbientThreshold{0.30f};
    std::atomic<float> waveSpareAmbientThreshold{0.30f};
    std::atomic<bool> ambientThresholdLocked{false};
    std::atomic<bool> atomAmbientThresholdLocked{false};
    std::atomic<bool> waveAmbientThresholdLocked{false};
    std::atomic<bool> atomAmbientActive{false};
    std::atomic<bool> waveAmbientActive{false};
    std::atomic<float> ambientLevel{0.0f};
    std::atomic<float> ambientThresholdLevel{0.30f};
    std::atomic<float> ambientBipolarThreshold{-120.0f};
    std::atomic<float> ambientRms{0.0f};
    std::atomic<float> ambientFftLevel{0.0f};
    std::atomic<float> ambientDb{-60.0f};
    std::atomic<float> warpThreshold{0.50f};
    std::atomic<float> stutterThreshold{0.50f};
    std::atomic<float> warpBipolarThreshold{-80.0f};
    std::atomic<float> stutterBipolarThreshold{-90.0f};
    std::atomic<float> warpHz{0.0f};
    std::atomic<float> stutterHz{0.0f};
    std::atomic<float> warpDb{0.0f};
    std::atomic<float> stutterDb{0.0f};
    std::atomic<float> warpRaw{0.0f};
    std::atomic<float> stutterRaw{0.0f};
    std::atomic<float> warpBipolar{0.0f};
    std::atomic<float> stutterBipolar{0.0f};
    std::atomic<int> warpCounter{0};
    std::atomic<int> stutterCounter{0};
    std::atomic<int> warpDirection{0};
    std::atomic<int> stutterDirection{0};
    std::atomic<int> warpDirectionUpCounter{0};
    std::atomic<int> warpDirectionDownCounter{0};
    std::atomic<int> stutterDirectionUpCounter{0};
    std::atomic<int> stutterDirectionDownCounter{0};
    std::atomic<float> bodyOutput{0.0f};
    std::atomic<bool> amplifierEnabled{false};
    std::atomic<float> amplifierLevel{0.5f};
    std::atomic<float> amplifierGain{1.0f};
    std::atomic<float> amplifierThreshold{0.1f};
    std::atomic<bool> microphoneEnabled{true};
    std::atomic<float> microphoneGain{1.0f};
    std::atomic<float> rawMicRms{0.0f};
    std::atomic<float> rawMicPeak{0.0f};
    std::atomic<float> ambientSpaceCurvature{0.50f};
    std::atomic<float> ambientSpaceCurvatureThreshold{0.30f};
    std::atomic<float> bipolarDb{-120.0f};
    std::atomic<float> pitchHz{0.0f};
    std::atomic<float> thresholdedPitchHz{0.0f};
    std::atomic<float> thresholdedPitchDb{-120.0f};
    std::atomic<float> pitchOutputThreshold{0.25f};
    std::atomic<float> pitchOutputLevel{0.5f};
    std::atomic<float> dominantThreshold{0.0f};
    std::atomic<float> dominantLevel{0.5f};
    std::atomic<float> centroidThreshold{0.0f};
    std::atomic<float> centroidLevel{0.5f};
    std::atomic<float> spectrumBipolarThreshold{-120.0f};
    std::atomic<float> dominantHz{0.0f};
    std::atomic<float> spectralCentroidHz{0.0f};
    std::atomic<int> dominantHzCounter{0};
    std::atomic<int> spectralCentroidCounter{0};
    std::atomic<float> spikeOutput{0.0f};
    std::atomic<int> spikeCount{0};
    std::atomic<bool> silenceActive{true};
    std::atomic<float> brainWaveOutput{0.0f};
    std::atomic<float> spikeThreshold{0.35f};
    std::atomic<float> silenceThreshold{0.02f};
    std::atomic<float> silenceLevel{0.0f};
    std::atomic<float> argumentThreshold{0.30f};
    std::atomic<bool> argumentActive{false};
    std::atomic<float> dbThreshold{-50.0f};
    std::atomic<int> pitchThresholdEvents{0};
    std::atomic<bool> innerVoiceMaskEnabled{false};
    std::atomic<float> innerVoiceMaskGain{0.35f};
    std::atomic<float> innerVoiceMaskThreshold{0.25f};
    std::atomic<bool> loudSpeechMaskEnabled{false};
    std::atomic<float> loudSpeechMaskGain{0.35f};
    std::atomic<float> loudSpeechMaskThreshold{-30.0f};
    std::atomic<bool> innerVoiceMaskActive{false};
    std::atomic<bool> loudSpeechMaskActive{false};
    std::atomic<bool> ambientKillEnabled{false};
    std::atomic<bool> ambientShiftEnabled{false};
    std::atomic<float> peakLimiterDb{-20.0f};
    std::atomic<float> peakLimiterRatio{4.0f};
    std::atomic<float> peakHoldDb{-300.0f};
    std::atomic<float> peakLimiterReductionDb{0.0f};
    std::atomic<bool> ambientKillActive{false};
    std::atomic<bool> ambientShiftActive{false};
    std::atomic<bool> antiAmbianceEnabled{true};
    std::atomic<int> atmosphereMode{2};
    std::atomic<float> intentionGateThreshold{-1000.0f};
    std::atomic<float> imaginationSpaceIntensity{1.0f};
    std::atomic<float> intentionLowHz{200.0f};
    std::atomic<float> intentionHighHz{4000.0f};
    std::atomic<float> gateAttackMs{20.0f};
    std::atomic<float> gateReleaseMs{120.0f};
    std::atomic<float> intentionLevel{0.0f};
    std::atomic<float> gateAmount{0.0f};
    std::atomic<bool> intentionGateOpen{false};
    std::atomic<float> eyeLeftLevel{0.0f};
    std::atomic<float> eyeRightLevel{0.0f};
    std::atomic<float> eyeLeftPitch{0.0f};
    std::atomic<float> eyeRightPitch{0.0f};
    std::atomic<float> eyeLeftProtection{0.0f};
    std::atomic<float> eyeRightProtection{0.0f};
    std::atomic<float> eyePingPongLevel{0.50f};
    std::atomic<float> eyeBipolarDb{0.0f};
    std::atomic<float> eyeAmbientThreshold{0.30f};
    std::atomic<bool> eyePingPongEnabled{true};

    std::atomic<float> windLevel{0.50f};
    std::atomic<float> windThreshold{0.25f};
    std::atomic<float> movementSpeed{0.50f};
    std::atomic<float> movementThreshold{0.20f};
    std::atomic<float> movementSmooth{0.60f};
    std::atomic<float> atomIntensity{0.70f};
    std::atomic<float> waveIntensity{0.70f};
    std::atomic<float> visualThreshold{0.25f};
    std::atomic<float> echoThreshold{0.40f};
    std::atomic<float> pitchSpeed{0.50f};
    std::atomic<float> pitchLevel{0.50f};
    std::atomic<float> pitchThreshold{0.25f};
    std::atomic<float> pitchSmooth{0.60f};
    std::atomic<bool> windEnabled{true};
    std::atomic<bool> atomGateEnabled{true};
    std::atomic<bool> waveGateEnabled{true};
    std::atomic<bool> visualGateEnabled{true};
    std::atomic<bool> echoGateEnabled{true};
    std::atomic<float> eyeMoveSpeed{0.60f};
    std::atomic<float> eyeWaveLevel{0.55f};
    std::atomic<float> eyeThreshold{0.20f};
    std::atomic<float> eyePitchThreshold{0.25f};
    std::atomic<float> eyeProtectionThreshold{0.85f};
    std::atomic<float> eyeVisionThreshold{0.30f};
    std::atomic<bool> eyeMoveEnabled{true};
    std::atomic<bool> eyeWaveEnabled{true};
    std::atomic<bool> eyeVisionEnabled{true};
    std::atomic<bool> eyeProtectionEnabled{true};

    std::atomic<bool>  resonanceModeEnabled{false};
    std::atomic<float> resonanceStrength{0.45f};
    std::atomic<bool>  roboticModeEnabled{false};
    std::atomic<float> roboticBias{0.50f};

    std::atomic<bool>  globalEffectsEnabled{false};
    std::atomic<float> globalEffectsMix{0.50f};

    std::atomic<bool>  audioGenEnabled{false};
    std::atomic<float> audioGenSpeed{0.50f};
    std::atomic<float> audioGenDensity{0.40f};

    std::atomic<bool>  protectionBlockEnabled{false};
    std::atomic<float> thresholdValue{0.60f};
    std::atomic<int>   blockingMode{1}; // 0=off, 1=soft, 2=hard
    std::atomic<bool>  protectionActive{false};
    std::atomic<int>   thresholdViolations{0};

    std::atomic<float> commThreshold{0.55f};
    std::atomic<bool>  commThresholdEnabled{true};
    std::atomic<int>   commStatus{0}; // 0=ok, 1=warning, 2=blocked
    std::atomic<bool> enemyProtectionEnabled{true};
    std::atomic<float> enemyAmbientThreshold{0.30f};
    std::atomic<bool> enemyAmbientThresholdLocked{false};
    std::atomic<float> enemyMovementThreshold{0.70f};
    std::atomic<float> enemySpeedThreshold{0.70f};
    std::atomic<float> enemyWaveThreshold{0.70f};
    std::atomic<float> enemyPitchThreshold{1800.0f};
    std::atomic<float> enemyCommunicationThreshold{0.55f};
    std::atomic<float> enemySpeakerThreshold{0.70f};
    std::atomic<bool> enemyHardBlock{false};
    std::atomic<bool> enemyProtectionActive{false};
    std::atomic<int> enemyProtectionStatus{0};
    std::atomic<bool> enemyAmbientSignalHold{false};

    std::atomic<float> speedEnergy{0.0f};
    std::atomic<float> moveEnergy{0.0f};
    std::atomic<float> waveEnergy{0.0f};
    std::atomic<float> thresholdedMovementOutput{0.0f};
    std::atomic<float> thresholdedMovementLevel{0.0f};
    std::atomic<float> thresholdedMovementThreshold{0.0f};
    std::atomic<float> thresholdedSpeedOutput{0.0f};
    std::atomic<float> thresholdedSpeedLevel{0.0f};
    std::atomic<float> thresholdedSpeedThreshold{0.0f};
    std::atomic<float> thresholdedWaveOutput{0.0f};
    std::atomic<float> thresholdedWaveLevel{0.0f};
    std::atomic<float> thresholdedWaveThreshold{0.0f};
    std::atomic<float> atomMoveEnergy{0.0f};
    std::atomic<float> atomWaveEnergy{0.0f};
    std::atomic<float> waveSpareSpeedOutput{0.0f};
    std::atomic<float> waveSpareMoveOutput{0.0f};
    std::atomic<float> waveSpareWaveOutput{0.0f};
    std::atomic<float> pitchSpeedOutput{0.0f};
    std::atomic<float> pitchMovementOutput{0.0f};
    std::atomic<float> pitchWaveOutput{0.0f};
    std::atomic<float> atomSpareSpeedLeft{0.0f};
    std::atomic<float> atomSpareSpeedRight{0.0f};
    std::atomic<float> atomSpareMoveLeft{0.0f};
    std::atomic<float> atomSpareMoveRight{0.0f};
    std::atomic<float> atomSpareWaveLeft{0.0f};
    std::atomic<float> atomSpareWaveRight{0.0f};
    std::atomic<float> warpLeft{0.0f};
    std::atomic<float> warpRight{0.0f};
    std::atomic<float> warpCenter{0.0f};
    std::atomic<float> stutterLeft{0.0f};
    std::atomic<float> stutterRight{0.0f};
    std::atomic<float> stutterCenter{0.0f};
    std::atomic<float> motionPitchLeftProtection{0.0f};
    std::atomic<float> motionPitchRightProtection{0.0f};
    std::atomic<float> motionPitchSpeedProtection{0.0f};
    std::atomic<float> motionPitchMovementProtection{0.0f};
    std::atomic<float> motionPitchWaveProtection{0.0f};
    std::atomic<bool> motionPitchProtectionEnabled{true};
    std::atomic<float> motionPitchThreshold{0.25f};
    std::atomic<float> motionPitchSpeedThreshold{0.65f};
    std::atomic<float> motionPitchMovementThreshold{0.65f};
    std::atomic<float> motionPitchWaveThreshold{0.65f};
    std::atomic<float> enemyCurveThreshold{0.70f};
    std::atomic<float> enemyPlaneThreshold{0.70f};
    std::atomic<float> enemyWallThreshold{0.70f};
    std::atomic<float> enemyRingThreshold{0.70f};

    std::atomic<float> headZone{0.0f};
    std::atomic<float> chestZone{0.0f};
    std::atomic<float> abdomenZone{0.0f};
    std::atomic<float> leftArmZone{0.0f};
    std::atomic<float> rightArmZone{0.0f};
    std::atomic<float> leftLegZone{0.0f};
    std::atomic<float> rightLegZone{0.0f};
    std::array<std::atomic<float>, 16> bodyThresholds{};
    std::array<std::atomic<float>, 16> bodyLevels{};
    std::array<std::atomic<float>, 16> bodyBipolarDb{};
    std::array<std::atomic<int>, 16> bodyCounters{};
    std::atomic<bool> bodyEnemyProtectionEnabled{false};
    std::atomic<float> bodyEnemyMovementThreshold{0.7f};
    std::atomic<bool> bodyEnemyProtectionActive{false};
    std::atomic<float> bodyInsideThreshold{0.5f};
    std::atomic<float> bodyOutsideThreshold{0.5f};
    std::atomic<bool> bodyInsideProtectionEnabled{true};
    std::atomic<bool> bodyOutsideProtectionEnabled{true};
    std::atomic<bool> bodyInsideProtectionActive{false};
    std::atomic<bool> bodyOutsideProtectionActive{false};

    float envSpeed = 0.0f;
    float envMove  = 0.0f;
    float envWave  = 0.0f;
    float previousInput = 0.0f;
    float audioGenPhase = 0.0f;
    int violationCounter = 0;
    bool pitchEventActive = false;
};