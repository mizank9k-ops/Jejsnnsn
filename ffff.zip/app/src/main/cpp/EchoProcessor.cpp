#include "EchoProcessor.h"
#include <cstring>
#include <algorithm>
#include <cmath>

EchoProcessor::EchoProcessor() {
    std::memset(delayL, 0, sizeof(delayL));
    std::memset(delayR, 0, sizeof(delayR));
}

void EchoProcessor::process(float* left, float* right, int numFrames) {
    if (!enabled.load() || !left || !right) return;

    const float dMs = delayMs.load();
    const float fb  = feedback.load();
    const float mx  = mix.load();
    const float smooth = smoothingFactor.load();
    const bool protect = protectionEnabled.load();
    const bool gate = gateEnabled.load();
    const float gateLevel = gateThreshold.load();
    const int delaySamples = static_cast<int>(dMs * 48.0f);
    const int readBase = (writePos - delaySamples + MAX_DELAY) % MAX_DELAY;

    bool anyClipping = false;

    for (int i = 0; i < numFrames; ++i) {
        int rp = (readBase + i) % MAX_DELAY;
        float wetL = delayL[rp];
        float wetR = delayR[rp];

        float inL = left[i];
        float inR = right[i];
        if (gate && (std::fabs(inL) + std::fabs(inR)) * 0.5f < gateLevel) {
            delayL[(writePos + i) % MAX_DELAY] = 0.0f;
            delayR[(writePos + i) % MAX_DELAY] = 0.0f;
            continue;
        }

        // Apply smoothing to feedback
        float smoothedFbL = lastFeedbackL * (1.0f - smooth) + wetL * fb * smooth;
        float smoothedFbR = lastFeedbackR * (1.0f - smooth) + wetR * fb * smooth;
        lastFeedbackL = smoothedFbL;
        lastFeedbackR = smoothedFbR;

        float outL = inL + smoothedFbL;
        float outR = inR + smoothedFbR;

        // Detection and protection
        if (protect) {
            if (fabsf(outL) > MAX_AMPLITUDE || fabsf(outR) > MAX_AMPLITUDE) {
                anyClipping = true;
                outL = applySoftClipping(outL);
                outR = applySoftClipping(outR);
            }
        }

        int wp = (writePos + i) % MAX_DELAY;
        delayL[wp] = outL;
        delayR[wp] = outR;

        // Output mixing
        float finalL = inL * (1.0f - mx) + wetL * mx;
        float finalR = inR * (1.0f - mx) + wetR * mx;

        // Smoothing on output
        finalL = lastOutL * (1.0f - smooth * 0.1f) + finalL * (smooth * 0.1f);
        finalR = lastOutR * (1.0f - smooth * 0.1f) + finalR * (smooth * 0.1f);
        
        lastOutL = finalL;
        lastOutR = finalR;

        left[i]  = finalL;
        right[i] = finalR;
    }
    writePos = (writePos + numFrames) % MAX_DELAY;
    protectionActive.store(anyClipping);
}