plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val signalModel = providers.gradleProperty("signalModel").orElse("atomspare-motion-v2").get()
val signalModelVersion = providers.gradleProperty("signalModelVersion").orElse("2").get()
val eyeModel = providers.gradleProperty("eyeModel").orElse("atomspare-eye-v1").get()
val eyeModelVersion = providers.gradleProperty("eyeModelVersion").orElse("1").get()
val intensityModel = providers.gradleProperty("intensityModel").orElse("atomspare-intensity-v1").get()
val visualModel = providers.gradleProperty("visualModel").orElse("atomspare-visual-v1").get()

android {
    namespace = "com.atomicworld.app"
    compileSdk = 34
    ndkVersion = "26.3.11579264"

    defaultConfig {
        applicationId = "com.atomicworld.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        buildConfigField("String", "SIGNAL_MODEL", "\"$signalModel\"")
        buildConfigField("int", "SIGNAL_MODEL_VERSION", signalModelVersion)
        buildConfigField("boolean", "SIGNAL_MODEL_ADJUSTABLE", "true")
        buildConfigField("String", "EYE_MODEL", "\"$eyeModel\"")
        buildConfigField("int", "EYE_MODEL_VERSION", eyeModelVersion)
        buildConfigField("boolean", "EYE_MODEL_ADJUSTABLE", "true")
        buildConfigField("String", "INTENSITY_MODEL", "\"$intensityModel\"")
        buildConfigField("String", "VISUAL_MODEL", "\"$visualModel\"")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17 -frtti -fexceptions"
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildFeatures {
        viewBinding = false
        dataBinding = false
        buildConfig = true
    }

    lint {
        disable.addAll(listOf("MissingTranslation", "ExtraTranslation"))
        abortOnError = false
        checkReleaseBuilds = false
        checkTestSources = false
    }
}

dependencies {
    implementation("com.google.ar:core:1.56.0")
    implementation("com.google.mediapipe:tasks-vision:0.10.35")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
}