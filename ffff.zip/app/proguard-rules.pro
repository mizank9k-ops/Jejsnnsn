# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.atomicworld.app.NativeBridge { *; }